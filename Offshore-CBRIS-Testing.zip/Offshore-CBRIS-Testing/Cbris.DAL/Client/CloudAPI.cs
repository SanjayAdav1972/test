﻿using Clarksons.Automation.Support.Setup;
using System;
using System.Threading.Tasks;

namespace Cbris.DAL.Client
{

    public interface ICloudAPI
    {
        Task<string> GetCloudTokenDecoded(string username, string password);
        Task<string> GetCloudTokenEncoded(string username, string password);

    }

    public class CloudAPI : ICloudAPI
    {
        private const string API = @"/API/1_1/";

        /// <summary>
        /// Call CloudApi to get the Login Token in decoded form.
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<string> GetCloudTokenDecoded(string username, string password)
        {
            string token = string.Empty;

            if (username == null || password == null)
                throw new ArgumentNullException("Username/Password cannot be null!");

            var uri = new System.Text.StringBuilder($"{Settings.CloudAPIUri}{API}Security/GetLoginToken");

            uri.Append($"?Username={username}&password={password}");


            using (var client = new System.Net.Http.HttpClient())
            {
                System.Net.Http.HttpResponseMessage response = await client.GetAsync(uri.ToString());

                var status = (int)response.StatusCode;

                if (status == 200)
                {
                    var responseData = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                    try
                    {
                        dynamic obj = Newtonsoft.Json.JsonConvert.DeserializeObject(responseData);
                        token = obj.LoginToken;
                    }
                    catch (Exception ex)
                    {
                        throw new ResponseBodyNotDeserialized($"Could not deserialize the response body. Status: {(int)response.StatusCode} Data: {responseData} Message: {ex.Message}");
                    }
                }

                else
                    if (status != 200 & status != 204)
                {
                    var responseData = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    throw new System.Net.Http.HttpRequestException($"The HTTP status code of the response was not expected ({(int)response.StatusCode}).");
                }
            }

            return token;
        }

        /// <summary>
        /// Call CloudApi to get the Login Token in encoded form.
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<string> GetCloudTokenEncoded(string username, string password)
        {
            return System.Web.HttpUtility.UrlEncode(await GetCloudTokenDecoded(username, password));
        }
    }

    [Serializable]
    public class ResponseBodyNotDeserialized : Exception
    {
        public ResponseBodyNotDeserialized() { }
        public ResponseBodyNotDeserialized(string message) : base(message) { }
        public ResponseBodyNotDeserialized(string message, Exception inner) : base(message, inner) { }
    }
}
