﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Configuration;

namespace Cbris.DAL.SQL.Engine
{
    public abstract class SQLRunner
    {

        public enum ApplicationDatabase
        {
            None, Arc, QAAutomation
        }

        /// <summary>
        /// Executes a SQL command and return a dataTable which contains the results
        /// </summary>
        /// <param name="command"></param>
        /// <param name="resultFolder"></param>
        /// <returns></returns>
        private static DataTable ExecuteScript(SqlCommand command, ApplicationDatabase app)
        {
            string connectionString = string.Empty;

            DataTable dtQueryResults = new DataTable();

            switch (app)
            {
                case ApplicationDatabase.Arc:
                    connectionString = ConfigurationManager.ConnectionStrings["ARC_DB"].ConnectionString;
                    break;
                case ApplicationDatabase.QAAutomation:
                    connectionString = ConfigurationManager.ConnectionStrings["ARC_KEYRING"].ConnectionString;
                    break;

            }



            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                command.Connection = cn;

                using (SqlDataAdapter da = new SqlDataAdapter(command))
                {
                    da.Fill(dtQueryResults);
                }

            }

            return dtQueryResults;

        }

        /// <summary>
        /// Export data from a Data Table to an Excel file
        /// </summary>
        /// <param name="filePath">Where to save the file</param>
        /// <param name="format">choose between csv and xlsx</param>
        /// <param name="dt">Data table to export</param>
        internal static void ExportDataWithExcel(string filePath, string format, DataTable dt)
        {
            //default format if not specified
            Excel.XlFileFormat form = Excel.XlFileFormat.xlWorkbookDefault;

            Excel.Application application = new Excel.Application
            {
                Visible = false
            };

            object misValue = Missing.Value;

            Excel.Workbook workbook = (Excel.Workbook)(application.Workbooks.Add(misValue));
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.ActiveSheet;

            string data = string.Empty;

            for (int r = 0; r <= dt.Rows.Count - 1; r++)
                for (int c = 0; c <= dt.Columns.Count - 1; c++)
                {
                    data = dt.Rows[r].ItemArray[c].ToString();
                    worksheet.Cells[r + 1, c + 1] = data;
                }

            switch (format)
            {
                case "csv":
                    form = Excel.XlFileFormat.xlCSV;
                    break;
                case "xlsx":
                    form = Excel.XlFileFormat.xlWorkbookDefault;
                    break;
            }

            workbook.SaveAs(filePath, form, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            workbook.Close(true, misValue, misValue);
            application.Quit();

            Dispose(worksheet);
            Dispose(workbook);
            Dispose(application);
        }

        private static void Dispose(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception exc)
            {
                obj = null;
                Console.WriteLine("Exception occured while releasing the object " + exc.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        /// <summary>
        /// Execute a script stored inside a sql file=. Returns a data table with the results
        /// </summary>
        /// <param name="resultFolder"></param>
        /// <param name="scriptFileName"></param>
        /// <param name="parameters">parameters to be provided to the script</param>
        internal static DataTable ExecuteScript(string sqlScript, Dictionary<string, object> parameters = null, ApplicationDatabase app = ApplicationDatabase.Arc)
        {

            using (SqlCommand command = new SqlCommand(sqlScript))
            {
                command.CommandTimeout = 600;
                if (parameters != null)
                {
                    foreach (KeyValuePair<string, object> param in parameters)
                        command.Parameters.AddWithValue(param.Key, param.Value);
                }

                return ExecuteScript(command, app);
            }

        }

        internal object ExecuteScalar(string query, Dictionary<string, object> parameters = null, ApplicationDatabase app = ApplicationDatabase.Arc)
        {
            string connectionString = string.Empty;

            switch (app)
            {
                case ApplicationDatabase.Arc:
                    connectionString = ConfigurationManager.ConnectionStrings["ARC_DB"].ConnectionString;
                    break;
                case ApplicationDatabase.QAAutomation:
                    connectionString = ConfigurationManager.ConnectionStrings["ARC_KEYRING"].ConnectionString;
                    break;

            }

            using (var conn = new SqlConnection(connectionString))
            {
                using (var cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        foreach (KeyValuePair<string, object> param in parameters)
                            cmd.Parameters.AddWithValue(param.Key, param.Value);
                    }

                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }

    }
}
