﻿using Cbris.DAL.SQL.Engine;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Cbris.DAL.SQL.Scripts
{
    public class VesselData :SQLRunner
    {
        /// <summary>
        /// Returns an Offshore vessel which doesn't have any activity affecting the start and end date
        /// </summary>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        /// <returns></returns>
        public static string GetNoActivityVesselImo(DateTime startdate, DateTime enddate)
        {
            Dictionary<string, object> par = new Dictionary<string, object>
            {
                { "@StartDate", startdate },
                {"@EndDate", enddate }
            };

            DataTable dt = ExecuteScript(SQLScripts.GetActivityFreeVessel, par, ApplicationDatabase.Arc);

            return (from DataRow dr in dt.Rows select dr["VesselIMO"].ToString()).Select(x => x.Trim()).FirstOrDefault();

        }

        public static string GetVesselNameFromImo(string imo)
        {
            Dictionary<string, object> par = new Dictionary<string, object>
            {
                { "@VesselIMO", imo },
            };

            DataTable dt = ExecuteScript(SQLScripts.GetVesselNameFromIMO, par, ApplicationDatabase.Arc);

            return (from DataRow dr in dt.Rows select dr["VesselName"].ToString()).Select(x => x.Trim()).FirstOrDefault();
        }
    }
}
