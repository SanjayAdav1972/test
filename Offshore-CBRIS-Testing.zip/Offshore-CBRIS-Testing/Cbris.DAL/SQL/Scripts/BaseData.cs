﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cbris.DAL.SQL.Engine;

namespace Cbris.DAL.SQL.Scripts
{
    public class BaseData : SQLRunner
    {
        public static Tuple<string, string> GetTestSettings(string useremail)
        {
            Dictionary<string, object> par = new Dictionary<string, object>
            {
                { "@EmailAdd", useremail },
            };

            DataTable dt = ExecuteScript(SQLScripts.GetTestCredentials, par, ApplicationDatabase.QAAutomation);

            return new Tuple<string, string>((from DataRow dr in dt.Rows select dr["EmailAddress"].ToString()).Select(x => x.Trim()).FirstOrDefault(),
                (from DataRow dr in dt.Rows select dr["Password"].ToString()).Select(x => x.Trim()).FirstOrDefault());

        }
    }
}
