﻿USE ARC

select StringValue as VesselName from VesselColumnValue vcv
inner join Vessels ve
on ve.VesselId = vcv.VesselId 
where ve.VesselIMO = @VesselIMO and vcv.VesselColumnId = 498 and DepartmentId = 8