﻿Use ARC

select Top(1) * from Vessels
where VesselId not in 
(
	select VesselId from Activity.Activity act
	where (act.StartDate <= @StartDate and act.EndDate >= @StartDate) or
	(act.StartDate <= @EndDate and act.EndDate >= @EndDate) and act.ActivityTypeId <> 1
) 
and VesselId in (select VesselId from Offshore.VesselIds)
and VesselId in (select VesselId from VesselColumnValue where VesselColumnId = 498 and DepartmentId = 8)
and VesselIMO is not NULL
Order by VesselIMO DESC