﻿OPEN SYMMETRIC KEY SymKeyTestCredentials
DECRYPTION BY CERTIFICATE CertTestCredentials;

SELECT 
	EmailAddress, 
	CONVERT(VARCHAR, DecryptByKey([Password_Encrypt])) as Password 
FROM 
	Arc.TestCredentials
WHERE
	EmailAddress = @EmailAdd;

CLOSE SYMMETRIC KEY SymKeyTestCredentials;