﻿namespace Cbris.Models.Enums
{
    public enum SectionType
    {
        None = 0,
        Activities = 1,
        Requirements = 2,
        Fixtures = 3,
        Vessels = 4,
        Offers = 5,
        Admin = 6
    }
}
