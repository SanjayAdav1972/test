﻿using System;
using System.Globalization;
using Clarksons.Automation.Support.Utility;

namespace Cbris.Models.Data
{
    public class RequirementObject
    {
        public string Area { get; set; }
        public string Country { get; set; }
        public string Type { get; set; }
        private string _job;
        public string Job
        {
            get { return _job; }

            set
            {
                _job = value + " " + Tools.GenerateRandomInt();
            }
        }
        public string Charterer { get; set; }
        public string VesselType { get; set; }
        private string _startDate;
        public string StartDate
        {
            set
            {
                if (value.Equals("today", StringComparison.InvariantCultureIgnoreCase))
                {
                    _startDate = DateTime.Now.ToString("dd-MM-yyyy");
                }
                else if (value.Contains("+")) //the '+' means today date plus a number of days
                {
                    double plus = double.Parse(value.Split('+')[1].Trim());
                    _startDate = DateTime.Now.AddDays(plus).ToString("dd-MM-yyyy");
                }
                else
                {
                    _startDate = value;
                }
            }
            get
            {
                return _startDate;
            }
        }
        public string Range { get; set; }
        public string DurationType { get; set; }

        public string GetEndDate()
        {
            var date = DateTime.ParseExact(_startDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            switch (DurationType)
            {
                case "Days":
                    return date.AddDays(int.Parse(Range)).ToString("dd-MM-yyyy");
                case "Months":
                    return date.AddMonths(int.Parse(Range)).ToString("dd-MM-yyyy");
                case "Weeks":
                    int weekstodays = int.Parse(Range) * 7;
                    return date.AddDays(weekstodays).ToString("dd-MM-yyyy");
                case "Years":
                    return date.AddYears(int.Parse(Range)).ToString("dd-MM-yyyy");
            }

            throw new DurationTypeNotValidException();
        }
    }
}
