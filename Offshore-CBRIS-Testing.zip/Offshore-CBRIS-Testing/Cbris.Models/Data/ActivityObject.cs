﻿using System;
using System.Globalization;

namespace Cbris.Models.Data
{
    public class ActivityObject
    {
        public string LocationPort { get; set; }
        public string DurationType { get; set; }
        public string Duration { get; set; }
        public string Status { get; set; }
        public string Comment { get; set; }
        private string _from;
        public string From
        {
            set
            {
                if (value.Equals("today", StringComparison.InvariantCultureIgnoreCase))
                    _from = DateTime.Now.ToString("dd-MM-yyyy HH:mm");
                else if (value.Contains("+")) //the '+' means today date plus a number of days
                {
                    double plus = double.Parse(value.Split('+')[1].Trim());
                    _from = DateTime.Now.AddDays(plus).ToString("dd-MM-yyyy HH:mm");
                }
                else
                    _from = value;
            }
            get { return _from; }
        }

        public string GetEndDate()
        {
            var date = DateTime.ParseExact(_from, "dd-MM-yyyy HH:mm", CultureInfo.InvariantCulture);
            switch(DurationType)
            {
                case "Days":
                    return date.AddDays(int.Parse(Duration)).ToString("dd MMM yy");
                case "Months":
                    return date.AddMonths(int.Parse(Duration)).ToString("dd MMM yy");
                case "Weeks":
                    int weekstodays = int.Parse(Duration) * 7;
                    return date.AddDays(weekstodays).ToString("dd MMM yy");
                case "Years":
                    return date.AddYears(int.Parse(Duration)).ToString("dd MMM yy");
            }

            throw new DurationTypeNotValidException();
        }

        public override string ToString()
        {
            return $"Status: {Status} Location: {LocationPort} Start Date: {From} Duration: {Duration} Duration Type: {DurationType}";
        }

    }

    [Serializable]
    internal class DurationTypeNotValidException : Exception
    {
        public DurationTypeNotValidException() { }
        public DurationTypeNotValidException(string message) : base(message) { }
        public DurationTypeNotValidException(string message, Exception inner) : base(message, inner) { }
    }
}
