﻿using Coypu;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

namespace Cbris.Coypu
{
    public static class Extensions
    {
        public static async void VisitWithAuthenticationToken(this BrowserSession browserSession, string url, string username, string password)
        {
            Cbris.DAL.Client.CloudAPI cloud = new DAL.Client.CloudAPI();

            var token = await cloud.GetCloudTokenEncoded(username, password);

            browserSession.Visit($"{url}?token={token}");
        }

        public static string GetCurrentWindowHandle(this BrowserSession browserSession) => ((RemoteWebDriver)browserSession.Native).CurrentWindowHandle;

        public static bool ExistOnPage(this ElementScope element)
        {
            try
            {
                return element.Exists(Options.NoWait);
            }
            catch (StaleElementReferenceException)
            {
                return false;
            }
        }

        public static string GetLastOpenWindow(this BrowserSession browserSession)
        {
            var driver = (RemoteWebDriver)browserSession.Native;
            string newwindow = string.Empty;
            var parenthandler = driver.CurrentWindowHandle;
            var handles = driver.WindowHandles;

            foreach (var windowhandle in handles)
            {
                if (!windowhandle.Equals(parenthandler))
                {
                    newwindow = windowhandle;
                }
            }

            return newwindow;
        }

        public static void SwitchToNewWindow(this BrowserSession browserSession, string windowhandle)
        {
            var driver = (RemoteWebDriver)browserSession.Native;

            driver.SwitchTo().Window(windowhandle);

        }

        public static ElementScope FillInWithDelayedKeyPresses(this ElementScope element, string text, Options options = null, int delayBetweenKeyPressInMs = 25)
        {
            if (!string.IsNullOrWhiteSpace(text))
            {
                foreach (var c in text)
                {
                    element.SendKeys(c.ToString(), options);
                    Thread.Sleep(delayBetweenKeyPressInMs);
                }
            }

            return element;
        }

        public static ElementScope FindFirstByText(this IEnumerable<ElementScope> scopes, string text)
        {
            return scopes.First(result => string.Equals(result.Text, text, StringComparison.InvariantCultureIgnoreCase));
        }

        public static ElementScope DoubleClick(this BrowserSession browserSession, ElementScope element)
        {
            CreateSeleniumActionFromCoypuSession(browserSession).DoubleClick(element.Native as IWebElement).Build().Perform();
            return element;
        }

        public static ElementScope RightClick(this BrowserSession browserSession, ElementScope element)
        {
            CreateSeleniumActionFromCoypuSession(browserSession).ContextClick(element.Native as IWebElement).Build().Perform();
            return element;
        }

        public static ElementScope MoveToElement(this BrowserSession browserSession, ElementScope element)
        {
            CreateSeleniumActionFromCoypuSession(browserSession).MoveToElement(element.Native as IWebElement).Perform();

            return element;
        }

        public static BrowserSession MoveToOffset(this BrowserSession session, int x, int y)
        {
            CreateSeleniumActionFromCoypuSession(session).MoveByOffset(x, y).Perform();

            return session;
        }

        public static BrowserSession ScrollIntoView(this BrowserSession session, ElementScope element)
        {
            session.ExecuteScript(@"arguments[0].scrollIntoView(true);", element);

            return session;
        }

        /// <summary>
        /// Scroll the view in order to have the given element in the center part of the view port.
        /// </summary>
        /// <param name="session"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        public static BrowserSession ScrollToCentralView(this BrowserSession session, ElementScope element)
        {
            string scrollElementIntoMiddle = "var viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);"
                                            + "var elementTop = arguments[0].getBoundingClientRect().top;"
                                            + "window.scrollBy(0, elementTop-(viewPortHeight/2));";

            session.ExecuteScript(scrollElementIntoMiddle, element);

            return session;
        }

        /// <summary>
        /// Returns if the checkbox is currently checked or not.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static bool IsChecked(this ElementScope element)
        {
            var seleniumElement = (IWebElement)element.Native;

            var value = seleniumElement.GetAttribute("aria-checked");

            return bool.Parse(value);
        }

        private static Actions CreateSeleniumActionFromCoypuSession(BrowserSession browserSession)
        {
            return new Actions((RemoteWebDriver)browserSession.Native);
        }

        /// <summary>
        /// Highlight the element on the page. Used in combination with screenshot
        /// </summary>
        /// <param name="element"></param>
        public static void Highlight(this ElementScope element)
        {
            var seleniumElement = (RemoteWebElement)element.Native;
            var jsDriver = (IJavaScriptExecutor)seleniumElement.WrappedDriver;
            string highlightJavascript = @"$(arguments[0]).css({ ""border-width"" : ""2px"", ""border-style"" : ""solid"", ""border-color"" : ""red"" });";
            jsDriver.ExecuteScript(highlightJavascript, new object[] { seleniumElement });
        }

        /// <summary>
        /// Check if the element is on the page. 
        /// </summary>
        /// <param name="element"></param>
        /// <param name="nowait"></param>
        /// <returns></returns>
        public static bool ExistClickable(this ElementScope element, bool nowait = true)
        {
            try
            {
                if (nowait)
                {
                    element.Click(Options.NoWait);
                }
                else
                {
                    element.Click();
                }

                return true;
            }
            catch (MissingHtmlException)
            {
                return false;
            }
            catch (StaleElementException)
            {
                return false;
            }
        }



        public static BrowserSession SelectAll(this BrowserSession browserSession)
        {
            CreateSeleniumActionFromCoypuSession(browserSession)
                .KeyDown(Keys.LeftControl)
                .SendKeys("a")
                .KeyUp(Keys.LeftControl)
                .Perform();

            return browserSession;
        }

        /// <summary>
        /// Returns the attribute value as string. 
        /// </summary>
        /// <param name="element"></param>
        /// <param name="attribute"></param>
        /// <returns></returns>
        public static string GetAttributeValue(this ElementScope element, string attribute)
        {
            var seleniumElement = (IWebElement)element.Native;

            return seleniumElement.GetAttribute(attribute);
        }

        /// <summary>
        /// Check if the web element contains the specified attribute.
        /// </summary>
        /// <param name="element"></param>
        /// <param name="attribute"></param>
        /// <returns></returns>
        public static bool HasAttribute(this ElementScope element, string attribute)
        {
            var seleniumElement = (IWebElement)element.Native;

            try
            {
                if (seleniumElement.GetAttribute(attribute) != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (StaleElementReferenceException)
            {
                return false;
            }
        }

        /// <summary>
        /// Check if the web element has text.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static bool HasText(this ElementScope element)
        {
            return string.IsNullOrWhiteSpace(element.Text);
        }

        /// <summary>
        /// Get the loading time of an element until is available on the page.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static float GetLoadingTime(this ElementScope element)
        {

            Stopwatch sw = new Stopwatch();

            sw.Start();

            while (!element.ExistClickable())
            {
                if (sw.ElapsedMilliseconds > 120000)
                {
                    throw new TimeoutException("Loading time for module exceeded 2 minutes of wait!");
                }
            }

            sw.Stop();

            return sw.ElapsedMilliseconds;
        }

        /// <summary>
        /// Get the loading time of an element until the content text is ready.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static float GetContentLoadingTime(this ElementScope element)
        {
            Stopwatch sw = new Stopwatch();

            sw.Start();

            while (element.Text.Equals(string.Empty))
            {
                if (sw.ElapsedMilliseconds > 120000)
                {
                    throw new TimeoutException("Loading time for module exceeded 2 minutes of wait!");
                }
            }

            sw.Stop();

            return sw.ElapsedMilliseconds;
        }

        /// <summary>
        /// Returns the text of an element when it's visualised on the page. Raise a timeout if the text is not ready after 2 minutes.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static string GetElementText(this ElementScope element)
        {
            Stopwatch sw = new Stopwatch();

            sw.Start();

            while (element.Text.Equals(string.Empty))
            {
                if (sw.ElapsedMilliseconds > 120000)
                {
                    throw new TimeoutException("Text not displayed after 2 minutes of wait!");
                }
            }

            sw.Stop();

            return element.Text;
        }

        /// <summary>
        /// Clear the text inside a web page element.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static ElementScope ClearValue(this ElementScope element)
        {
            while (!string.IsNullOrEmpty(element.Value))
            {
                element.SendKeys(Keys.Backspace);
            }

            return element;
        }

        public static BrowserSession SelectAll(this BrowserSession session, ElementScope element)
        {
            element.Click();

            Actions action = new Actions((IWebDriver)session.Native);

            action.SendKeys(Keys.Control + "a").Build().Perform();

            return session;
        }

        /// <summary>
        /// Validate if an Aria Checkbox is set to a specific value
        /// </summary>
        /// <param name="element"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool ValidateCheckbox(this ElementScope element, string value)
        {
            string chkvalue = element.GetAttributeValue("aria-checked");

            if (chkvalue.Equals("true") && value.Equals("y", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (chkvalue.Equals("false") && value.Equals("n", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (chkvalue.Equals("mixed") && value.Equals("u", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return false;
        }

        public static void WaitUntilElementNotDisabled(this BrowserSession session, ElementScope element)
        {
            session.TryUntil(() => { }, () => !element.Disabled, TimeSpan.FromMilliseconds(500));
        }

        public static void WaitUntilElementDisabled(this BrowserSession session, ElementScope element)
        {
            session.TryUntil(() => { }, () => element.Disabled, TimeSpan.FromMilliseconds(500));
        }

        public static void WaitUntilTextPopulated(this ElementScope element)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            while (element.Text.Equals(string.Empty))
            {
                if (sw.ElapsedMilliseconds > 30000)
                {
                    throw new TimeoutException();
                }
            }
            sw.Stop();
        }

        public static void WaitWhilePageHasContent(this BrowserSession session, string text)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            while (session.HasContent(text, Options.NoWait))
            {
                if (sw.ElapsedMilliseconds > 60000)
                {
                    throw new TimeoutException();
                }
            }
            sw.Stop();
        }

        public static void WaitUntilTextNotVisible(this BrowserSession session, string text)
        {
            session.TryUntil(() => { }, () => !session.Text.Contains(text), TimeSpan.FromMilliseconds(500));
        }

        public static void WaitUntil(this BrowserSession session, Func<bool> until)
        {
            session.TryUntil(() => { }, until, TimeSpan.FromMilliseconds(10));
        }

        /// <summary>
        /// Check if the web page contains the element localised by the XPath
        /// </summary>
        /// <param name="broSession"></param>
        /// <param name="xpath"></param>
        /// <param name="nowait"></param>
        /// <returns></returns>
        public static bool HasElementXPath(this BrowserSession session, string xpath, bool nowait = true)
        {
            try
            {
                if (nowait)
                {
                    session.FindXPath(xpath, Options.NoWait).Click();
                }
                else
                {
                    session.FindXPath(xpath).Click();
                }

                return true;
            }
            catch (MissingHtmlException)
            {
                return false;
            }
        }

        /// <summary>
        /// Modifies attribute on an element on the HTML page
        /// </summary>
        /// <param name="element"></param>
        /// <param name="broSession"></param>
        /// <param name="attribute"></param>
        /// <param name="value"></param>
        public static void SetInputElementAttribute(this BrowserSession session, ElementScope element, string attribute, string value)
        {
            session.ExecuteScript(
                @"arguments[0].getElementsByTagName(""input"")[0].setAttribute(arguments[1], arguments[2]);", element, attribute, value);
        }

        /// <summary>
        /// Fills autocomplete in CBRIS application
        /// </summary>
        /// <param name="session"></param>
        /// <param name="text"></param>
        /// <param name="element"></param>
        public static void FillAutoComplete(this BrowserSession session, string text, ElementScope element)
        {
            session.DoubleClick(element);
            session.FindXPath("//input[@class='select2-search__field']").FillInWithDelayedKeyPresses(text);
            session.FindXPath($"//ul[@class='select2-results__options']//*[text()='{text}']").Click();
        }
    }
}
