﻿using System;
using System.Diagnostics;
using System.Linq;
using Coypu;

namespace Cbris.Coypu.Handlers
{
    public class DataGridHandler
    {
        private BrowserSession _session;
        protected ElementScope LoadingOverlay => _session.FindXPath("//span[@class='ag-overlay-loading-center']");
        protected ElementScope Grid => _session.FindXPath("//power-grid[@options.bind='options']");

        public DataGridHandler(BrowserSession session)
        {
            _session = session;
        }

        /// <summary>
        /// Given a col-id return the number of row existing on the grid which have a column with that col id.
        /// </summary>
        /// <param name="colid"></param>
        /// <returns></returns>
        public int GetRowCountByType(int colid)
        {
            try
            {
                return _session.FindAllXPath($"//div[@col-id='{colid}' and @role='gridcell']", col => col.Any()).Count();
            }
            catch(MissingHtmlException)
            {
                return 0;
            }
        }
        

        /// <summary>
        /// Check if the data GRID on Activities Page is ready after a timeout (default 15 seconds).
        /// </summary>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public bool IsGridLoaded(int timeout = 15)
        {
            Stopwatch sw = new Stopwatch();
            bool loading = true;
            sw.Start();

            while (loading && sw.Elapsed < TimeSpan.FromSeconds(timeout))
            {
                loading = LoadingOverlay.ExistOnPage();
            }

            return !loading;
        }

        /// <summary>
        /// Check if a section of the GRID is currently displaying at least one row of data.
        /// </summary>
        /// <param name="gridsection"></param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public bool AreDataDisplayed(ElementScope gridsection, int timeout = 15)
        {
            Stopwatch sw = new Stopwatch();
            bool exist = false;
            sw.Start();

            while (!exist && sw.Elapsed < TimeSpan.FromSeconds(timeout))
            {
                exist = gridsection.FindXPath(".//div[@role='row' and @row-index='2']").ExistOnPage();
            }

            return exist;
        }

        #region AG-GRID API
        public void ScrollToGridRowByColumnId(string columnId)
        {
            try
            {
                _session.ExecuteScript($"document.getElementsByTagName('power-grid')[1].au.controller.scope.bindingContext.gridApi.gridApi.ensureColumnVisible('{columnId}')");
            }
            catch(OpenQA.Selenium.WebDriverException)
            {
                _session.ExecuteScript($"document.getElementsByTagName('power-grid')[1].au.controller.scope.bindingContext.powerGridApi.gridApi.ensureColumnVisible('{columnId}')");
            }
        }

        public void ScrollToRowIndex(int index)
        {
            _session.ExecuteScript($"document.getElementsByTagName('power-grid')[1].au.controller.scope.bindingContext.gridApi.gridApi.ensureIndexVisible({index})");
        }

        public void ScrollToGridRowByColumnId(int columnId)
        {
            ScrollToGridRowByColumnId(columnId.ToString());
        }

        public void MoveToNextTab()
        {
            _session.ExecuteScript("document.getElementsByTagName('power-grid')[1].au.controller.scope.bindingContext.gridApi.gridApi.tabToNextCell()");
        }
        #endregion

        public ElementScope ReturnRowAtIndex(ElementScope gridsection, int index)
        {
            return gridsection.FindXPath($".//div[@role='row' and @row-index='{index + 1}']");
        }

        public ElementScope ReturnColumnWithId(ElementScope row, int id)
        {
            return row.FindXPath($"./div[@col-id='{id}']");
        }
    }
}
