﻿using System;

namespace Cbris.Coypu
{

    [Serializable]
    public class LoadingTimeoutException : Exception
    {
        public LoadingTimeoutException() { }
        public LoadingTimeoutException(string message) : base(message) { }
        public LoadingTimeoutException(string message, Exception inner) : base(message, inner) { }
    }

}
