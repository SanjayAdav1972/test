﻿using Cbris.Coypu.Common;
using Clarksons.Automation.TestReporting.Utility;
using Coypu;
using System;

namespace Cbris.Coypu.PageObjects.Modules
{
    public class OperationsModule : PageObject
    {
        public OperationsModule(BrowserSession browserSession) => _browserSession = browserSession;

        #region LAYOUT SECTION
        protected ElementScope LayoutSelector => _browserSession.FindXPath("//select[@value.bind='selectedGridState']");
        protected ElementScope LayoutOperationsBtn => _browserSession.FindXPath("//div[@class='layoutBtns']//button");
        protected ElementScope SaveGridBtn => _browserSession.FindXPath("//ul[@id='dropDownMenu']/li[text()='Save As New']");
        #endregion

        public void SaveGridState(string name)
        {
            LayoutOperationsBtn.Click();
            ScreenCapture.Instance.TakeScreenshot($"SaveLayout{Tools.GenerateRandomInt()}_1.jpg");
            SaveGridBtn.Click();
            ScreenCapture.Instance.TakeScreenshot($"SaveLayout{Tools.GenerateRandomInt()}_2.jpg");
            FillAndAcceptDialog(name);
            ScreenCapture.Instance.TakeScreenshot($"SaveLayout{Tools.GenerateRandomInt()}_3.jpg");
        }

        public bool DoesLayoutExist(string name) => LayoutSelector.FindXPath($"./option[text()='{name}']").Exists();
        public void SelectLayoutOption(string name) => LayoutSelector.SelectOption(name);

        public bool UpdateSuccessful()
        {
            try
            {
               return _browserSession.FindXPath("//div[@id='toast-container']/div[2]/div").Text.Trim().Equals("update successful", StringComparison.OrdinalIgnoreCase);
            }
            catch (MissingHtmlException)
            {
                return false;
            }
        }
    }
}
