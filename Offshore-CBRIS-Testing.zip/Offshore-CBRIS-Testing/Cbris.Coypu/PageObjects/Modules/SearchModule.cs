﻿using Cbris.Coypu.Common;
using Clarksons.Automation.TestReporting.Utility;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Diagnostics;
using System.Linq;

namespace Cbris.Coypu.PageObjects.Modules
{
    public class SearchModule : PageObject
    {

        public SearchModule(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        protected ElementScope SearchGridContainer => _browserSession.FindXPath("//power-grid[@grid-name='grid.name']/div");

        protected ElementScope SaveSearchBtn => _browserSession.FindXPath("//button[@title='Save Search']");
        protected ElementScope SearchSelector => _browserSession.FindXPath("//select[@value.bind='fleetId']");

        #region MOST USED SEARCH FIELDS
        protected ElementScope ByName => _browserSession.FindXPath("//div[span/div[@title='Name']]/following-sibling::div");
        protected ElementScope ByIMO => _browserSession.FindXPath("//div[span/div[@title='IMO']]/following-sibling::div");
        #endregion

        public void Reset()
        {
            _browserSession.FindXPath("//button[@title='Reset Search']").Click();
        }

        public void ClearSection(string sectionname)
        {
            var sectionField = _browserSession.FindXPath($"//div[span/div[@title='{sectionname}']]/following-sibling::div");
            sectionField.Click();
            try
            {
                var listitem= _browserSession.FindAllXPath("//span[@class='multi-select2-close']", x => x.Count() >= 1);
                foreach (var item in listitem)
                    item.Click();
            }
            catch (MissingHtmlException)
            {
                return;
            }
        }

        public bool IsReady() => SearchGridContainer.Exists();

        public bool DoesSearchExist(string name) => SearchSelector.FindXPath($"./option[contains(text(),'{name}')]").Exists();

        public void SelectSearchOption(string name) => SearchSelector.SelectOption(name);

        public void SaveSearchAsNew(string name)
        {
            SaveSearchBtn.Click();
            ScreenCapture.Instance.TakeScreenshot($"SaveSearch{Tools.GenerateRandomInt()}_1.jpg");
            _browserSession.FindXPath("//li[@click.trigger='createPrivateSearch()']").Click();
            ScreenCapture.Instance.TakeScreenshot($"SaveSearch{Tools.GenerateRandomInt()}_2.jpg");
            FillAndAcceptDialog(name);
            ScreenCapture.Instance.TakeScreenshot($"SaveSearch{Tools.GenerateRandomInt()}_3.jpg");
        }

        public void SearchVesselByName(string name)
        {
            SelectSearchOption("All");
            ClearSection("Zone");
            ByName.Click();
            ByName.FindXPath("./input").FillInWith(name).SendKeys(Keys.Enter);
            WaitForSearchToComplete();
        }

        public void SearchVesselByIMO(string imo)
        {
            SelectSearchOption("All");
            ClearSection("Zone");
            ByIMO.Click();
            ByIMO.FindXPath("./input").FillInWith(imo).SendKeys(Keys.Enter);
            WaitForSearchToComplete();
        }

        private void WaitForSearchToComplete()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            bool loading = true;
            while (sw.Elapsed <= TimeSpan.FromSeconds(60) && loading)
            {
                try
                {
                    loading = _browserSession.FindXPath("//loading-bar").ExistClickable();
                }
                catch (WebDriverException)
                {
                    return;
                }
            }
        }
    }
}
