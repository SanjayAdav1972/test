﻿using Cbris.Coypu.Common;
using Cbris.Coypu.PageObjects.Pages;
using Cbris.Coypu.PageObjects.PopUps;
using Cbris.Coypu.PageObjects.Modules;

namespace Cbris.Coypu.PageObjects
{
    public static class PagesCollection
    {
        #region GRIDS
        public static ActivitiesGrid ActivitiesPage => new ActivitiesGrid(Browser.BrowserSession);
        public static RequirementsGrid RequirementsPage => new RequirementsGrid(Browser.BrowserSession);
        public static FixturesGrid FixturesPage => new FixturesGrid(Browser.BrowserSession);
        public static VesselsGrid VesselsPage => new VesselsGrid(Browser.BrowserSession);
        public static OffersGrid OffersPage => new OffersGrid(Browser.BrowserSession);
        #endregion

        #region POPUPS
        public static VesselInfoPopUp VesselInfoPopUp => new VesselInfoPopUp(Browser.BrowserSession);
        #endregion

        #region MODULES
        public static SearchModule SearchModule => new SearchModule(Browser.BrowserSession);
        public static OperationsModule OperationsModule => new OperationsModule(Browser.BrowserSession);
        #endregion
    }
}
