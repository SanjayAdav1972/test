﻿using Cbris.Coypu.Common;
using Cbris.Coypu.Handlers;
using Cbris.Models.Data;
using Clarksons.Automation.TestReporting.Utility;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Diagnostics;
using System.Linq;

namespace Cbris.Coypu.PageObjects.Pages
{
    public class ActivitiesGrid : GridPage
    {
        public ActivitiesGrid(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        protected ElementScope RightPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Activity']//div[@class='ag-pinned-right-cols-viewport']");
        protected ElementScope LeftPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Activity']//div[@class='ag-pinned-left-cols-viewport']");
        protected ElementScope CentralGridViewPort => _browserSession.FindXPath("//power-grid[@grid-name='Activity']//div[@class='ag-body-viewport-wrapper']");


        protected ElementScope SearchGrid => _browserSession.FindXPath("//power-grid[@grid-name='grid.name']//div[@class='ag-body-viewport-wrapper']");

        public void Open() => _browserSession.FindXPath("//a[@title='Activities']").Click();

        public void AddFixture(ElementScope elementScope)
        {
            _browserSession.RightClick(elementScope);

            _browserSession.FindXPath("//span[text()='Add or Edit Fixtures']").Click();
        }

       

        /// <summary>
        /// Check if at least one row is available inside the GRID (default timeout 15 seconds).
        /// </summary>
        /// <returns></returns>
        public bool AreDataDisplayed() => new DataGridHandler(_browserSession).AreDataDisplayed(CentralGridViewPort);

        public string SetVesselVerified(string vesselIndex)
        {
            _browserSession.RightClick(_browserSession.FindXPath($"//div[@row-index='{vesselIndex}']//div[@col-id='524']", Options.First));

            ActivitiesSubMenu submenu = new ActivitiesSubMenu(_browserSession);
            submenu.SetAsVerifiedOption.Click();

            return DateTime.Now.ToString("dd MMM yy HH:mm");
        }

        public void SetVesselAvailableNow(string vesselIndex)
        {
            DataGridHandler gridHandler = new DataGridHandler(_browserSession);
            gridHandler.ScrollToGridRowByColumnId("454");

            _browserSession.RightClick(_browserSession.FindXPath($"//div[@row-index='{vesselIndex}']//div[@col-id='454']", Options.First));

            ActivitiesSubMenu submenu = new ActivitiesSubMenu(_browserSession);
            submenu.SetAsAvailableNowOption.Click();
        }

        public void AddNewActivityForVesselWithName(string name, ActivityObject newActivityData)
        {
            var vessel = ReturnFirstVesselWithName(name);
            _browserSession.RightClick(vessel);

            ActivitiesSubMenu submenu = new ActivitiesSubMenu(_browserSession);
            submenu.NewActivityOption.Click();

            ActivityDetail activitydetail = new ActivityDetail(_browserSession);
            activitydetail.FillActivityFields(newActivityData);
        }



        public string AddNewActivityForVesselAtIndex(string index, ActivityObject newActivityData)
        {
            _browserSession.RightClick(_browserSession.FindXPath($"//div[@row-index='{index}']//div[@col-id='524']", Options.First));

            ActivitiesSubMenu submenu = new ActivitiesSubMenu(_browserSession);
            submenu.NewActivityOption.Click();

            ActivityDetail activitydetail = new ActivityDetail(_browserSession);
            return activitydetail.FillActivityFields(newActivityData);
        }

        /// <summary>
        /// Selects from the list of vessel, a vessel which have an Activity different than AVAILABLE
        /// </summary>
        /// <returns></returns>
        public string SelectVesselWithActivities()
        {
            int rowindex = 2;
            bool found = false;
            DataGridHandler gridHandler = new DataGridHandler(_browserSession);
            gridHandler.ScrollToGridRowByColumnId("454");
            while (!found)
            {
                if (rowindex > 20)
                {
                    gridHandler.ScrollToRowIndex(rowindex + 5);
                }

                found = !CheckFieldOnGrid(rowindex.ToString(), "AVAILABLE", 454, true);

                if (!found)
                {
                    rowindex++;
                }
            }

            return rowindex.ToString();
        }

        /// <summary>
        /// Selects from the list of vessel, a vessel which have only AVAILABLE activities
        /// </summary>
        /// <returns></returns>
        public string SelectVesselWithNoActivities()
        {
            int rowindex = 2;
            bool found = false;
            DataGridHandler gridHandler = new DataGridHandler(_browserSession);
            gridHandler.ScrollToGridRowByColumnId("T0");
            while (!found)
            {
                if (rowindex > 20)
                {
                    gridHandler.ScrollToRowIndex(rowindex + 5);
                }

                var activities = _browserSession.FindAllXPath($"//div[@row-index='{rowindex}']//div[@col-id='T0']//a");

                if (activities.Count() >= 1)
                {
                    found = activities.All(a => a.Text.Equals("Available", StringComparison.OrdinalIgnoreCase));
                }

                if (!found)
                {
                    rowindex++;
                }
            }

            return rowindex.ToString();
        }

        public ElementScope SelectVesselFromList(int index)
        {
            return _browserSession.FindXPath($"//div[@row-index='{index}']//div[@col-id='524']");
        }

        public ActivityObject EditActivityAtIndex(string index, ActivityObject newAct, ActivityObject oldAct)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            grid.ScrollToGridRowByColumnId("T0");

            if (DoesActivityExistsAtIndex(index, oldAct) == false)
            {
                throw new ActivityNotFoundException($"Activity with values {oldAct.ToString()} not found!");
            }

            var identifier = oldAct.Status.ToUpper() + " " + oldAct.Comment;
            _browserSession.FindXPath($"//div[@row-index='{index}']//div[@col-id='T0']//a[text() = '{identifier}']").Click();

            ActivityDetail activityDetail = new ActivityDetail(_browserSession);
            activityDetail.FillActivityFields(newAct);

            if (string.IsNullOrWhiteSpace(newAct.Comment))
            {
                newAct.Comment = oldAct.Comment;
            }

            return newAct;
        }
        #region CHECK FIELDS 

        public bool CheckFieldOnGrid(string vesselIndex, string value, int gridId, bool equality = false)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            grid.ScrollToGridRowByColumnId(gridId);
            var gridvalue = _browserSession.FindXPath($"//div[@row-index='{vesselIndex}']//div[@col-id='{gridId}']/span/div").Text;

            if (equality)
            {
                return gridvalue.Equals(value, StringComparison.OrdinalIgnoreCase);
            }
            else
            {
                return gridvalue.Contains(value);
            }
        }
        #endregion

        private bool DoesActivityExistsAtIndex(string index, ActivityObject activity)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            grid.ScrollToGridRowByColumnId("T0");

            var identifier = activity.Status.ToUpper() + " " + activity.Comment;
            return _browserSession.FindXPath($"//div[@row-index='{index}']//div[@col-id='T0']//a[text() = '{identifier}']").Exists();
        }

        /// <summary>
        /// Checks if the activity has been successfully created.
        /// </summary>
        /// <param name="activity"></param>
        /// <returns></returns>
        public bool IsActivityCreatedAtIndex(string index, ActivityObject activity) => DoesActivityExistsAtIndex(index, activity);

        /// <summary>
        /// Checks if the activity has been successfully deleted.
        /// </summary>
        /// <param name="activity"></param>
        /// <returns></returns>
        public bool IsActivityDeleted(string index, ActivityObject activity)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            bool deleted = !IsActivityCreatedAtIndex(index, activity);
            while (sw.Elapsed < TimeSpan.FromSeconds(60) && !deleted)
            {
                deleted = !DoesActivityExistsAtIndex(index, activity);
            }

            return deleted;
        }

        public void DeleteActivity(ActivityObject activity)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            grid.ScrollToGridRowByColumnId("T0");

            var identifier = activity.Status.ToUpper() + " " + activity.Comment;
            _browserSession.RightClick(_browserSession.FindXPath($"//a[text()='{identifier}']"));
            ActivitiesSubMenu activitiesSubMenu = new ActivitiesSubMenu(_browserSession);
            activitiesSubMenu.DeleteActivityOption.Click();
            ClickDeleteBtn();
        }

        /// <summary>
        /// Open vessel details for a row at specific index
        /// </summary>
        /// <param name="index"></param>
        public void OpenVesselInfoAtIndex(int index)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            var row = grid.ReturnRowAtIndex(LeftPinnedColumns, index);
            //vessel name is col-id=524
            var col = grid.ReturnColumnWithId(row, 524);

            col.FindXPath(".//a").Click();
        }

        public bool IsVesselDisplayed(string name)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            int rows = grid.GetRowCountByType(524);
            int index = 1;
            bool valid = true;
            var col = grid.ReturnColumnWithId(grid.ReturnRowAtIndex(LeftPinnedColumns, index), 524);

            if (rows == 0)
            {
                return false;
            }

            while (index <= rows)
            {
                if (col.FindXPath(".//a").Text.Trim().Equals(name, StringComparison.OrdinalIgnoreCase) == false &&
                    col.FindXPath(".//a").Text.Trim().Equals(string.Empty) == false)
                {
                    valid = false;
                    col.Highlight();
                    ScreenCapture.Instance.TakeScreenshot($"ValidateVessel{Tools.GenerateRandomInt()}.jpg");
                }
                index++;
            }

            return valid;
        }

        /// <summary>
        /// Return the Vessel Name Column ElementScope object corresponding to the passed name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private ElementScope ReturnFirstVesselWithName(string name)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            int rows = grid.GetRowCountByType(524);
            int index = 1;

            var col = grid.ReturnColumnWithId(grid.ReturnRowAtIndex(LeftPinnedColumns, index), 524);

            while (index <= rows)
            {
                if (col.FindXPath(".//a").Text.Trim().Equals(name, StringComparison.OrdinalIgnoreCase) ||
                    col.FindXPath(".//a").Text.Trim().Equals(string.Empty))
                {
                    return col;
                }

                index++;
            }

            return null;
        }
    }

    internal class ActivitiesSubMenu
    {
        private readonly BrowserSession _session;
        internal ActivitiesSubMenu(BrowserSession session) => _session = session;

        internal ElementScope NewActivityOption => _session.FindXPath("//div[@class='ag-menu']//div[span[text()='New Activity']]");
        internal ElementScope DeleteActivityOption => _session.FindXPath("//div[@class='ag-menu']//div[span[text()='Delete Activity']]");
        internal ElementScope SetAsVerifiedOption => _session.FindXPath("//div[@class='ag-menu']//div[span[text()='Set as Verified']]");
        internal ElementScope SetAsAvailableNowOption => _session.FindXPath("//div[@class='ag-menu']//div[span[text()='Set Available Now']]");
    }

    internal class ActivityDetail
    {
        private readonly BrowserSession _session;
        internal ActivityDetail(BrowserSession session) => _session = session;

        internal ElementScope LocationPort => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='Location Port']]/following-sibling::div");
        internal ElementScope From => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='From']]/following-sibling::div");
        internal ElementScope To => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='To']]/following-sibling::div");
        internal ElementScope DurationType => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='Duration Type']]/following-sibling::div");
        internal ElementScope Duration => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='Duration']]/following-sibling::div");
        internal ElementScope Status => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='Status']]/following-sibling::div");
        internal ElementScope Comment => _session.FindXPath("//power-grid[@grid-name='ActivityDetail']//div[span/div[@title='Comment']]/following-sibling::div");

        internal ElementScope SaveBtn => _session.FindXPath("//ai-dialog-footer//Button[@title='Save']");

        internal string FillActivityFields(ActivityObject newActivityData)
        {
            _session.FillAutoComplete(newActivityData.LocationPort, LocationPort);
            From.Click().FillInWithDelayedKeyPresses(newActivityData.From).SendKeys(Keys.Enter);
            _session.FillAutoComplete(newActivityData.DurationType, DurationType);
            Duration.Click().FillInWithDelayedKeyPresses(newActivityData.Duration).SendKeys(Keys.Enter);
            _session.FillAutoComplete(newActivityData.Status, Status);

            if (string.IsNullOrEmpty(newActivityData.Comment) == false)
            {
                Comment.Click().FillInWith(newActivityData.Comment);
            }

            var todate = To.Text;

            SaveBtn.Click();

            return todate;
        }


    }

    [Serializable]
    internal class ActivityNotFoundException : Exception
    {
        public ActivityNotFoundException() { }
        public ActivityNotFoundException(string message) : base(message) { }
        public ActivityNotFoundException(string message, Exception inner) : base(message, inner) { }
    }
}
