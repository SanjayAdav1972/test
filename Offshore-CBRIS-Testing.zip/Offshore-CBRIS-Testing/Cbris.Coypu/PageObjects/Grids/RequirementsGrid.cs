﻿using Cbris.Coypu.Common;
using Cbris.Coypu.Handlers;
using Cbris.Models.Data;
using Clarksons.Automation.Support.Utility;
using Clarksons.Automation.TestReporting.Utility;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Cbris.Coypu.PageObjects.Pages
{
    public class RequirementsGrid : GridPage
    {
        public RequirementsGrid(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region REQUIREMENTS COLID CONST
        private readonly Dictionary<string, int> requirementscolid = new Dictionary<string, int>() {
            { "Area", 411 },
            { "Country", 410 },
            { "Type", 414 },
            { "Job", 408 },
            { "Charterer", 409 },
            { "VesselType", 412 },
            { "StartDate", 406 },
            { "Range", 429 },
            { "DurationType", 428 },
            { "EndDate", 407 }
        };
        #endregion

        protected ElementScope RightPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Requirement']//div[@class='ag-pinned-right-cols-viewport']");
        protected ElementScope LeftPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Requirement']//div[@class='ag-pinned-left-cols-viewport']");
        protected ElementScope CentralGridViewPort => _browserSession.FindXPath("//power-grid[@grid-name='Requirement']//div[@class='ag-body-viewport-wrapper']");
        protected ElementScope AddRequirement => _browserSession.FindXPath("//button[@title='Add New Row']");
        protected ElementScope SaveBtn => _browserSession.FindXPath("//button[@title='Save Changes']");

        private string GetNewRowIndex() => _browserSession.FindXPath("//div[div/span/i[@class='fa fa-asterisk']]").GetAttributeValue("row-index");


        public void Open() => _browserSession.FindXPath("//a[@title='Requirements']").Click();

        /// <summary>
        /// Check if at least one row is available inside the GRID (default timeout 15 seconds).
        /// </summary>
        /// <returns></returns>
        public bool AreDataDisplayed() => new DataGridHandler(_browserSession).AreDataDisplayed(CentralGridViewPort);

        public string AddNewRequirement(RequirementObject requirement)
        {
            AddRequirement.Click();

            string rowindex = GetNewRowIndex();

            DataGridHandler grid = new DataGridHandler(_browserSession);

            var properties = typeof(RequirementObject).GetProperties();

            foreach (var prop in properties)
            {
                var field = prop.Name;
                var coldid = requirementscolid.SingleOrDefault(x => x.Key.Equals(field, System.StringComparison.OrdinalIgnoreCase)).Value;
                var req = (string)requirement.GetPropertyValue(field);
                var webfield = _browserSession.FindXPath($"//div[@row-index='{rowindex}']/div[@col-id='{coldid}']");
                grid.ScrollToGridRowByColumnId(coldid);
                _browserSession.DoubleClick(webfield);

                try
                {
                    _browserSession.FindXPath("//input[@class='select2-search__field']").FillInWithDelayedKeyPresses(req, Options.NoWait, 300);
                    _browserSession.FindXPath("//input[@class='select2-search__field']").SendKeys(Keys.ArrowDown, Options.NoWait);
                    _browserSession.FindXPath("//input[@class='select2-search__field']").SendKeys(Keys.Enter, Options.NoWait);
                }
                catch (MissingHtmlException)
                {
                    webfield.FindXPath(".//input", Options.First).FillInWith(req);
                    webfield.FindXPath(".//input", Options.First).SendKeys(Keys.Enter);
                }

            }

            SaveBtn.Click();

            return rowindex;
        }

        public bool VerifyRequirementExist(RequirementObject requirement, string rowindex)
        {
            bool valid = true;
            DataGridHandler grid = new DataGridHandler(_browserSession);
            DateTime startdate;
            var properties = typeof(RequirementObject).GetProperties();

            foreach (var prop in properties)
            {
                var field = prop.Name;
                var coldid = requirementscolid.SingleOrDefault(x => x.Key.Equals(field, System.StringComparison.OrdinalIgnoreCase)).Value;
                var req = (string)requirement.GetPropertyValue(field);
                grid.ScrollToGridRowByColumnId(coldid);
                var webfield = _browserSession.FindXPath($"//div[@row-index='{rowindex}']/div[@col-id='{coldid}']");

                if (DateTime.TryParseExact(req, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out startdate))
                {
                    req = startdate.ToString("dd MMM yy");
                }

                if (!webfield.FindXPath("./span").Text.Contains(req))
                {
                    valid = false;
                    webfield.Highlight();
                    ScreenCapture.Instance.TakeScreenshot($"ValidateRequirements{Clarksons.Automation.TestReporting.Utility.Tools.GenerateRandomInt()}.jpg");
                }
            }

            return valid;
        }
    }
}
