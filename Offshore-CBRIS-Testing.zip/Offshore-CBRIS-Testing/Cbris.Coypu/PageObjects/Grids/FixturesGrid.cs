﻿using Cbris.Coypu.Common;
using Cbris.Coypu.Handlers;
using Cbris.Models.Data;
using Clarksons.Automation.Support.Utility;
using Clarksons.Automation.TestReporting.Utility;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Cbris.Coypu.PageObjects.Pages
{
    public class FixturesGrid : GridPage
    {
        public FixturesGrid(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region REQUIREMENTS COLID CONST
        private readonly Dictionary<string, int> requirementscolid = new Dictionary<string, int>() {
            { "Port", 651 },
            { "Vessel", 636 },
            { "Type", 637 },
            { "Job", 643 },
            { "Charterer", 638 },
            { "StartDate", 641 },
            { "Range", 640 },
            { "DurationType", 639 },
            { "EndDate", 642 }
        };
        #endregion

        protected ElementScope RightPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreFixture']//div[@class='ag-pinned-right-cols-viewport']");
        protected ElementScope LeftPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreFixture']//div[@class='ag-pinned-left-cols-viewport']");
        protected ElementScope CentralGridViewPort => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreFixture']//div[@class='ag-body-viewport-wrapper']");
        protected ElementScope AddFixture => _browserSession.FindXPath("//button[@title='Add New Row']");
        protected ElementScope SaveBtn => _browserSession.FindXPath("//button[@title='Save Changes']");


        private string GetNewRowIndex() => _browserSession.FindXPath("//div[div/span/i[@class='fa fa-asterisk']]").GetAttributeValue("row-index");

        public void Open() => _browserSession.FindXPath("//a[@title='Fixtures']").Click();

        /// <summary>
        /// Check if at least one row is available inside the GRID (default timeout 15 seconds).
        /// </summary>
        /// <returns></returns>
        public bool AreDataDisplayed() => new DataGridHandler(_browserSession).AreDataDisplayed(CentralGridViewPort);

        public string AddNewFixture(FixtureObject requirement)
        {
            AddFixture.Click();

            string rowindex = GetNewRowIndex();

            DataGridHandler grid = new DataGridHandler(_browserSession);

            var properties = typeof(FixtureObject).GetProperties();

            foreach (var prop in properties)
            {
                var field = prop.Name;
                var coldid = requirementscolid.SingleOrDefault(x => x.Key.Equals(field, System.StringComparison.OrdinalIgnoreCase)).Value;
                var fixt = (string)requirement.GetPropertyValue(field);
                if (fixt != null)
                {
                    grid.ScrollToGridRowByColumnId(coldid);
                    var webfield = _browserSession.FindXPath($"//div[@row-index='{rowindex}']/div[@col-id='{coldid}']");
                    webfield.Click();
                    webfield.SendKeys(Keys.Enter);
                    try
                    {
                        _browserSession.FindXPath("//input[@class='select2-search__field']").FillInWithDelayedKeyPresses(fixt, Options.NoWait, 500);
                        _browserSession.FindXPath("//input[@class='select2-search__field']").SendKeys(Keys.Enter, Options.NoWait);
                    }
                    catch (MissingHtmlException)
                    {
                        webfield.FindXPath(".//input", Options.First).FillInWith(fixt);
                        webfield.FindXPath(".//input", Options.First).SendKeys(Keys.Enter);
                    }
                }
            }

            SaveBtn.Click();

            return rowindex;
        }

        public bool VerifyFixtureExist(FixtureObject fixture, string rowindex)
        {
            bool valid = true;
            DataGridHandler grid = new DataGridHandler(_browserSession);
            DateTime startdate;
            var properties = typeof(FixtureObject).GetProperties();

            foreach (var prop in properties)
            {
                var field = prop.Name;
                var coldid = requirementscolid.SingleOrDefault(x => x.Key.Equals(field, System.StringComparison.OrdinalIgnoreCase)).Value;
                var fixt = (string)fixture.GetPropertyValue(field);
                grid.ScrollToGridRowByColumnId(coldid);
                var webfield = _browserSession.FindXPath($"//div[@row-index='{rowindex}']/div[@col-id='{coldid}']");

                if(DateTime.TryParseExact(fixt,"dd-MM-yyyy",CultureInfo.InvariantCulture, DateTimeStyles.None, out startdate))
                {
                    fixt = startdate.ToString("dd MMM yy");
                }

                if (!webfield.FindXPath("./span").Text.Contains(fixt))
                {
                    valid = false;
                    webfield.Highlight();
                    ScreenCapture.Instance.TakeScreenshot($"ValidateRequirements{Clarksons.Automation.TestReporting.Utility.Tools.GenerateRandomInt()}.jpg");
                }
            }

            return valid;
        }
    }
}
