﻿using Cbris.Coypu.Common;
using Cbris.Coypu.Handlers;
using Coypu;

namespace Cbris.Coypu.PageObjects.Pages
{
    public class OffersGrid : GridPage
    {
        public OffersGrid(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        protected ElementScope RightPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Offer']//div[@class='ag-pinned-right-cols-viewport']");
        protected ElementScope LeftPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='Offer']//div[@class='ag-pinned-left-cols-viewport']");
        protected ElementScope CentralGridViewPort => _browserSession.FindXPath("//power-grid[@grid-name='Offer']//div[@class='ag-body-viewport-wrapper']");

        public void Open() => _browserSession.FindXPath("//a[@title='Offers']").Click();

        /// <summary>
        /// Check if at least one row is available inside the GRID (default timeout 15 seconds).
        /// </summary>
        /// <returns></returns>
        public bool AreDataDisplayed() => new DataGridHandler(_browserSession).AreDataDisplayed(CentralGridViewPort);
    }
}
