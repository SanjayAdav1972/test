﻿using Cbris.Coypu.Common;
using Cbris.Coypu.Handlers;
using Coypu;

namespace Cbris.Coypu.PageObjects.Pages
{
    public class VesselsGrid : GridPage
    {
        public VesselsGrid(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        protected ElementScope RightPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreVessels']//div[@class='ag-pinned-right-cols-viewport']");
        protected ElementScope LeftPinnedColumns => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreVessels']//div[@class='ag-pinned-left-cols-viewport']");
        protected ElementScope CentralGridViewPort => _browserSession.FindXPath("//power-grid[@grid-name='OffshoreVessels']//div[@class='ag-body-viewport-wrapper']");

        public void OpenVesselInfoAtIndex(int index)
        {
            DataGridHandler grid = new DataGridHandler(_browserSession);
            var row = grid.ReturnRowAtIndex(LeftPinnedColumns, index);
            row.Click();
        }

        public void Open() => _browserSession.FindXPath("//a[@title='Vessels']").Click();

        /// <summary>
        /// Check if at least one row is available inside the GRID (default timeout 15 seconds).
        /// </summary>
        /// <returns></returns>
        public bool AreDataDisplayed() => new DataGridHandler(_browserSession).AreDataDisplayed(CentralGridViewPort);
    }
}
