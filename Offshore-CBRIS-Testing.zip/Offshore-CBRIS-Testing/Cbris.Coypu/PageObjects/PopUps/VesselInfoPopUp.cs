﻿using Cbris.Coypu.Common;
using Coypu;

namespace Cbris.Coypu.PageObjects.PopUps
{
    public class VesselInfoPopUp : PageObject
    {
        public VesselInfoPopUp(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        public bool IsReady()
        {
            return _browserSession.FindXPath("//section[@class='vessel__section vessel__summary clk-grid-1_sm-1']").Exists() 
                && _browserSession.FindXPath("//section[@class='vessel__section vessel__latest-fixture']").Exists();
        }
    }
}
