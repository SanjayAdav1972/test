﻿using Coypu.Drivers.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using Clarksons.Automation.Support.Setup;

namespace Cbris.Coypu.Drivers
{
    public class CoypuRemoteWebDriver : SeleniumWebDriver
    {
        public CoypuRemoteWebDriver(global::Coypu.Drivers.Browser browser, ICapabilities capabilities)
            : base(CustomWebDriver(capabilities), browser)
        {

        }

        private static RemoteWebDriver CustomWebDriver(ICapabilities capabilities)
        {
            var remoteAppHost = new System.Uri(Settings.WebdriverUri);
            return new RemoteWebDriver(remoteAppHost, capabilities);
        }
    }
}
