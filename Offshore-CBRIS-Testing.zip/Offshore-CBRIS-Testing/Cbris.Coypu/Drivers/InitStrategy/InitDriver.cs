﻿using Coypu;

namespace Cbris.Coypu.Drivers.InitStrategy
{
    public interface IInitDriver
    {
        bool CanInit(string configuration);
        BrowserSession Init();
    }
}
