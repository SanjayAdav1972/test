﻿using System;
using Coypu;
using OpenQA.Selenium.Chrome;

namespace Cbris.Coypu.Drivers.InitStrategy
{
    public class InitRemoteWebDriver : IInitDriver
    {
        public bool CanInit(string configuration)
        {
            return configuration.Equals("RemoteWebDriver", StringComparison.OrdinalIgnoreCase);
        }

        public BrowserSession Init()
        {
            var _sessionConfiguration = new SessionConfiguration()
            {
                Driver = typeof(CoypuRemoteWebDriver),
                Timeout = TimeSpan.FromSeconds(30)
            };
            //adding capabilities for remote connection
            var chromeOptions = new ChromeOptions();
            chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
            var chromeCapabilities = chromeOptions.ToCapabilities();
            var remoteDriverCh = new CoypuRemoteWebDriver(global::Coypu.Drivers.Browser.Chrome, chromeCapabilities);
            return new BrowserSession(_sessionConfiguration, remoteDriverCh);
        }
    }
}
