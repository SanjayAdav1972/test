﻿using System;
using Coypu;

namespace Cbris.Coypu.Drivers.InitStrategy
{
    public class InitLocalWebDriver : IInitDriver
    {
        public bool CanInit(string configuration)
        {
            return configuration.Equals("LocalWebDriver", StringComparison.OrdinalIgnoreCase);
        }

        public BrowserSession Init()
        {
            var sessionConfiguration = new SessionConfiguration()
            {
                Browser = global::Coypu.Drivers.Browser.Chrome,
                Timeout = TimeSpan.FromSeconds(10),
                Port = 43
            };
            return new BrowserSession(sessionConfiguration);
        }
    }
}
