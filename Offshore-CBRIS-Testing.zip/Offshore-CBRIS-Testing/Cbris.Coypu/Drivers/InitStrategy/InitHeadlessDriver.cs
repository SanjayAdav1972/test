﻿using System;
using Coypu;

namespace Cbris.Coypu.Drivers.InitStrategy
{
    public class InitHeadlessDriver : IInitDriver
    {
        public bool CanInit(string configuration)
        {
            return configuration.Equals("HeadlessDriver", StringComparison.OrdinalIgnoreCase);
        }

        public BrowserSession Init()
        {
           var _sessionConfiguration = new SessionConfiguration()
            {
                Timeout = TimeSpan.FromSeconds(30),
                Driver = typeof(HeadlessChromeDriver),
                Browser = global::Coypu.Drivers.Browser.Chrome
            };
            return new BrowserSession(_sessionConfiguration);
        }
    }
}
