﻿using Coypu.Drivers.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Chrome;

namespace Cbris.Coypu.Drivers
{
    public class HeadlessChromeDriver : SeleniumWebDriver
    {
        public HeadlessChromeDriver(global::Coypu.Drivers.Browser browser)
            : base(CustomProfile(), browser)
        {

        }

        private static RemoteWebDriver CustomProfile()
        {
            var chromeOptions = new ChromeOptions();
            chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
            chromeOptions.AddArgument("--headless");
            chromeOptions.AddArgument("--window-size=1920,1080");
            chromeOptions.UnhandledPromptBehavior = OpenQA.Selenium.UnhandledPromptBehavior.Dismiss;

            return new ChromeDriver(chromeOptions);
        }
    }
}
