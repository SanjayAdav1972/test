﻿using Coypu;
using Clarksons.Automation.Support.Setup;
using System.Collections.Generic;
using Cbris.Coypu.Drivers.InitStrategy;
using System.Linq;

namespace Cbris.Coypu.Common
{
    public static class Browser
    {

        private static BrowserSession _browserSession;
        public static BrowserSession BrowserSession { get { return _browserSession; } }

        private static List<IInitDriver> _driverinit = new List<IInitDriver>()
        {
            new InitHeadlessDriver(),
            new InitLocalWebDriver(),
            new InitRemoteWebDriver()
        };

        public static string Title
        {
            get
            {
                return _browserSession.Title;
            }
        }

        public static void Goto(string url)
        {
            _browserSession.Visit(url);
        }

        /// <summary>
        /// Quits the browser and all windows associated with it.
        /// </summary>
        public static void Quit()
        {
            if (_browserSession != null)
            {
                _browserSession.Dispose();
            }
            _browserSession = null;

        }


        /// <summary>
        /// Opens a new browser window.
        /// </summary>
        public static void Open()
        {
            var webdriver = _driverinit.SingleOrDefault(i => i.CanInit(Settings.LocationRun));

            _browserSession = webdriver.Init();

            _browserSession.MaximiseWindow();
            _browserSession.Visit("/");

        }
    }
}
