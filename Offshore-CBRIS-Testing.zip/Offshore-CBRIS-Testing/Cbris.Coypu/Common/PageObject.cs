﻿using System;
using Coypu;
using System.Diagnostics;
using Cbris.Coypu.Handlers;
using Clarksons.Automation.TestReporting.Utility;

namespace Cbris.Coypu.Common
{
    /// <summary>
    /// This class implement all the methods used to operate on the page object
    /// The method of this class are inherited by all the page object
    /// </summary>
    public abstract class PageObject
    {
        internal static string PageTitle { get; set; }

        internal static string Url { get; set; }

        internal BrowserSession _browserSession;

        /// <summary>
        /// Checks if the browser is on the calling page.
        /// </summary>
        /// <returns>Returs true if the browser is on the page and false if it isnt.</returns>
        public bool IsAt()
        {
            return Browser.Title.Contains(PageTitle);
        }

        /// <summary>
        /// Check if the browser is on the calling page or
        /// if it is on a specific called page
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public bool IsAt(string title)
        {
            string callingPageTitle = Browser.Title.ToLower();
            string calledPageTitle = title.ToLower();
            return callingPageTitle.Contains(calledPageTitle);
        }

        public bool IsGridReady() => new DataGridHandler(_browserSession).IsGridLoaded();

        public bool IsPageReady(int timeout = 60)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            bool loading = true;
            try
            {
                while(loading && sw.Elapsed < TimeSpan.FromSeconds(timeout))
                {
                    loading = _browserSession.FindXPath("//div[@class='login-wall-container']").Exists();
                }

                return this.IsAt();
            }
            catch(MissingHtmlException)
            {
                return this.IsAt();
            }
        }

        /// <summary>
        /// Clicks on the page at coordinates x, y and using an know element as position reference.
        /// </summary>
        /// <param name="broSession"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="knowElement"></param>
        internal void ClickOnPage(int x, int y, string knowElement)
        {
            var selenium = ((OpenQA.Selenium.Remote.RemoteWebDriver)_browserSession.Native);

            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(selenium);

            builder.MoveToElement(selenium.FindElementByXPath(knowElement), x, y).Click().Build().Perform();
        }

        /// <summary>
        /// Check if the loading bar at the bottom of the page disappear after the content is loaded.
        /// </summary>
        /// <param name="timeout"></param>
        /// <returns></returns>
        internal bool IsLoadingComplete(int timeout = 60)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var cssclass = _browserSession.FindXPath("//loading-bar").GetAttributeValue("class");

            while (cssclass.Contains("aurelia-hide") == false && sw.Elapsed < TimeSpan.FromSeconds(timeout))
            {
                cssclass = _browserSession.FindXPath("//loading-bar").GetAttributeValue("class");
            }

            sw.Stop();

            if (sw.Elapsed > TimeSpan.FromSeconds(timeout))
                throw new LoadingTimeoutException($"Loading exceeded {timeout} seconds time!");

            return true;
        }

        internal void FillAndAcceptDialog(string text)
        {
            _browserSession.FindXPath("//ai-dialog-body//input").FillInWith(text);
            ScreenCapture.Instance.TakeScreenshot($"FillDialog{Clarksons.Automation.Support.Utility.Tools.GenerateRandomInt()}_1.jpg");
            _browserSession.FindXPath("//button[@click.trigger='acceptDialog()']").Click();
            ScreenCapture.Instance.TakeScreenshot($"FillDialog{Clarksons.Automation.Support.Utility.Tools.GenerateRandomInt()}_2.jpg");
        }

        internal void ClickDeleteBtn()
        {
            _browserSession.FindXPath("//ai-dialog//button[text()='Delete']").Click();
        }

    }
}
