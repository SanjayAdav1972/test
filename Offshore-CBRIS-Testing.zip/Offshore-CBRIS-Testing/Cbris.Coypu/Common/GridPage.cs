﻿using System;
using Clarksons.Automation.Support.Setup.Environment;

namespace Cbris.Coypu.Common
{
    public class GridPage : PageObject
    {
        protected GridPage()
        {
            Url = EnvironmentReader.get(GetType().Name).Url;
            PageTitle = EnvironmentReader.get(GetType().Name).PageTitle;
        }

        public void Refresh()
        {
            _browserSession.Refresh();
        }

        /// <summary>
        /// Navigates to the page URL.
        /// </summary>
        public void Goto()
        {
            try
            {
                Browser.Goto(Url);

            }
            catch (Exception e)
            {
                throw new Exception(GetType().Name + " could not be loaded. Check page url is correct in app.config." +
                                    " " + e.Message);
            }
        }

        /// <summary>
        /// Navigate to a specific url
        /// </summary>
        /// <param name="url"></param>
        public void Goto(string url)
        {
            try
            {
                Browser.Goto(url);

            }
            catch (Exception e)
            {
                throw new Exception(GetType().Name + " could not be loaded. Check passed page url is correct" +
                                    " " + e.Message);
            }
        }

        public string GetURL()
        {
            return Url;
        }

        public GridPage ModifyURL(string adding)
        {
            Url += adding;
            this.Goto();

            return this;
        }

        public void Navigate(string username, string password)
        {
            _browserSession.VisitWithAuthenticationToken(Url, username, password);
        }

        public void PickADate(DateTime date)
        {

            var day = date.ToString("dd");
            var month = date.ToString("MMMM");
            var year = date.ToString("yyyy");

        }

    }
}
