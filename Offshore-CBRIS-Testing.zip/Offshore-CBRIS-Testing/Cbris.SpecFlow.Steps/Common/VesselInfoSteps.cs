﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Enums;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Cbris.SpecFlow.Steps.Common
{
    [Binding]
    public class VesselInfoSteps
    {
        [When(@"open the vessel info of a vessel")]
        public void WhenOpenTheVesselInfoOfAVessel()
        {
            if ((SectionType)ScenarioContext.Current["SectionType"] == SectionType.Activities)
                PagesCollection.ActivitiesPage.OpenVesselInfoAtIndex(1);
            else
                PagesCollection.VesselsPage.OpenVesselInfoAtIndex(1);
        }

        [Then(@"the vessel info are available on a pop up page")]
        public void ThenTheVesselInfoAreAvailableOnAPopUpPage()
        {
            Assert.IsTrue(PagesCollection.VesselInfoPopUp.IsReady(), "Vessel info page not ready!");
        }
    }
}
