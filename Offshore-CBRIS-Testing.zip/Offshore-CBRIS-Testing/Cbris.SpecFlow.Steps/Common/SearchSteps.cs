﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Enums;
using Clarksons.Automation.Support.Utility;
using NUnit.Framework;
using TechTalk.SpecFlow;


namespace Cbris.SpecFlow.Steps.Common
{
    [Binding]
    public class SearchSteps
    {
        private string _searchname;

        [Given(@"the search is cleared")]
        public void GivenTheSearchIsCleared()
        {
            PagesCollection.SearchModule.Reset();
        }


        [Given(@"the vessel with name '(.*)' is returned on the GRID")]
        public void GivenTheVesselWithNameIsReturnedOnTheGRID(string p0)
        {
            PagesCollection.SearchModule.SearchVesselByName(p0);

            if ((SectionType)ScenarioContext.Current["SectionType"] == SectionType.Activities)
                Assert.IsTrue(PagesCollection.ActivitiesPage.IsVesselDisplayed(p0),
                    $"No matching vessels returned with the name {p0}");
            else
            {
                //TODO: for other pages which allows to search by vessel name
            }

            ScenarioContext.Current["VesselName"] = p0;
        }

        [Given(@"the vessel with that IMO is returned on the GRID")]
        public void GivenTheVesselWithThatIMOIsReturnedOnTheGRID()
        {
            PagesCollection.SearchModule.SearchVesselByIMO(ScenarioContext.Current["VesselIMO"].ToString());
            string vesselname = DAL.SQL.Scripts.VesselData.GetVesselNameFromImo(ScenarioContext.Current["VesselIMO"].ToString());

            ScenarioContext.Current["VesselName"] = vesselname;

            if ((SectionType)ScenarioContext.Current["SectionType"] == SectionType.Activities)
                Assert.IsTrue(PagesCollection.ActivitiesPage.IsVesselDisplayed(vesselname),
                    $"No matching vessels returned with the name {vesselname}");
            else
            {
                //TODO: for other pages which allows to search by vessel name
            }
        }


        [StepDefinition(@"the search is available on the page")]
        public void ThenTheSearchIsAvailableOnThePage()
        {
            Assert.IsTrue(PagesCollection.SearchModule.IsReady(), "Search section not ready!");
        }

        [When(@"the current search is saved with the name '(.*)'")]
        public void WhenTheCurrentSearchIsSavedWithTheName(string p0)
        {
            _searchname = $"{p0}-{Tools.GenerateRandomInt()}";
            PagesCollection.SearchModule.SaveSearchAsNew(_searchname);
        }

        [Then(@"the search is saved")]
        public void ThenTheSearchIsSaved()
        {
            Assert.IsTrue(PagesCollection.SearchModule.DoesSearchExist(_searchname), 
                $"Search {_searchname} not available inside the selector");

            PagesCollection.SearchModule.SelectSearchOption(_searchname);
        }

        [Then(@"the search available after the page is reloaded")]
        public void ThenTheSearchAvailableNextTimeThePageIsReloaded()
        {
            

            Assert.IsTrue(PagesCollection.SearchModule.DoesSearchExist(_searchname),
                $"Search {_searchname} not available inside the selector after page refresh");

            PagesCollection.SearchModule.SelectSearchOption(_searchname);

        }

    }
}
