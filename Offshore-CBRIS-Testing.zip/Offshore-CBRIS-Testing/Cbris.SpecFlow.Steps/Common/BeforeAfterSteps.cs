﻿using System;
using System.Linq;
using TechTalk.SpecFlow;
using System.IO;
using Clarksons.Automation.Support.Setup;
using Clarksons.Automation.TestReporting.SpecFlow;
using Clarksons.Automation.TestReporting.Services;
using NUnit.Framework;
using Clarksons.Automation.TestReporting.Utility;
using Cbris.Coypu.Common;

namespace Cbris.SpecFlow.Steps.Common
{
    [Binding]
    public class BeforeAfterStep
    {

        private static readonly string _env = Settings.Environment;

        private static string _user, _psw;

        private static int _step;

        private static TestLogger _testLogger = new TestLogger();


        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            System.Globalization.CultureInfo.CurrentCulture.ClearCachedData();

             _user = Settings.TestUser;
            //_psw = DAL.SQL.Scripts.BaseData.GetTestSettings(Settings.TestUser).Item2;
            _psw = Settings.TestPassword;

            _testLogger.User = Settings.TestUser;
            _testLogger.Environment = _env;
        }

        [BeforeFeature]
        public static void BeforeFeature()
        {
            _testLogger.AddFeature(FeatureContext.Current);
        }

        //The before and after scenario Open and Close (clean all the resources) the webDriver
        [BeforeScenario]
        public void BeforeScenario()
        {
            ScenarioContext.Current["Username"] = _user;
            ScenarioContext.Current["Password"] = _psw;

            _step = 0;

            _testLogger.AddScenarioToFeature(ScenarioContext.Current);
            _testLogger.LogScenarioStart();

            //skip the scenario if the test tag is not equal to the Environment
            if (ScenarioContext.Current.ScenarioInfo.Tags.Contains(_env))
            {
                if (!ScenarioContext.Current.ScenarioInfo.Tags.Contains("ignore"))
                    if (!ScenarioContext.Current.ScenarioInfo.Tags.Contains("ignore"))
                    {
                        Browser.Open();
                        ScreenCapture.Init(Browser.BrowserSession);
                        ScreenCapture.Instance.Subscribe(_testLogger);
                    }
            }
            else
            {
                Assert.Ignore($"Test skipped as not part of the test suite for the environment {_env}");
            }
        }

        [BeforeStep]
        public static void BeforeStep()
        {
            _testLogger.AddStepToScenario(ScenarioStepContext.Current);
        }

        [AfterStep]
        public static void AfterStep()
        {
            _step += 1;
            ScreenCapture.Instance.TakeScreenshot($"Step_{_step}" + DateTime.Now.ToString("ddMMyyyy-hhmmss") + ".jpg");

            if (ScenarioContext.Current.TestError != null)
            {
                _testLogger.ReportStepFailure();
            }
            else
                _testLogger.ReportStepPass();

            _testLogger.GroupImagesInGif(Settings.ScreenshotStoreLocation, Settings.ScreenshotArtifactLocation);
        }

        [AfterScenario(Order = 1)]
        public static void AfterScenario()
        {
            if (ScenarioContext.Current.ScenarioInfo.Tags.Contains(_env))
            {

                if (ScenarioContext.Current.TestError != null)
                {
                    var testError = ScenarioContext.Current.TestError;

                    _testLogger.AddTestOutput(testError.Message, testError.StackTrace);
                }

                //if the scenario is inconclusive
                if (ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.StepDefinitionPending ||
                    ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.UndefinedStep ||
                    ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.BindingError)
                {
                    _testLogger.MarkScenarioAsInconclusive();
                }

                if (!ScenarioContext.Current.ScenarioInfo.Tags.Contains("ignore"))
                {
                    Browser.Quit();
                }
            }

            _testLogger.LogScenarioEnd();

            _testLogger.UpdateScenarioCount();
        }


        [AfterFeature]
        public static void AfterFeature()
        {
            _testLogger.UpdateTestCount();
        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            _testLogger.CloseTestExecution();
            TestTransformer transformer = new TestTransformer(_testLogger);

            //Generate and save report
            if (!Directory.Exists(Settings.HtmlReportStoreLocation))
            {
                Directory.CreateDirectory(Settings.HtmlReportStoreLocation);
            }

            transformer.ToHtmlReport(Settings.HtmlReportStoreLocation, "Report.html");

        }
    }
}
