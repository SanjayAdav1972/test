﻿using Cbris.Coypu.PageObjects;
using Clarksons.Automation.Support.Utility;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Cbris.SpecFlow.Steps.Common
{
    [Binding]
    public class LayoutSteps
    {
        private string _layoutname;

        [When(@"the current layout is saved with the name '(.*)'")]
        public void WhenTheCurrentLayoutIsSavedWithTheName(string p0)
        {
            _layoutname = $"{p0}-{Tools.GenerateRandomInt()}";
            PagesCollection.OperationsModule.SaveGridState(_layoutname);
        }

        [Then(@"the layout is saved")]
        public void ThenTheLayoutIsSaved()
        {
            Assert.IsTrue(PagesCollection.OperationsModule.DoesLayoutExist(_layoutname),
                $"Layout {_layoutname} not available inside the selector");

            PagesCollection.OperationsModule.SelectLayoutOption(_layoutname);

        }

        [Then(@"the layout available after the page is reloaded")]
        public void ThenTheLayoutAvailableNextTimeThePageIsReloaded()
        {
            Assert.IsTrue(PagesCollection.OperationsModule.DoesLayoutExist(_layoutname),
                $"Layout {_layoutname} not available inside the selector after page refresh");

            PagesCollection.OperationsModule.SelectLayoutOption(_layoutname);
        }

    }
}
