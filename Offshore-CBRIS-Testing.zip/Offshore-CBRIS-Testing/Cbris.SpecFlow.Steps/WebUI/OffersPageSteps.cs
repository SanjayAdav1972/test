﻿using Cbris.Coypu.PageObjects;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class OffersPageSteps
    {
        [When(@"user open Offers page")]
        public void WhenUserOpenOffersPage()
        {
            PagesCollection.OffersPage.Open();
        }
        
        [StepDefinition(@"the Offers data grid is loaded")]
        public void ThenTheOffersDataGridIsLoaded()
        {
            Assert.IsTrue(PagesCollection.OffersPage.IsGridReady(), "Grid not loaded!");
        }
        
        [Then(@"the Offers data in the grid are ready")]
        public void ThenTheOffersDataInTheGridAreReady()
        {
            Assert.IsTrue(PagesCollection.OffersPage.AreDataDisplayed(), "Data not ready!");
        }
    }
}
