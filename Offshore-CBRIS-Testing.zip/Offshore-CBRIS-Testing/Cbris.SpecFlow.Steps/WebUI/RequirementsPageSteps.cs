﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Data;
using NUnit.Framework;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class RequirementsPageSteps
    {
        private RequirementObject _requirement = null;
        private string _newrowindex = string.Empty;

        [StepDefinition(@"user open Requirements page")]
        public void WhenUserOpenRequirementsPage()
        {
            PagesCollection.RequirementsPage.Open();
        }
        
        [StepDefinition(@"the Requirements data grid is loaded")]
        public void ThenTheRequirementsDataGridIsLoaded()
        {
            Assert.IsTrue(PagesCollection.RequirementsPage.IsGridReady(), "Requirements data grid not loaded!");
        }

        [StepDefinition(@"the requirement with the below data is created")]
        public void WhenTheRequirementWithTheBelowDataIsCreated(Table table)
        {
            _requirement = table.CreateInstance<RequirementObject>();

            _newrowindex = PagesCollection.RequirementsPage.AddNewRequirement(_requirement);
        }

        [Then(@"the Requirements data in the grid are ready")]
        public void ThenTheRequirementsDataInTheGridAreReady()
        {
            Assert.IsTrue(PagesCollection.RequirementsPage.AreDataDisplayed(), "Requirements data not ready!");
        }

        [Then(@"the requirement is available inside the list")]
        public void ThenTheRequirementIsAvailableInsideTheList()
        {
            Assert.IsTrue(PagesCollection.RequirementsPage.VerifyRequirementExist(_requirement, _newrowindex),
                "New requirement not displayed/created!");
        }

    }
}
