﻿using Cbris.Coypu.PageObjects;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class BaseSteps
    {
        [StepDefinition(@"user navigates to Offshore app")]
        public void GivenUserNavigatesToOffshoreApp()
        {
            PagesCollection.ActivitiesPage.Navigate(ScenarioContext.Current["Username"].ToString(),
                ScenarioContext.Current["Password"].ToString());

            Assert.IsTrue(PagesCollection.ActivitiesPage.IsPageReady(),
                "Issue on navigating to Offshore App!");
        }

        [When(@"the page is refreshed")]
        public void WhenThePageIsRefreshed()
        {
            PagesCollection.ActivitiesPage.Refresh();
        }

        [When(@"a vessel is selected from the list")]
        public void WhenAVesselIsSelectedFromTheList()
        {
            ScenarioContext.Current["VesselElement"] = PagesCollection.ActivitiesPage.SelectVesselFromList(2);
        }

    }
}
