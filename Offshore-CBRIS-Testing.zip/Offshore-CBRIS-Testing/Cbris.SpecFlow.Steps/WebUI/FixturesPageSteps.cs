﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Data;
using NUnit.Framework;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class FixturesPageSteps
    {
        private FixtureObject _fixture = null;
        private string _newrowindex = string.Empty;

        [StepDefinition(@"user open Fixtures page")]
        public void WhenUserOpenFixturesPage()
        {
            PagesCollection.FixturesPage.Open();
        }
        
        [StepDefinition(@"the Fixtures data grid is loaded")]
        public void ThenTheFixturesDataGridIsLoaded()
        {
            Assert.IsTrue(PagesCollection.FixturesPage.IsGridReady(), "Grid not loaded!");
        }

        [When(@"the Fixtures with the below data is created")]
        public void WhenTheFixturesWithTheBelowDataIsCreated(Table table)
        {
            _fixture = table.CreateInstance<FixtureObject>();
            _newrowindex = PagesCollection.FixturesPage.AddNewFixture(_fixture);
        }

        [Then(@"the Fixtures is available inside the list")]
        public void ThenTheFixturesIsAvailableInsideTheList()
        {
            Assert.IsTrue(PagesCollection.FixturesPage.VerifyFixtureExist(_fixture, _newrowindex),
                "New Fixture not displayed/created!");
        }

        [Then(@"the Fixtures data in the grid are ready")]
        public void ThenTheFixturesDataInTheGridAreReady()
        {
            Assert.IsTrue(PagesCollection.FixturesPage.AreDataDisplayed(), "Data not ready!");
        }
    }
}
