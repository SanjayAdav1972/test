﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Data;
using Cbris.Models.Enums;
using Clarksons.Automation.Support.Setup;
using Coypu;
using NUnit.Framework;
using System;
using System.Globalization;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class ActivitiesPageSteps
    {
        #region GRID ID CONST
        private const int VERIFYBY = 1782;
        private const int VERIFIEDDATE = 1781;
        private const int NEXTDATE = 466;
        private const int CURRENTSTATUS = 454;
        private const int NEXTSTATUS = 1595;
        private const int TODATE = 456;
        private const int AVAILABLE = 472;
        #endregion

        private ActivityObject _activity;
        private string _vesselIndex;
        private string _toDate;
        private string _verifiedDate;

        [StepDefinition(@"user open Activities page")]
        public void WhenUserOpenActivitiesPage()
        {
            PagesCollection.ActivitiesPage.Open();
            ScenarioContext.Current["SectionType"] = SectionType.Activities;

        }


        [StepDefinition(@"the Activities data grid is loaded")]
        public void ThenTheDataGridIsLoaded()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.IsGridReady(), "Grid not loaded after 15 seconds!");
        }

        [Given(@"a vessel with an activity different from Available is selected from the list")]
        public void GivenAVesselWithAnActivityDifferentFromAvailableIsSelectedFromTheList()
        {
            _vesselIndex = PagesCollection.ActivitiesPage.SelectVesselWithActivities();
        }

        [When(@"add fixture is selected from the right click menu")]
        public void WhenAddFixtureIsSelectedFromTheRightClickMenu()
        {
            PagesCollection.ActivitiesPage.AddFixture((ElementScope)ScenarioContext.Current["VesselElement"]);
        }

        [When(@"the vessel is set as available now")]
        public void WhenTheVesselIsSetAsAvailableNow()
        {
            PagesCollection.ActivitiesPage.SetVesselAvailableNow(_vesselIndex);
        }

        [Then(@"the current status is changed to Available")]
        public void ThenTheCurrentStatusIsChangedToAvailable()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, "AVAILABLE", CURRENTSTATUS, true));
        }

        [Then(@"the Available status should be NOW")]
        public void ThenTheAvailableStatusShouldBeNOW()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, "NOW", AVAILABLE, true));
        }


        [Then(@"the Activities data in the grid are ready")]
        public void ThenDataInTheGridAreReady()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.AreDataDisplayed(), "Data not loaded after 15 seconds!");
        }

        #region VERIFY VESSEL
        [When(@"the vessel is set to verify")]
        public void WhenTheVesselIsSetToVerify()
        {
           _verifiedDate = PagesCollection.ActivitiesPage.SetVesselVerified(_vesselIndex);
        }

        [Then(@"the verified date is updated")]
        public void ThenTheVerifiedDateIsUpdated()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, _verifiedDate, VERIFIEDDATE, true));
        }

        [Then(@"the verify by is updated with user")]
        public void ThenTheVerifyByIsUpdatedWithUser()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, Settings.TestUser, VERIFYBY, true));
        }

        #endregion

        #region ADD/EDIT/DELETE ACTIVITY
        [Given(@"the activity")]
        public void GivenTheActivity(Table table)
        {
            _activity = table.CreateInstance<ActivityObject>();
        }

        [Given(@"a vessel without Activities is selected from the list")]
        public void GivenAVesselWithoutActivitiesIsSelectedFromTheList()
        {
            _vesselIndex = PagesCollection.ActivitiesPage.SelectVesselWithNoActivities();
        }


        [When(@"the new activity is added to the vessel")]
        public void WhenANewActivityIsAddedToTheVesselWithBelowValues()
        {
            _toDate = PagesCollection.ActivitiesPage.AddNewActivityForVesselAtIndex(_vesselIndex, _activity);
        }

        [When(@"the activity is deleted")]
        public void WhenTheActivityIsDeleted()
        {
            PagesCollection.ActivitiesPage.DeleteActivity(_activity);
        }

        [When(@"the activity is edited using the data")]
        public void WhenTheActivityIsEditedUsingTheData(Table table)
        {
            var oldAct = _activity;
            _activity = PagesCollection.ActivitiesPage.EditActivityAtIndex(_vesselIndex, table.CreateInstance<ActivityObject>(), oldAct);
        }

        [Then(@"the modified activity is displayed for the vessel")]
        public void ThenTheModifiedActvityIsDisplayedForTheVessel()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.IsActivityCreatedAtIndex(_vesselIndex, _activity),
                "Activity not displayed inside the GRID");
        }


        [Then(@"the activity it is not displayed anymore for the vessel")]
        public void ThenItIsNotDisplayedAnymoreForTheVessel()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.IsActivityDeleted(_vesselIndex, _activity),
                "Activity still displayed inside the GRID");
        }


        [Then(@"the updated sucessful toast message is displayed")]
        public void ThenTheUpdatedSucessfulToastMessageIsDisplayed()
        {
            Assert.IsTrue(PagesCollection.OperationsModule.UpdateSuccessful(),
                "Data Update not completed with success!");
        }

        [Then(@"the activity is added to the vessel")]
        public void ThenTheActivityIsAddedToTheVessel()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.IsActivityCreatedAtIndex(_vesselIndex, _activity),
                "Activity not displayed inside the GRID");
        }

        [Then(@"the to date is updated with the correct one")]
        public void ThenTheToDateIsUpdatedWithTheCorrectOne()
        {           
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, _toDate, TODATE));
        }

        [Then(@"the Next availability date is the same as the end date")]
        public void ThenTheNextAvailabilityDateIsTheSameAsTheEndDate()
        {
            var nextDate = _activity.GetEndDate();

            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, nextDate,NEXTDATE));
        }

        [Then(@"the status is updated with current activity")]
        public void ThenTheStatusIsUpdatedWithCurrentActivity()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, _activity.Status, CURRENTSTATUS, true));
        }

        [Then(@"the next available Activity is AVAILABLE")]
        public void ThenTheNextAvailableActivityIsAVAILABLE()
        {
            Assert.IsTrue(PagesCollection.ActivitiesPage.CheckFieldOnGrid(_vesselIndex, "Available", NEXTSTATUS, true));
        }

        #endregion
    }
}
