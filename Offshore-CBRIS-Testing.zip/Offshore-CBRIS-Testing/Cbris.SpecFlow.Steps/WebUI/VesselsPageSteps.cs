﻿using Cbris.Coypu.PageObjects;
using Cbris.Models.Enums;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Cbris.SpecFlow.Steps.WebUI
{
    [Binding]
    public class VesselsPageSteps
    {
        [When(@"user open Vessels page")]
        public void WhenUserOpenVesselsPage()
        {
            PagesCollection.VesselsPage.Open();
            ScenarioContext.Current["SectionType"] = SectionType.Vessels;
        }

        [StepDefinition(@"the Vessels data grid is loaded")]
        public void ThenTheVesselsDataGridIsLoaded()
        {
            Assert.IsTrue(PagesCollection.VesselsPage.IsGridReady(), "Grid not loaded!");
        }

        [Then(@"the Vessels data in the grid are ready")]
        public void ThenTheVesselsDataInTheGridAreReady()
        {
            Assert.IsTrue(PagesCollection.VesselsPage.AreDataDisplayed(), "Data not ready!");
        }
    }
}
