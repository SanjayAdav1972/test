﻿using Clarksons.Automation.Support.Utility;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;

namespace Clarksons.Automation.Support.Export
{
    public class ExcelExport
    {

        private int _headerindex;
        private int _datasheetindex;
        private string _filepath;

        public ExcelExport(string filePath, int headerindex = 7, int datasheetindex = 0)
        {
            _filepath = filePath;
            _headerindex = headerindex;
            _datasheetindex = datasheetindex;
        }

        private XSSFSheet GetDataSheet()
        {
            if (Tools.CheckFileExist(_filepath) >= 0)
            {

                XSSFWorkbook hssfwb;
                using (FileStream file = new FileStream(_filepath, FileMode.Open, FileAccess.Read))
                {
                    hssfwb = new XSSFWorkbook(file);
                }

                return (XSSFSheet)hssfwb.GetSheetAt(_datasheetindex);

            }
            else
                throw new FileNotFoundException(string.Format("File {0} not found!", _filepath));
        }

        private List<string> ReturnColumnData(int index)
        {
            XSSFSheet sheet = GetDataSheet();

            int eof = sheet.LastRowNum;
            DateTime datevalue;
            List<string> data = new List<string>();

            for (int i = _headerindex + 1; i <= eof; i++)
            {
                var cell = (XSSFCell)sheet.GetRow(i).GetCell(index);

                switch (cell.CellType)
                {
                    case CellType.Numeric:
                        data.Add(cell.NumericCellValue.ToString());
                        break;

                    case CellType.String:
                        if (cell.StringCellValue.Contains(",")) //values with , and only numbers can be mistaken for dates
                        {
                            data.Add(cell.StringCellValue.RemoveMultipleSpaces());
                        }
                        else if (DateTime.TryParse(cell.StringCellValue, out datevalue)) //if the string is a date
                        {
                            data.Add(datevalue.ToString("dd-MM-yyyy HH:mm"));
                        }
                        else
                        {
                            data.Add(cell.StringCellValue.RemoveMultipleSpaces());
                        }
                        break;
                }
            }

            return data;
        }

        private List<string> ReturnRowData(XSSFRow row, bool roundnumbers = false)
        {
            List<string> data = new List<string>();
            DateTime datevalue;
            foreach (var col in row)
            {

                switch (col.CellType)
                {
                    case CellType.Numeric:
                        if (roundnumbers)
                        {
                            data.Add(col.NumericCellValue.ToString("#0.#"));
                        }
                        else
                        {
                            data.Add(col.NumericCellValue.ToString());
                        }
                        break;

                    case CellType.String:
                        if (col.StringCellValue.Contains(",") || col.StringCellValue.Contains(".")) //values with , or . and only numbers can be mistaken for dates
                        {
                            data.Add(col.StringCellValue.RemoveMultipleSpaces());
                        }
                        else if (DateTime.TryParse(col.StringCellValue, out datevalue)) //if the string is a date
                        {
                            data.Add(datevalue.ToString("dd-MM-yyyy HH:mm"));
                        }
                        else
                        {
                            data.Add(col.StringCellValue.RemoveMultipleSpaces());
                        }
                        break;
                }
            }

            return data;
        }

        /// <summary>
        /// Returns al the rows below the header. 
        /// </summary>
        /// <returns></returns>
        private List<XSSFRow> GetAllDataRows()
        {
            XSSFSheet sheet = GetDataSheet();

            int eof = sheet.LastRowNum - 1; //last row is empty

            List<XSSFRow> data = new List<XSSFRow>();

            for (int i = _headerindex + 1; i <= eof; i++)
            {
                data.Add((XSSFRow)sheet.GetRow(i));
            }

            return data;
        }

        /// <summary>
        /// Returns the count of data row (excluding header) inside the file
        /// </summary>
        /// <returns></returns>
        public int GetRowCount()
        {
            //get last row to check if it is empty or not
            var lastrow = (XSSFRow)GetDataSheet().GetRow(_headerindex + GetDataSheet().LastRowNum);
            if (lastrow != null)
                return GetDataSheet().LastRowNum - _headerindex;
            else
                return GetDataSheet().LastRowNum - 1 - _headerindex;
        }

        /// <summary>
        /// Returns the header of the excel file
        /// </summary>
        public List<string> GetHeader() => ReturnRowData((XSSFRow)GetDataSheet().GetRow(_headerindex));

        /// <summary>
        /// Returns true if the file is populated.
        /// </summary>
        public bool IsFilePopulated() => ReturnRowData((XSSFRow)GetDataSheet().GetRow(_headerindex + 1)).Count > 0;

        /// <summary>
        /// Check if the file contains empty column and return the header title of the empty ones.
        /// </summary>
        /// <returns></returns>
        public List<string> AreColumnNotEmpty()
        {
            List<string> emptyCol = new List<string>();

            List<string> header = GetHeader();
            //Header on the file are shifted one cell 
            //while on the list they start from 0
            for (int i = 1; i < header.Count + 1; i++)
            {
                if (ReturnColumnData(i).Count == 0)
                    emptyCol.Add(header[i - 1]);
            }

            return emptyCol;
        }

        /// <summary>
        /// Check if the row at specific index contains the list of data provided
        /// </summary>
        /// <param name="data"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool CheckRowContainsData(List<string> data, int index, bool round)
        {

            bool equals = true;

            var filedata = ReturnRowData((XSSFRow)GetDataSheet().GetRow(_headerindex + index), round);

            foreach (var file in filedata)
            {
                if (!string.IsNullOrEmpty(file))
                    if (!data.Contains(file))
                        equals = false;
            }

            return equals;
        }

        /// <summary>
        /// Extract the content of the file as VesselCriterias. Used to facilitate the comparison operation.
        /// </summary>
        /// <returns></returns>
        public List<Dictionary<string,string>> ExtractFileData()
        {
            int rowcount = GetRowCount();

            var header = GetHeader();

            List<Dictionary<string, string>> results = new List<Dictionary<string, string>>();

            for(int row = 1; row < rowcount; row++)
            {
                Dictionary<string, string> col = new Dictionary<string, string>();

                var rowdata = ReturnRowData((XSSFRow)GetDataSheet().GetRow(_headerindex + row));

                for(int column = 0; column < rowdata.Count; column++)
                {
                    col.Add(header[column], rowdata[column]);
                }

                results.Add(col);
            }

            return results;
        }

        /// <summary>
        /// Compare the file agains a list of data from an external source.
        /// </summary>
        /// <param name="uidata"></param>
        /// <param name="round"></param>
        /// <returns></returns>
        public Dictionary<int, List<string>> CompareFileVsExternalData(List<List<string>> uidata, bool round = false)
        {
            Dictionary<int, List<string>> diff = new Dictionary<int, List<string>>();

            int filerowcount = GetRowCount();

            if (filerowcount != uidata.Count)
                throw new Exceptions.WrongTypeOfExportFile("File exported is in a different format and/or different type!");

            for (int ui = 0; ui < uidata.Count; ui++)
            {
                bool loop = true;
                //just in case are in the order files have the same order
                if (CheckRowContainsData(uidata[ui], ui + 1, round))
                {
                    loop = false;
                }
                else //if the row at the same position are not equals, it is possible they are not ordered at the same way
                {

                    int ex = 0;
                    while (loop && ex < filerowcount)
                    {
                        if (CheckRowContainsData(uidata[ui], ex + 1, round))
                            loop = false;
                        ex++;
                    }
                }
                if (loop)
                    diff.Add(ui + 1, uidata[ui]);
            }

            return diff;
        }
    }
}
