﻿using System.Collections.Generic;
using System.Linq;
using Clarksons.Automation.Support.Exceptions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Clarksons.Automation.Support.Export
{
    public class WordExport
    {
        private string _filepath;
        private int _tableindex;
        private int _headerindex;
        private WordprocessingDocument _doc;

        public WordExport(string filepath, int tableindex = 0, int headerindex = 1)
        {
            _filepath = filepath;
            _tableindex = tableindex;
            _headerindex = headerindex;
            _doc = WordprocessingDocument.Open(_filepath, true);
        }

        private Table GetTable(int index)
        {
            Table table;


            var tables = _doc.MainDocumentPart.Document.Body.Elements<Table>();
            if (tables.Count() == 0)
                throw new TableNotFoundException("File doesn't contain any table!");

            table = tables.ElementAt(index);


            return table;
        }

        private int GetRowCount()
        {
            return GetTable(_tableindex).Elements<TableRow>().Count() - _headerindex;
        }

        private int GetColumnCount()
        {
            return GetTable(_tableindex).Elements<TableRow>().First().Elements<TableCell>().Count();
        }

        /// <summary>
        /// Extract content from a table inside the word document.
        /// </summary>
        /// <param name="tableindex"></param>
        /// <returns></returns>
        private List<List<string>> ExtractTableContent()
        {
            List<List<string>> results = new List<List<string>>();

            var table = GetTable(_tableindex);

            var rowcount = GetRowCount();

            for (int row = 0; row < rowcount; row++)
            {
                List<string> columns = new List<string>();

                for (int column = 0; column <= table.Elements<TableRow>().First().Elements<TableCell>().Count(); column++)
                {
                    var rowelement = table.Elements<TableRow>().ElementAt(row);

                    columns.Add(rowelement.Elements<TableCell>().ElementAt(column).InnerText);
                }

                results.Add(columns);
            }

            return results;
        }

        private List<string> ReturnRowData(int rowindex)
        {
            var table = GetTable(_tableindex);

            List<string> data = new List<string>();

            int columncount = GetColumnCount();

            for (int column = 0; column < columncount; column++)
            {
                var rowelement = table.Elements<TableRow>().ElementAt(rowindex);

                string text = rowelement.Elements<TableCell>().ElementAt(column).InnerText.Replace("\r\a", string.Empty);

                data.Add(text);
            }

            return data;
        }

        public void Deallocate() => _doc.Close();

        /// <summary>
        /// Check if the row at specific index contains the list of data provided
        /// </summary>
        /// <param name="data"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool CheckRowContainsData(List<string> data, int index, bool round)
        {

            bool equals = true;

            var filedata = ReturnRowData(index + _headerindex);

            foreach (var file in filedata)
            {
                if (!string.IsNullOrEmpty(file))
                    if (!data.Contains(file))
                        equals = false;
            }

            return equals;
        }

        /// <summary>
        /// Compare the file agains a list of data from an external source.
        /// </summary>
        /// <param name="uidata"></param>
        /// <param name="round"></param>
        /// <returns></returns>
        public Dictionary<int, List<string>> CompareFileVsExternalData(List<List<string>> uidata, bool round = false)
        {
            Dictionary<int, List<string>> diff = new Dictionary<int, List<string>>();

            int filerowcount = GetRowCount();

            if (filerowcount != uidata.Count)
                throw new Exceptions.WrongTypeOfExportFile("File exported is in a different format and/or different type!");

            for (int ui = 0; ui < uidata.Count; ui++)
            {
                bool loop = true;
                //just in case are in the order files have the same order
                if (CheckRowContainsData(uidata[ui], ui, round))
                {
                    loop = false;
                }
                else //if the row at the same position are not equals, it is possible they are not ordered at the same way
                {

                    int ex = 0;
                    while (loop && ex < filerowcount)
                    {
                        if (CheckRowContainsData(uidata[ui], ex, round))
                            loop = false;
                        ex++;
                    }
                }
                if (loop)
                    diff.Add(ui, uidata[ui]);
            }

            return diff;
        }
    }
}
