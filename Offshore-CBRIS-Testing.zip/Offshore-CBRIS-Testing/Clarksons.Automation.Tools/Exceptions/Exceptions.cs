﻿using System;

namespace Clarksons.Automation.Support.Exceptions
{
    [Serializable]
    public class ValueNotRecognizedException : Exception
    {
        public ValueNotRecognizedException() { }
        public ValueNotRecognizedException(string message) : base(message) { }
        public ValueNotRecognizedException(string message, Exception inner) : base(message, inner) { }
    }
    [Serializable]
    public class PageNotFoundException : Exception
    {
        public PageNotFoundException() { }
        public PageNotFoundException(string message) : base(message) { }
        public PageNotFoundException(string message, Exception inner) : base(message, inner) { }

    }
    [Serializable]
    public class AccessDeniedException : Exception
    {
        public AccessDeniedException() { }
        public AccessDeniedException(string message) : base(message) { }
        public AccessDeniedException(string message, Exception inner) : base(message, inner) { }
    }
    [Serializable]
    public class FileLockedException : Exception
    {
        public FileLockedException() { }
        public FileLockedException(string message) : base(message) { }
        public FileLockedException(string message, Exception inner) : base(message, inner) { }
    }
    [Serializable]
    public class ScenarioSkippedException : Exception
    {
        public ScenarioSkippedException() { }
        public ScenarioSkippedException(string message) : base(message) { }
        public ScenarioSkippedException(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class EmailNotValidException : Exception
    {
        public EmailNotValidException() { }
        public EmailNotValidException(string message) : base(message) { }
        public EmailNotValidException(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class FunctionNotImplemented : Exception
    {
        public FunctionNotImplemented() { }
        public FunctionNotImplemented(string message) : base(message) { }
        public FunctionNotImplemented(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class VesselNotFoundException : Exception
    {
        public VesselNotFoundException() { }
        public VesselNotFoundException(string message) : base(message) { }
        public VesselNotFoundException(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class SearchResultNotValidException : Exception
    {
        public SearchResultNotValidException() { }
        public SearchResultNotValidException(string message) : base(message) { }
        public SearchResultNotValidException(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class DateOutOfRangeException : Exception
    {
        public DateOutOfRangeException() { }
        public DateOutOfRangeException(string message) : base(message) { }
        public DateOutOfRangeException(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class WrongTypeOfExportFile : Exception
    {
        public WrongTypeOfExportFile() { }
        public WrongTypeOfExportFile(string message) : base(message) { }
        public WrongTypeOfExportFile(string message, Exception inner) : base(message, inner) { }
    }

    [Serializable]
    public class TableNotFoundException : Exception
    {
        public TableNotFoundException() { }
        public TableNotFoundException(string message) : base(message) { }
        public TableNotFoundException(string message, Exception inner) : base(message, inner) { }
    }

}
