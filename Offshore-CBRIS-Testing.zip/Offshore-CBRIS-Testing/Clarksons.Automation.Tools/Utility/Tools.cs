﻿using System;
using System.IO;
using Clarksons.Automation.Support.Exceptions;
using System.Security.Cryptography;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using CsvHelper;
using System.ComponentModel;
using System.Reflection;

namespace Clarksons.Automation.Support.Utility
{
    public static class Tools
    {
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        /// <summary>
        /// Generates SECURE random numbers using OS entropy to generate seeds. OS entropy is a random value
        /// which is generated using sound, mouse click and keyboard timings, thermal temp, etc.
        /// </summary>
        /// <returns></returns>
        public static int GenerateRandomInt()
        {
            int random = 0;
            using (RNGCryptoServiceProvider rg = new RNGCryptoServiceProvider())
            {
                byte[] rno = new byte[5];

                rg.GetBytes(rno);
                random = BitConverter.ToInt32(rno, 0);
            }

            return random < 0 ? random * -1 : random;
        }

        /// <summary>
        /// Checks if a file is currently used by another thread or does not exist
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public static bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            {
                //file is locked
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;

        }
        /// <summary>
        /// Checks if a file exist inside a containing folder
        /// </summary>
        /// <param name="fileToCheck"></param>
        /// <param name="containingFolder"></param>
        /// <returns>-1 if the files does not exist</returns>
        public static int CheckFileExist(string fileToCheck, string containingFolder)
        {
            int found = -1;

            var startTime = DateTime.UtcNow;

            while (found < 0 && DateTime.UtcNow - startTime < TimeSpan.FromMinutes(2))
            {
                string[] files = System.IO.Directory.GetFiles(containingFolder);

                found = Array.IndexOf(files, System.IO.Path.Combine(containingFolder, fileToCheck));
            }

            return found;
        }

        /// <summary>
        /// Checks if a specific file path exist
        /// </summary>
        /// <param name="fileToCheck"></param>
        /// <param name="containingFolder"></param>
        /// <returns>-1 if the files does not exist</returns>
        public static int CheckFileExist(string filePath)
        {
            string fileToCheck = System.IO.Path.GetFileName(filePath);
            string containingFolder = filePath.Remove(filePath.Length - fileToCheck.Length);

            return CheckFileExist(fileToCheck, containingFolder);
        }

        /// <summary>
        /// Move a file from a origin to a destination
        /// </summary>
        /// <param name="originFile">Origin complete with file name and extension</param>
        /// <param name="destinationFile">Destination complete with file name and extension</param>
        public static void MoveFile(string originFile, string destinationFile)
        {
            System.IO.FileInfo file = new System.IO.FileInfo(originFile);

            //empty loop to wait that the file is completed
            while (Tools.IsFileLocked(file)) { }

            //if the file is not locked (should not be, but better be sure)
            if (!Tools.IsFileLocked(file))
                System.IO.File.Move(originFile, destinationFile);
            else
                throw new FileLockedException(string.Format("Error: The file {0} is still locked by another process", originFile));
        }

        /// <summary>
        /// Compares two dates and return an offset in hours reppresenting the difference between the two dates
        /// </summary>
        /// <param name="dateA"></param>
        /// <param name="dateB"></param>
        /// <returns></returns>
        public static double CompareDates(string dateA, string dateB)
        {
            var formats = new string[] { "dd/MM/yyyy HH:mm", "yyyy/MM/dd HH:mm", "MM/dd/yyyy HH:mm", "dd/MM/yy HH:mm", "dd MMM yyyy HH:mm" };
            CultureInfo enGB = new CultureInfo("en-GB");

            if (dateA.Contains("-"))
                dateA = dateA.Replace('-', '/');
            if (dateB.Contains("-"))
                dateB = dateB.Replace('-', '/');

            DateTime a;
            DateTime b;

            DateTime.TryParseExact(dateA, formats, enGB, DateTimeStyles.None, out a);
            DateTime.TryParseExact(dateB, formats, enGB, DateTimeStyles.None, out b);

            var diff = b.Subtract(a).Hours;

            if (diff < 0)
                return diff * -1;
            else
                return diff;
        }

        /// <summary>
        /// Take most common format date as string in input and returns a universal formatted DateTime.
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime ConvertDate(string date)
        {
            var formats = new string[] { "dd/MM/yyyy HH:mm", "yyyy/MM/dd HH:mm", "MM/dd/yyyy HH:mm", "dd/MM/yy HH:mm", "dd MMM yyyy HH:mm" };
            CultureInfo enGB = new CultureInfo("en-GB");

            if (date.Contains("-"))
                date = date.Replace('-', '/');

            DateTime parsed;
            DateTime.TryParseExact(date, formats, enGB, DateTimeStyles.None, out parsed);

            return parsed;
        }



        /// <summary>
        /// Convert a date from hh:mm week dd Month yyyy format to dd MMM yyyy HH:mm format
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string ParseDateTime(string input)
        {
            //extract the time frome the date
            string time = System.Text.RegularExpressions.Regex.Match(input, @"^(?:\d|[01]\d|2[0-3]):[0-5]\d").Value;

            string date = System.Text.RegularExpressions.Regex.Match(input, @"\d{2}\s[A-z]{3}\s\d{4}").Value;

            return string.Format("{0} {1}", date, time);
        }

        /// <summary>
        /// Returns a FileInfo instance containing the information of the latest created file inside the folder.
        /// </summary>
        /// <param name="directory"></param>
        /// <returns></returns>
        public static FileInfo GetNewestFile(DirectoryInfo directory)
        {
            return directory.GetFiles()
                .Union(directory.GetDirectories().Select(d => GetNewestFile(d)))
                .OrderByDescending(f => (f == null ? DateTime.MinValue : f.LastWriteTime))
                .FirstOrDefault();
        }

        /// <summary>
        /// Returns headers and values at specific index from a CSV file.
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="row"></param>
        /// <returns></returns>
        public static Dictionary<string, string> ExtractCSVFile(string filePath, int row)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();

            if (File.Exists(filePath))
            {
                CsvReader csv = new CsvReader(File.OpenText(filePath));
                csv.Read();
                csv.ReadHeader();

                List<string> headers = csv.Context.HeaderRecord.ToList();

                while (row != 0)
                {
                    csv.Read();
                    row -= 1;
                }

                foreach (string header in headers)
                {
                    string value = csv.GetField<string>(header);
                    if (!string.IsNullOrWhiteSpace(value))
                        results.Add(header, value.Trim());
                }
            }
            else
                throw new FileNotFoundException($"File {filePath} not found! Check if the file exists!");

            return results;

        }

        /// <summary>
        /// Decode a url string
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string DecodeUrlString(string url)
        {
            string newUrl;
            while ((newUrl = Uri.UnescapeDataString(url)) != url)
                url = newUrl;
            return newUrl;
        }

        /// <summary>
        /// Convert yy date to DateTime
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime ConvertTwoDigitDate(string date)
        {
            try
            {
                var culture = new CultureInfo(CultureInfo.CurrentCulture.Name);
                culture.Calendar.TwoDigitYearMax = 2057; //oldest vessel is from 1958

                var year = culture.Calendar.ToFourDigitYear(int.Parse(date));

                return DateTime.Parse($"{year}-01-01");
            }catch(FormatException)
            {
                return DateTime.MinValue;
            }

        }

        /// <summary>
        /// Convert yyyy date to DateTime
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime ConvertFourDigitDate(string date)
        {
            try
            {
                return DateTime.Parse($"{date}-01-01");
            }catch(FormatException)
            {
                return DateTime.MinValue;
            }
        }

        public static DateTime ConvertAgeToFourDigitDate(string age)
        {
            var year = DateTime.Now.Year - int.Parse(age);

            return ConvertFourDigitDate(year.ToString());
        }

        /// <summary>
        /// Returns Enum value from description.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="description"></param>
        /// <returns></returns>
        public static T GetValueFromDescription<T>(string description)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                {
                    if (attribute.Description == description)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                }
            }
            throw new ArgumentException("Not found.", "description");

        }

        /// <summary>
        /// Returns enum description from its value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetDescription(Enum value)
        {
            return
                value
                    .GetType()
                    .GetMember(value.ToString())
                    .FirstOrDefault()
                    ?.GetCustomAttribute<DescriptionAttribute>()
                    ?.Description;
        }
    }
}
