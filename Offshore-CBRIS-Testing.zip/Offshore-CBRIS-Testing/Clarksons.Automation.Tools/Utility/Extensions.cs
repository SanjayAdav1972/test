﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;

namespace Clarksons.Automation.Support.Utility
{
    public static class Extensions
    {
        /// <summary>
        /// Returns a value indicating wether a specified substring occurs within this string. Case insensitive
        /// </summary>
        /// <param name="text"></param>
        /// <param name="value"></param>
        /// <param name="stringComparison"></param>
        /// <returns></returns>
        public static bool CaseInsensitiveContains(this string text, string value,
            StringComparison stringComparison = StringComparison.CurrentCultureIgnoreCase)
        {
            return text.IndexOf(value, stringComparison) >= 0;
        }

        /// <summary>
        /// Returns enum value using the descriptions of the enum
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="description"></param>
        /// <returns></returns>
        public static T GetValueFromDescription<T>(this string description)
        {
            var type = typeof(T);
            if (!type.IsEnum) throw new InvalidOperationException();
            foreach (var field in type.GetFields())
            {
                var attribute = Attribute.GetCustomAttribute(field,
                    typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                {
                    if (attribute.Description == description)
                        return (T)field.GetValue(null);
                }
                else
                {
                    if (field.Name == description)
                        return (T)field.GetValue(null);
                }
            }
            throw new ArgumentException("Not found.", "description");
            // or return default(T);
        }

        public static string RemoveWhitespace(this string input)
        {
            return new string(input.ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
        }

        public static string RemoveCharacter(this string input, char character)
        {
            return new string(input.ToCharArray().Where(c => c != character).ToArray());
        }

        public static bool IsAnagram(this string strA, string strB)
        {
            strA = strA.RemoveWhitespace();
            strB = strB.RemoveWhitespace();

            if (strA.Equals(string.Empty) || strB.Equals(string.Empty)) return false;
            else if (strA.Length != strB.Length) return false;

            int[] letters = new int[256];
            char[] s_array = strA.ToCharArray();

            foreach (char c in s_array)
            {
                letters[c]++;
            }

            for (int i = 0; i < strB.Length; i++)
            {
                int c = strB[i];
                if (--letters[c] < 0)
                {
                    return false;
                }
            }
            return true;
        }

        public static string RemoveMultipleSpaces(this string input)
        {
            return System.Text.RegularExpressions.Regex.Replace(input, @"\s+", " ");
        }

        public static string SplitList(this List<string> list, bool carriagereturn = false)
        {
            string strList = string.Empty;
            string separator = string.Empty;
            if (carriagereturn)
                separator = "\n";
            else
                separator = " ";
            foreach (var str in list)
            {
                strList += str + separator;
            }

            return strList.Trim();
        }

        public static void Rename(this FileInfo fileInfo, string newName)
        {
            fileInfo.MoveTo(Path.Combine(fileInfo.Directory.FullName, newName + fileInfo.Extension));
        }

        /// <summary>
        /// Split a string using the provided separator and returns a KeyValuePair object.
        /// </summary>
        /// <param name="input"></param>
        /// <param name="separator"></param>
        /// <param name="lowercase"></param>
        /// <returns></returns>
        public static KeyValuePair<string, string> ToKeyValuePair(this string input, char separator, bool lowercase = true)
        {

            if (lowercase)
                return new KeyValuePair<string, string>(input.Split(separator)[0].Trim().ToLower(), input.Split(separator)[1].Trim().ToLower());
            else
                return new KeyValuePair<string, string>(input.Split(separator)[0].Trim(), input.Split(separator)[1].Trim());

        }

        /// <summary>
        /// Return property value from an object knowing the property name
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static object GetPropertyValue(this object obj, string propertyName)
        {
            return obj.GetType().GetProperties()
                .Single(pi => pi.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase))
                .GetValue(obj, null);
        }

    }
}
