﻿using System;
using log4net;


namespace Clarksons.Automation.Support.Utility
{
    /// <summary>
    /// Define new SQLScript log level in log4net for logging SQL scripts
    /// </summary>
    public static class SQLLoggingLevel
    {
        public static readonly log4net.Core.Level sqlLevel = new log4net.Core.Level(35000, "SQLSCRIPT");

        public static void SQLScript(this ILog log, object message)
        {
            log.Logger.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, sqlLevel, message, null);
        }
    }

    /// <summary>
    /// Interface for Log4NetWrapper
    /// </summary>
    public interface ILogger
    {
        void Debug(object message);
        bool IsDebugEnabled { get; }

        void Info(object message);
        bool IsInfoEnabled { get; }

        void Error(object message);
        bool IsErrorEnabled { get; }

        void Fatal(object message);
        bool IsFatalEnabled { get; }

        void Warn(object message);
        bool IsWarnEnabled { get; }

        void SQLScript(object message);

    }

    /// <summary>
    /// Wrapper for log4net. Allows to change logger without necessarily touch the code
    /// </summary>
    public class EventLogger : ILogger
    {
        private readonly log4net.ILog _logger;

        public EventLogger(Type type)
        {
            //Add custom Level to Ilogger repository
            log4net.LogManager.GetRepository().LevelMap.Add(SQLLoggingLevel.sqlLevel);
            _logger = log4net.LogManager.GetLogger(type);
        }

        public void Debug(object message)
        {
            _logger.Debug(message);
        }

        public bool IsDebugEnabled
        {
            get { return _logger.IsDebugEnabled; }
        }

        public void Info(object message)
        {
            _logger.Info(message);
        }

        public bool IsInfoEnabled
        {
            get { return _logger.IsInfoEnabled; }
        }

        public void Error(object message)
        {
            _logger.Error(message);
        }

        public bool IsErrorEnabled
        {
            get { return _logger.IsErrorEnabled; }
        }

        public void Fatal(object message)
        {
            _logger.Fatal(message);
        }

        public bool IsFatalEnabled
        {
            get { return _logger.IsFatalEnabled; }
        }

        public void Warn(object message)
        {
            _logger.Warn(message);
        }

        public void SQLScript(object message)
        {
            _logger.SQLScript(message);
        }

        public bool IsWarnEnabled
        {
            get { return _logger.IsWarnEnabled; }
        }

    }

    public static class LogManager
    {
        public static ILogger GetLogger(Type type)
        {
            return new EventLogger(type);
        }
    }
}
