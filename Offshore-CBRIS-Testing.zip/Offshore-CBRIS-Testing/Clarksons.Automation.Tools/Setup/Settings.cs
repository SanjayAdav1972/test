﻿using System.Configuration;

namespace Clarksons.Automation.Support.Setup
{
    public class Settings
    {
        public static readonly string Environment = ConfigurationManager.AppSettings["Environment"];
        public static readonly string LocationRun = ConfigurationManager.AppSettings["LocationRun"];
        public static readonly string TestUser = ConfigurationManager.AppSettings["TestUser"];
        public static readonly string TestPassword = ConfigurationManager.AppSettings["TestPassword"];
        public static readonly string WebdriverUri = ConfigurationManager.AppSettings["WebdriverUri"];
        public static readonly string ScreenshotStoreLocation = ConfigurationManager.AppSettings["ScreenshotStoreLocation"];
        public static readonly string ScreenshotArtifactLocation = ConfigurationManager.AppSettings["ScreenshotArtifactLocation"];
        public static readonly string CloudAPIUri = ConfigurationManager.AppSettings["CloudAPI"];
        public static readonly string HtmlReportStoreLocation = ConfigurationManager.AppSettings["HtmlReportStoreLocation"];

    }
}
