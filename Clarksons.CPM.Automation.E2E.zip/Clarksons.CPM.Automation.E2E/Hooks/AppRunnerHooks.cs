﻿using BoDi;
using Clarksons.Automation.TestReporting.Services;
using Clarksons.Automation.TestReporting.SpecFlow;
using Clarksons.Automation.TestReporting.Utility;
using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu.WebDriver;
using Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using Coypu.Drivers;
using NUnit.Framework;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Hooks
{
    [Binding]
    public class AppRunnerHooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks
        private static BrowserSession reuseableBrowserSession;
        private BrowserSession browserSession;
        private readonly IObjectContainer objectContainer;
       
        // To generate HTML Report 
        private static string _env => Setting.Env;
        private static string _product => Setting.Product;
        private static int _step;
        private static TestLogger _testLogger = new TestLogger();

        public AppRunnerHooks(IObjectContainer objectContainer)
        {
            this.objectContainer = objectContainer;
        }

        #region "BeforeTestRun "
        /// <summary>
        /// Kill any webdriver instances
        /// </summary>
        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            Console.WriteLine("AppRunnerHooks->BeforeTestRun");
            _testLogger.User = _product;
            _testLogger.Environment = _env;

            CleanUpDownloadFolder();

            if (Setting.UseSeleniumGrid2)
            {
                CodeHelper.CanFail(() => ExecuteProcess(Setting.DockerComposeDownFile, wait: true));
                ExecuteProcess(Setting.DockerComposeUpFile, wait: false);
                var secondsToWaitForZaleniumToStart = 30;
                Thread.Sleep(TimeSpan.FromSeconds(secondsToWaitForZaleniumToStart));
            }
            else
            {
                KillProcess("chromedriver");
                KillProcess("geckodriver");
                KillProcess("IEDriverServer");
            }
        }
        #endregion

        [BeforeFeature]
        public static void BeforeFeature()
        {
            _testLogger.AddFeature(FeatureContext.Current);
        }

        #region "BeforeScenario "
        /// <summary>
        /// Use this tag on scenarios if re-usable browser set to 'True' on app.config and want to dispose browser after each run
        /// </summary>
        [BeforeScenario("Isolated", Order = 0)]
        public void ForceIsolatedSession()
        {
            Console.WriteLine("AppRunnerHooks->BeforeScenario->ForceIsolatedSession");
            AppRunnerHooks.DisposeAfterTestRun();
        }

        [BeforeScenario("AppCPM", Order = 1)]
        // [BeforeScenario("AppRM", Order = 1)]     // Currently not targetted
        [BeforeScenario("AppShared", Order = 1)]
        public void BeforeScenarioStart()
        {
            Console.WriteLine("AppRunnerHooks->BeforeScenario->BeforeScenarioStart");
            Retry.Timeout(() => InitialiseAppRunner(Setting.BaseUrl), 60);

            _step = 0;
            _testLogger.AddScenarioToFeature(objectContainer.Resolve<ScenarioContext>());
            _testLogger.LogScenarioStart();
            ScreenCapture.Init(browserSession);
            ScreenCapture.Instance.Subscribe(_testLogger);

            Console.WriteLine("You are running CPM Automation test pack on environment {0} with url {1}", _env, Setting.BaseUrl);
        }
        #endregion

        #region "AfterScenario "
        /// <summary>
        /// Dispose browser session after test run
        /// </summary>
        [AfterScenario(Order = 100)]
        public void Dispose()
        {
            Console.WriteLine("AppRunnerHooks->AfterScenario->Dispose");
           
            if (ScenarioContext.Current.TestError != null)
            {
                var testError = ScenarioContext.Current.TestError;
                _testLogger.AddTestOutput(testError.Message, testError.StackTrace);
            }

            //if the scenario is inconclusive
            if (ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.StepDefinitionPending ||
                ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.UndefinedStep ||
                ScenarioContext.Current.ScenarioExecutionStatus == ScenarioExecutionStatus.BindingError)
            {
                _testLogger.MarkScenarioAsInconclusive();
            }
       
            _testLogger.LogScenarioEnd();
            _testLogger.UpdateScenarioCount();

            if (AppRunnerHooks.reuseableBrowserSession == null)
            {
                this.browserSession.Dispose();
            }
        }
        #endregion

        [BeforeStep]
        public static void BeforeStep()
        {
            _testLogger.AddStepToScenario(ScenarioStepContext.Current);
        }

        [AfterStep]
        public static void AfterStep()
        {
            _step += 1;
            if (!Directory.Exists(Setting.HtmlReportStoreLocation))
            {
                Directory.CreateDirectory(Setting.HtmlReportStoreLocation);
            }

            ScreenCapture.Instance.TakeScreenshot($"Step_{_step}" + DateTime.Now.ToString("ddMMyyyy-hhmmss") + ".jpg");

            if (ScenarioContext.Current.TestError != null)
            {
                _testLogger.ReportStepFailure();
            }
            else
                _testLogger.ReportStepPass();

            _testLogger.GroupImagesInGif(Setting.ScreenshotStoreLocation, Setting.ScreenshotArtifactLocation);
        }
        
        #region "AfterTestRun "
        /// <summary>
        /// Perform activities After Test Run e.g. close any open browser session to release memory
        /// </summary>
        [AfterTestRun]
        public static void DisposeAfterTestRun()
        {
            Console.WriteLine("AppRunnerHooks->AfterTestRun->DisposeAfterTestRun");
            _testLogger.CloseTestExecution();
            TestTransformer transformer = new TestTransformer(_testLogger);

            //Generate and save report
            if (!Directory.Exists(Setting.HtmlReportStoreLocation))
            {
                Directory.CreateDirectory(Setting.HtmlReportStoreLocation);
            }

            transformer.ToHtmlReport(Setting.HtmlReportStoreLocation, "Report.html");

            // ExecuteProcess(Setting.DockerComposeDownFile);
            if (AppRunnerHooks.reuseableBrowserSession != null)
            {
                AppRunnerHooks.reuseableBrowserSession.Dispose();
                AppRunnerHooks.reuseableBrowserSession = null;
            }
        }
        #endregion

        [AfterFeature]
        public static void AfterFeature()
        {
            _testLogger.UpdateTestCount();
        }

        #region "Other supporting methods "
        /// <summary>
        /// Execute Process
        /// </summary>
        /// <param name="file"></param>
        /// <param name="wait"></param>
        private static void ExecuteProcess(string file, bool wait)
        {
            var process = Process.Start(new ProcessStartInfo()
            {
                WorkingDirectory = Path.GetDirectoryName(file),
                FileName = file
            });
            if (wait)
            {
                process.WaitForExit();
            }
        }

        /// <summary>
        /// Clean Up Download Folder to remove any existing pdf files
        /// </summary>
        public static void CleanUpDownloadFolder()
        {
            string filePath = Setting.UserDownloadPath;
            FileHelper.DeleteFiles(filePath, "Export*.pdf");
            FileHelper.DeleteFiles(filePath, "CharterParty*.pdf");
        }

        /// <summary>
        /// Specify Tests Results Folder where test run data will be stored
        /// </summary>
        private void SpecifyTestsResultsFolder()
        {
            var path = TestContext.CurrentContext.TestDirectory;
            path = Directory.GetParent(path).ToString();
            path = Path.Combine(path, @"TestResults\");
            Directory.CreateDirectory(path);
            Directory.SetCurrentDirectory(path);
        }

        /// <summary>
        /// Initialise App Runner for the provided url
        /// </summary>
        /// <param name="baseUrl"></param>
        private void InitialiseAppRunner(string baseUrl)
        {
            if (Setting.ReuseBrowser)
            {
                this.browserSession = AppRunnerHooks.reuseableBrowserSession;
            }

            if (this.browserSession == null)
            {
                var baseUri = new Uri(baseUrl);
                var host = baseUri.Host;
                var port = baseUri.Port;
                var isSsl = baseUri.Scheme == "https";

                var sessionConfiguration = new SessionConfiguration
                {
                    AppHost = host,
                    Port = port,
                    Browser = Setting.Browser,
                    SSL = isSsl,
                    Timeout = Setting.ElementTimeout,
                };

                if (Setting.UseSeleniumGrid2)
                {
                    var browser = Setting.BrowserName.ToLower();
                    var desiredCapabilites = new DesiredCapabilities(
                        new Dictionary<string, object>() {
                            { "browserName", browser },
                            { "version", string.Empty },
                            { "platform", "linux" },
                            { "javaScript", true },
                            { "name", TestContext.CurrentContext.Test.Name }
                        });
                    var gridRemoteHostUrl = new Uri(Setting.SeleniumGrid2Uri);
                    var driver = new CustomRemoteDriver(
                        gridRemoteHostUrl,
                        Browser.Parse(browser),
                        desiredCapabilites);
                    this.browserSession = new BrowserSession(sessionConfiguration, driver);
                }
                else
                {
                    this.browserSession = new BrowserSession(sessionConfiguration);
                }

                SetWindowSize(this.browserSession);
            }

            if (Setting.ReuseBrowser)
            {
                AppRunnerHooks.reuseableBrowserSession = this.browserSession;
            }

            objectContainer.RegisterInstanceAs(this.browserSession);

            new RegisterRunner(objectContainer).RegisterStepRunners();

            SetupRetryMultiplier();
        }

        /// <summary>
        /// Set up Retry count to retry the tests to run in parallel.
        /// </summary>
        private void SetupRetryMultiplier()
        {
            try
            {
                // Set the Parallelizable and LevelOfParallelism in AssemblyInfo.cs file of this "Clarksons.CPM.Automation.E2E" project.
                var attribute = (LevelOfParallelismAttribute)Attribute.GetCustomAttribute(
                    Assembly.GetExecutingAssembly(), typeof(LevelOfParallelismAttribute), false);
                var levelOfParallelismValue = attribute.Properties["LevelOfParallelism"][0];
                var levelOfParallelism = int.Parse(levelOfParallelismValue.ToString());
                Retry.TimeoutMultiplier = 1 + (levelOfParallelism * .2);
            }
            catch
            {
                //ignore
            }
        }

        /// <summary>
        /// Maximise the open instance of any open browser window (Chrome / Internet Explorer) etc.
        /// </summary>
        /// <param name="browserSession"></param>
        private void SetWindowSize(BrowserSession browserSession)
        {
            try
            {
                var device = Setting.Device;
                if (device == Device.DesktopMax)
                {
                    browserSession.MaximiseWindow();
                }
                else
                {
                    //TODO create dictionary of sizes per device enum; i.e. iPhone4Portrait
                }
            }
            catch (Exception exception)
            {
                var sva = exception;
            }
        }

        /// <summary>
        /// Kill Processes like if any existing instances of Webdrivers e.g. Chrome Driver, Internet Explorer driver etc.
        /// </summary>
        /// <param name="processToKill"></param>
        private static void KillProcess(string processToKill)
        {
            if (!Setting.UseSeleniumGrid2)
            {
                Process.GetProcessesByName(processToKill).ToList()
                    .ForEach(p => p.Kill());
            }
        }
        #endregion
    }
}