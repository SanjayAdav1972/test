﻿using BoDi;
using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;
using Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs;
using Clarksons.CPM.Automation.Utilities.Config;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Drawing;
using System.IO;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Hooks
{
    [Binding]
    public class LoginHooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        private readonly IObjectContainer objectContainer;
        private BrowserSession browserSession;
        private readonly ScenarioContext scenarioContext;

        public LoginHooks(IObjectContainer objectContainer)
        {
            this.objectContainer = objectContainer;
            this.browserSession = objectContainer.Resolve<BrowserSession>();
            this.scenarioContext = objectContainer.Resolve<ScenarioContext>();
        }

        #region "BeforeScenario "
        /// <summary>
        /// Always login to fixer
        /// Use @Login within feature files to login into CPM/RM
        /// </summary>
        [BeforeScenario("Login")]
        public void BeforeScenarioLogin()
        {
            Console.WriteLine("LoginHooks->BeforeScenario->BeforeScenarioLogin");

            // Remove this multiple IgnoreAlert when defect# is fixed 71584
            this.objectContainer.Resolve<PageActions>().IgnoreAlert();                  // Ignore the alert appears on page
            this.objectContainer.Resolve<LoginActs>().LoginAsBroker();                  // Login as Broker
            this.objectContainer.Resolve<LoginActions>().IgnoreReleaseNotesPopup();     // Ignore release notes pop-up
        }
        #endregion

        #region "AfterScenario "
        /// <summary>
        /// Take screenshots for failed tests
        /// </summary>
        [AfterScenario(Order = 0)]
        public void TakeScreenshot()
        {
            try
            {
                Console.WriteLine("LoginHooks->AfterScenario->TakeScreenshot");
                var scenarioTitle = scenarioContext.ScenarioInfo.Title.Replace(" ", String.Empty);
                if (!string.IsNullOrEmpty(scenarioContext.TestError.Message))
                {
                    IWebDriver driver = (IWebDriver)browserSession.Native;
                    var capture = ((ITakesScreenshot)driver).GetScreenshot();
                    var bitmapStream = new System.IO.MemoryStream(capture.AsByteArray);
                    var image = new Bitmap(System.Drawing.Image.FromStream(bitmapStream));

                    string screenshotFolderpath = "";
                    if (Directory.Exists(Setting.UserPicturesPath))
                    {
                        screenshotFolderpath = string.Format(@"{0}\Screenshot_{1}_{2}.jpg", Setting.UserPicturesPath, scenarioTitle, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                    }
                    else
                    {
                        screenshotFolderpath = Path.Combine(AssemblyDirectory, Setting.UserPicturesPath);
                        if (!Directory.Exists(screenshotFolderpath))
                        {
                            Directory.CreateDirectory(screenshotFolderpath);
                        }

                        screenshotFolderpath = string.Format(@"{0}\Screenshot_{1}_{2}.jpg", screenshotFolderpath, scenarioTitle, DateTime.Now.ToString("yyyyMMddHHmmssfff"));

                    }

                    image.Save(screenshotFolderpath);
                }
            }
            catch (Exception ex)
            {
                var sva = ex;
                // This try-catch is used so other AfterScenario hooks can be executed after this one. 
                // If there's a failure in a test (for example a button not being able to be clicked), then this AfterScenario fails
                // and the other AfterScenarios are not executed, causing the browser not to be disposed, for example.
            }

        }

        /// <summary>
        /// Use tag @Delete within feature files to delete CP if needed
        /// </summary>
        [AfterScenario("DeleteCP", Order = 1)]
        public void DeleteCP()
        {
            Console.WriteLine("LoginHooks->AfterScenario->DeleteCP");
            try
            {
                this.objectContainer.Resolve<CharterPartyActions>().Delete();
            }
            catch
            {
                // This try-catch is used so other AfterScenario hooks can be executed after this one. 
                // If there's a failure in a test (for example a button not being able to be clicked), then this AfterScenario fails
                // and the other AfterScenarios are not executed, causing the browser not to be disposed, for example.
            }
        }

        /// <summary>
        /// Always logout of fixture
        /// </summary>
        [AfterScenario(Order = 2)]
        public void AfterScenario()
        {
            Console.WriteLine("LoginHooks->AfterScenario->Logout");
            try
            {
                this.objectContainer.Resolve<SearchActs>().Logout();
            }
            catch
            {
                // This try-catch is used so other AfterScenario hooks can be executed after this one. 
                // If there's a failure in a test (for example a button not being able to be clicked), then this AfterScenario fails
                // and the other AfterScenarios are not executed, causing the browser not to be disposed, for example.
            }
        }
        #endregion

        /// <summary>
        /// Get Directory Name where this code is running
        /// </summary>
        public static string AssemblyDirectory
        {
            get
            {
                string codeBase = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }
    }
}