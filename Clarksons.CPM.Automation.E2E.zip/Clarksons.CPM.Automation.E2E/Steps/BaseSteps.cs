﻿using BoDi;
using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;
using Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs;
using Clarksons.CPM.Automation.POM.CommonPages;
using Clarksons.CPM.Automation.POM.CPM;
using Clarksons.CPM.Automation.POM.RecapManager;
using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities.Helper;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps
{
    public class BaseSteps
    {
        protected readonly IObjectContainer objectContainer;
        protected readonly ScenarioContext scenarioContext;

        protected LoginActs loginActs => Resolve<LoginActs>();
        protected SearchActs searchActs => Resolve<SearchActs>();
        protected CharterPartyActs charterPartyActs => Resolve<CharterPartyActs>();
        protected Login login => Resolve<Login>();
        protected PageActions page => Resolve<PageActions>();
        protected LoginActions loginActions => Resolve<LoginActions>();
        protected SearchActions search => Resolve<SearchActions>();
        protected CharterPartyActions charterParty => Resolve<CharterPartyActions>();
        protected CharterPartyEditorActions charterPartyEditor => Resolve<CharterPartyEditorActions>();
        protected CharterPartySearchPage charterPartySearchPage => Resolve<CharterPartySearchPage>();
        protected RecapPage recapPage => Resolve<RecapPage>();
        protected AdditionalClausesPage additionalClausesPage => Resolve<AdditionalClausesPage>();
        protected EditorPage editorPage => Resolve<EditorPage>();
        protected BPVOY5EditorPage bpvoy5editorPage => Resolve<BPVOY5EditorPage>();
        protected AttachmentsPage attachmentsPage => Resolve<AttachmentsPage>();
        protected HistoryPage historyPage => Resolve<HistoryPage>();
        protected HelperMethod helperMethod => Resolve<HelperMethod>();
        protected NavigationMenu navigationMenu => Resolve<NavigationMenu>();
        protected InvoicingPage invoicingPage => Resolve<InvoicingPage>();
        protected ExistingClausesPage existingClausesPage => Resolve<ExistingClausesPage>();
        protected DeclarationAlertsPage declarationAlertsPage => Resolve<DeclarationAlertsPage>();
        protected SummaryPage summaryPage => Resolve<SummaryPage>();
                
        public BaseSteps(IObjectContainer objectContainer)
        {
            this.objectContainer = objectContainer;
            this.scenarioContext = objectContainer.Resolve<ScenarioContext>();
        }

        private T Resolve<T>()
        {
            return this.objectContainer.Resolve<T>();
        }
    }
}