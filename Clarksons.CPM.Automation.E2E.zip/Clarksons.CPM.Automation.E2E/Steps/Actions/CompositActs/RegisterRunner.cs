﻿using BoDi;
using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;
using Coypu;
using System;

namespace Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs
{
    public class RegisterRunner
    {
        private readonly IObjectContainer objectContainer;

        public RegisterRunner(IObjectContainer objectContainer)
        {
            this.objectContainer = objectContainer;
        }

        private void Register<T>(Func<T> func)
        {
            // objectContainer.RegisterInstanceAs<T>(o => func());
        }

        public void RegisterStepRunners()
        {
            var browserSession = this.objectContainer.Resolve<BrowserSession>();
            this.objectContainer.RegisterInstanceAs(new LoginActs(new LoginActions(browserSession), new PageActions(browserSession)));
            this.objectContainer.RegisterInstanceAs(new SearchActs(new SearchActions(browserSession)));
            this.objectContainer.RegisterInstanceAs(new CharterPartyActs(new CharterPartyActions(browserSession)));
            // Register(() => new LoginActs(new LoginActions(browserSession)));
            // Register(() => new SearchActs(new SearchActions(browserSession)));
            // Register(() => new CharterPartyActs(new CharterPartyActions(browserSession)));
        }
    }
}