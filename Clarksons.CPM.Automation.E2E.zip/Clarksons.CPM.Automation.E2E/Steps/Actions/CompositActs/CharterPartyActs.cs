﻿using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs
{
    public class CharterPartyActs : BaseActs
    {
        private CharterPartyActions charterParty;
        private int numberOfVessels;
        private List<IEnumerable<string>> vessels = new List<IEnumerable<string>>();

        public CharterPartyActs(CharterPartyActions charterParty)
        {
            this.charterParty = charterParty;
        }

        public void CreateNewRecap(string broker, string charterer, string template)
        {
            charterParty.AddNewCharterParty();
            charterParty.SpecifyBroker(broker);
            charterParty.SpecifyCharterer(charterer);
            charterParty.SelectCharterPartyStyle(template);
            charterParty.CreateNew();
        }

        public void CreateVessels(int numberOfVessels, bool isFreetext = false)
        {
            this.numberOfVessels = numberOfVessels;
            for (int i = 0; i < numberOfVessels; i++)
            {
                this.vessels.Add(charterParty.CreateVessel(isFreetext));
            }
        }

        public void CheckVessels()
        {
            for (int i = 0; i < this.vessels.Count; i++)
            {
                charterParty.CheckVessel(i, this.vessels[i]);
            }
        }

        public void RemoveVessels(int numberOfVesselsToRemove)
        {
            var vesselsToRemove = new List<int>();
            var removedCount = 0;
            var random = new Random();
            int defaultVessel = 1;
            while (removedCount < numberOfVesselsToRemove)
            {
                foreach (var vessel in this.vessels.Skip(defaultVessel))
                {
                    if (random.NextDouble() >= 0.5)
                    {
                        charterParty.RemoveVessel(this.vessels.IndexOf(vessel) - 1);
                        this.vessels.Remove(vessel);
                        removedCount++;
                        break;
                    }
                }
            }
        }

        public void CheckVesselsRandomly()
        {
            var timesToCheck = 5;
            var random = new Random();
            for (int i = 0; i < this.vessels.Count * timesToCheck; i++)
            {
                var number = random.Next(0, this.vessels.Count);
                charterParty.CheckVessel(number, this.vessels[number]);
            }
        }

        public void ExportFixtureCharterParty()
        {
            charterParty.ClickExportButton();
            charterParty.ExportFixtureCharterParty();
        }

        public void ExportFixtureRecap()
        {
            charterParty.ClickExportButton();
            charterParty.ExportFixtureRecap();
        }

        public void ViewRecap()
        {
            if (IsAppCharterPartyManager)
            {
                charterParty.ViewRecap();
            }
            if (IsAppRecapManager)
            {
                charterParty.ViewMainDetails();
            }
        }
    }
}