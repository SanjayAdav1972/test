﻿using Clarksons.CPM.Automation.Utilities.Config;

namespace Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs
{
    public class BaseActs
    {
        public BaseActs() { }
        protected bool IsAppCharterPartyManager => Setting.Product == "CPM";
        protected bool IsAppRecapManager => Setting.Product == "RM";
    }
}