﻿using BoDi;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.Shared
{
    [Binding]
    public class SharedSteps : BaseSteps
    {
        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef
        public SharedSteps(IObjectContainer objectContainer) : base(objectContainer) { }
    }
}