﻿using BoDi;
using Clarksons.CPM.Automation.Utilities;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.Shared
{
    [Binding]
    public sealed class SearchSteps : BaseSteps
    {
        public SearchSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef
        [Given(@"I am at the Search page")]
        public void GivenIAmAtTheSearchPage()
        {
            search.Navigate();
            Retry.Timeout(()=>search.AtSearchPage(), 10);
        }

    }
}