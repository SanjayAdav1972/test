﻿using BoDi;
using Clarksons.CPM.Automation.Utilities;
using NUnit.Framework;
using Should.Fluent;
using System;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class MenuButtonsSteps : BaseSteps
    {
        public MenuButtonsSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [When(@"I click on send email notification button")]
        public void WhenIClickOnSendEmailNotificationButton()
        {
            recapPage.ClickEmailNotificationButton();
        }

        [Then(@"I verify Broker Automation user name and email appear as '(.*)'")]
        public void ThenIVerifyBrokerAutomationUserNameAndEmailAppearAsAnd(string notifiedUser)
        {
            Assert.AreEqual(notifiedUser, recapPage.EmailNotifiedUserName.Text);
            recapPage.ClickCloseDialog();
        }

        [When(@"I click on the copy link button")]
        public void WhenIClickOnTheCopyLinkButton()
        {
            recapPage.ClickCopyLinkButton();
        }

        [When(@"I add an IMONumber and a Vessel '(.*)' and '(.*)'")]
        [Then(@"I overwrite IMONumber and Vessel Name with '(.*)' and '(.*)'")]
        public void ThenIOverwriteIMONumberAndVesselNameWithAnd(string imoOverwrite, string vesselOverwrite)
        {
            recapPage.PopulatedImoNumber.SendKeys(imoOverwrite);
            recapPage.PopulatedVesselName.SendKeys(vesselOverwrite);
        }

        [Then(@"I Discard Changes")]
        public void ThenIDiscardChanges()
        {
            recapPage.ClickDiscardChangesButton();
            recapPage.ClickYesButton();
        }

        [Then(@"I Undo Changes")]
        public void ThenIUndoChanges()
        {
            Retry.Timeout(() => recapPage.ClickUndoButton(), 10);
            Retry.Timeout(() => recapPage.ClickUndoButton(), 10);
        }

        [Then(@"I Redo Changes")]
        public void ThenIRedoChanges()
        {
            Retry.Timeout(() => recapPage.ClickRedoButton(), 10);
            Retry.Timeout(() => recapPage.ClickRedoButton(), 10);
        }

        [When(@"I set the CP date")]
        public void WhenISetTheCPDate()
        {
            var cpDate = DateTime.Now.AddDays(2).ToString("dd-MM-yyyy");
            charterParty.SpecifyCPDate(cpDate);
        }
        
        [Then(@"I confirm all draft recap tab buttons are present")]
        public void ThenIConfirmAllDraftRecapTabButtonsArePresent()
        {
            recapPage.CopyLinkButton.Exists().Should().Be.True();
            recapPage.ToolbarDropDownMenu.Exists().Should().Be.True();
            recapPage.EmailNotificationButton.Exists().Should().Be.True();
            recapPage.UndoButton.Exists().Should().Be.True();
            recapPage.RedoButton.Exists().Should().Be.True();
            recapPage.DeleteButton.Exists().Should().Be.True();
            recapPage.DiscardChangesButton.Exists().Should().Be.True();
            recapPage.CreateACopyButton.Exists().Should().Be.False();
            recapPage.AddAdditionalClauseButton.Exists().Should().Be.True();
            recapPage.SaveButton.Exists().Should().Be.True();
        }

        [Then(@"I confirm draft editor buttons")]
        public void ThenIConfirmDraftEditorButtons()
        {
            recapPage.CopyLinkButton.Exists().Should().Be.True();
            recapPage.ToolbarDropDownMenu.Exists().Should().Be.True();
            recapPage.EmailNotificationButton.Exists().Should().Be.True();
            recapPage.UndoButton.Exists().Should().Be.False();
            recapPage.RedoButton.Exists().Should().Be.False();
            recapPage.DeleteButton.Exists().Should().Be.True();
            recapPage.DiscardChangesButton.Exists().Should().Be.True();
            recapPage.CreateACopyButton.Exists().Should().Be.False();
            recapPage.AddAdditionalClauseButton.Exists().Should().Be.True();
            recapPage.SaveButton.Exists().Should().Be.True();
        }

        [Then(@"I confirm all fully fixed recap tab buttons are present")]
        [Then(@"I confirm all on subs recap tab buttons are present")]
        public void ThenIConfirmAllOnSubsRecapTabButtonsArePresent()
        {
            recapPage.CopyLinkButton.Exists().Should().Be.True();
            recapPage.ToolbarDropDownMenu.Exists().Should().Be.True();
            recapPage.EmailNotificationButton.Exists().Should().Be.True();
            recapPage.UndoButton.Exists().Should().Be.True();
            recapPage.RedoButton.Exists().Should().Be.True();
            recapPage.DeleteButton.Exists().Should().Be.False();
            recapPage.DiscardChangesButton.Exists().Should().Be.True();
            recapPage.CreateACopyButton.Exists().Should().Be.True();
            recapPage.AddAdditionalClauseButton.Exists().Should().Be.True();
            recapPage.SaveButton.Exists().Should().Be.True();
        }

        [Then(@"I confirm fully fixed editor buttons")]
        [Then(@"I confirm on subs editor buttons")]
        public void ThenIConfirmOnSubsEditorButtons()
        {
            recapPage.CopyLinkButton.Exists().Should().Be.True();
            recapPage.ToolbarDropDownMenu.Exists().Should().Be.True();
            recapPage.EmailNotificationButton.Exists().Should().Be.True();
            recapPage.UndoButton.Exists().Should().Be.False();
            recapPage.RedoButton.Exists().Should().Be.False();
            recapPage.DeleteButton.Exists().Should().Be.False();
            recapPage.DiscardChangesButton.Exists().Should().Be.True();
            recapPage.CreateACopyButton.Exists().Should().Be.True();
            recapPage.AddAdditionalClauseButton.Exists().Should().Be.True();
            recapPage.SaveButton.Exists().Should().Be.True();
        }


        [Then(@"I confirm there are no buttons")]
        public void ThenIConfirmThereAreNoButtons()
        {
            recapPage.CopyLinkButton.Exists().Should().Be.False();
            recapPage.ToolbarDropDownMenu.Exists().Should().Be.False();
            recapPage.EmailNotificationButton.Exists().Should().Be.False();
            recapPage.UndoButton.Exists().Should().Be.False();
            recapPage.RedoButton.Exists().Should().Be.False();
            recapPage.DeleteButton.Exists().Should().Be.False();
            recapPage.DiscardChangesButton.Exists().Should().Be.False();
            recapPage.CreateACopyButton.Exists().Should().Be.False();
            recapPage.AddAdditionalClauseButton.Exists().Should().Be.False();
            recapPage.SaveButton.Exists().Should().Be.False();
        }
    }
}