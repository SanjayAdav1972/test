﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BoDi;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class RecapManagerSteps : BaseSteps
    {
        private IEnumerable<string> preambleInputs;
        private IEnumerable<string> vesselInputs;
        private IEnumerable<string> fixtureInputs;
        protected BrowserSession _browserSession;
        string filePath = Setting.UserDownloadPath;
        public string pageUrlOriginal { get; set; }

        public RecapManagerSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [StepDefinition(@"I see specific clauses '(.*)' displayed on editor tab for templates '(.*)'")]
        public void ISeeSpecificClausesDisplayedOnEditorTabForTemplates(string p_SpecificClauses, string p_TemplateName)
        {
            switch (p_TemplateName)
            {
                case "BPVOY4":
                    if (!existingClausesPage.BPVOY4Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY5":
                    if (!existingClausesPage.BPVOY5Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4CLEARLAKE":
                    if (!existingClausesPage.BPVOY4CLEARLAKEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4STVOY2006":
                    if (!existingClausesPage.BPVOY4STVOY2006Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4STVOY2010":
                    if (!existingClausesPage.BPVOY4STVOY2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOL2006":
                    if (!existingClausesPage.BPVOY4VITOL2006Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOL2010":
                    if (!existingClausesPage.BPVOY4VITOL2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOLTORM2007":
                    if (!existingClausesPage.BPVOY4VITOLTORM2007Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOLMANSEL":
                    if (!existingClausesPage.BPVOY4VITOLMANSELClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005":
                    if (!existingClausesPage.EXXONMOBILVOY2005Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005SOCAR2010":
                    if (!existingClausesPage.EXXONMOBILVOY2005SOCAR2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005VALERO":
                    if (!existingClausesPage.EXXONMOBILVOY2005VALEROClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "OMVOY2001":
                    if (!existingClausesPage.OMVOY2001Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "SHELLVOY6-V1-1-APR06":
                    if (!existingClausesPage.SHELLVOY6Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "SHELLTIME4":
                    if (!existingClausesPage.SHELLTIME4Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONVOY84SCANPORT":
                    if (!existingClausesPage.EXXONVOY84SCANPORTClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005TESORO":
                    if (!existingClausesPage.EXXONMOBILVOY2005TESOROClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONVOY84":
                    if (!existingClausesPage.EXXONVOY84Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ASBATANKVOY1977":
                    if (!existingClausesPage.ASBAClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BOXTIMEMAERSK":
                    if (!existingClausesPage.BOXTIMEMAERSKClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BOXTIME":
                    if (!existingClausesPage.BOXTIMEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "GENCON1994":
                    if (!existingClausesPage.Gencon94Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "YARACHARTER":
                    if (!existingClausesPage.YaraCharterClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "AMWELSH1993":
                    if (!existingClausesPage.AMWELSH93Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ANGLOAMERICAN":
                    if (!existingClausesPage.ANGLOAMERICANClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NORGRAIN74":
                    if (!existingClausesPage.NORGRAIN74Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NORGRAIN89":
                    if (!existingClausesPage.NORGRAIN89Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "HYDROCHARTER2017":
                    if (!existingClausesPage.HYDROCHARTER2017Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "TATASTEELGATE":
                    if (!existingClausesPage.TATASTEELGATEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "RTMVOY1Q15":
                    if (!existingClausesPage.RTMVOY1Q15Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BALTIMOREBERTHCP1913":
                    if (!existingClausesPage.BALTIMOREClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "GENCON76":
                    if (!existingClausesPage.GENCON76Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ROYHILL":
                    if (!existingClausesPage.ROYHILLClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "VALEVOY2014":
                    if (!existingClausesPage.VALEVOY2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BHPBVOY2014":
                    if (!existingClausesPage.BHPBVOY2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NYPE93":
                    if (!existingClausesPage.NYPE93Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ARCELORMITTALIRONORECP2014":
                    if (!existingClausesPage.ARCELORMITTALIRONORECP2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EUROMED1997":
                    if (!existingClausesPage.EUROMED1997Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "FMGVOY2012":
                    if (!existingClausesPage.FMGVOY2012Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NYPE81":
                    if (!existingClausesPage.NYPE81Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW FORM TEMPLATE");
                    break;
            }

            System.Threading.Thread.Sleep(5000);
        }

        [StepDefinition(@"I click on export Fixture Charter Party")]
        public void IClickOnExportFixtureCharterParty()
        {
            recapPage.ClickOnExportFixtureCharterParty();
        }

        [Then(@"I see my file has been downloaded successfully")]
        public void ISeeMyFileHasBeenDownloadedSuccessfully()
        {
            int timeOutPeriod = 90;
            if (ScenarioContext.Current["TemplateName"].ToString() == "RTMVOY1Q15" || ScenarioContext.Current["TemplateName"].ToString() == "VALEVOY2014")
            {
                timeOutPeriod = 300;
            }

            bool fileDownloaded = false;
            //Retry.Timeout(() => Assert.IsTrue(FileHelper.CheckFileExist("Export*.pdf", $"-{page.GetCPId()}-")), timeOutPeriod);
            Retry.Timeout(() => fileDownloaded = FileHelper.CheckFileExist("Export*.pdf", $"-{page.GetCPId()}-"), timeOutPeriod);
            Console.WriteLine("download status {0}", fileDownloaded);
        }

    }
}
