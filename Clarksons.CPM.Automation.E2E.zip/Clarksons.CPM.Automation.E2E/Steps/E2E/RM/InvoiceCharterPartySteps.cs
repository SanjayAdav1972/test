﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BoDi;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class CharterPartyBPVOYSteps : BaseSteps
    {
        public CharterPartyBPVOYSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [StepDefinition(@"I change status to '(.*)'")]
        public void ThenIChangeStatusFromDraftToFullyFixed(string status)
        {
            var click = new Dictionary<string, Func<object>>()
            {
                { "draft", recapPage.ClickDraftStatus },
                { "on subs", recapPage.ClickOnSubsStatus },
                { "working copy", recapPage.ClickWorkingCopyStatus },
                { "fully fixed", recapPage.ClickFullyFixedStatus },
                { "final", recapPage.ClickFinalStatus },
                { "cancelled", recapPage.ClickCancelledStatus }
            };

            click[status.ToLower()]();
        }
    }
}
