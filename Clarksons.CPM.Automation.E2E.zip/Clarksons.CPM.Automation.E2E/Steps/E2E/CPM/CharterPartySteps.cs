﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BoDi;
using Clarksons.CPM.Automation.E2E.Data.Fields;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Data;
using Clarksons.CPM.Automation.Utilities.Helper;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.CPM
{
    [Binding]
    public sealed class CharterPartySteps : BaseSteps
    {
        private IEnumerable<string> preambleInputs;
        private IEnumerable<string> vesselInputs;
        private IEnumerable<string> fixtureInputs;
        private IEnumerable<string> detailsInput;
        private IEnumerable<string> contactDetailsInput;

        public CharterPartySteps(IObjectContainer objectContainer) : base(objectContainer) { }

        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef

        [StepDefinition(@"I click on create a new Recap")]
        [StepDefinition(@"I click on create a new Charter Party")]
        public void WhenIClickOnCreateANewCharterParty()
        {
            charterParty.AddNewCharterParty();
        }

        [StepDefinition(@"I enter '(.*)' and '(.*)' to create template '(.*)'")]
        public void GivenIEnterAndToCreateTemplate(string broker, string charterer, string p_Template)
        {
            charterParty.SpecifyBroker(broker);
            charterParty.SpecifyCharterer(charterer);
            charterParty.SelectCharterPartyStyle(p_Template);
            charterParty.CreateNew();
        }
        
        [StepDefinition(@"I enter Broker Company and Charterer Company to create template '(.*)'")]
        public void WhenIEnterAndToCreateTemplate(string p_Template)
        {
            ScenarioContext.Current["TemplateName"] = p_Template;
            charterParty.SpecifyBroker(Setting.Company.Broker);
            charterParty.SpecifyCharterer(Setting.Company.Charterer);
            charterParty.SelectCharterPartyStyle(p_Template);
            charterParty.CreateNew();
        }

        [StepDefinition(@"I click on Save button")]
        public void ThenIClickOnSaveButton()
        {
            recapPage.ClickOnSaveButton();
            Retry.Timeout(() => Assert.IsTrue(!recapPage.SaveButton.Disabled), 30);
        }

        [StepDefinition(@"I should see toast message '(.*)'")]
        public void ThenIShouldSeeToastMessage(string p_ToastMessage)
        {
            CodeHelper.CanFail(() =>
            {
                if (!string.IsNullOrWhiteSpace(p_ToastMessage))
                    helperMethod.VerifyThatToastMessageSays(p_ToastMessage);
            });
        }

        [StepDefinition(@"I verify the status as '(.*)'")]
        public void WhenIVerifyTheStatusAsDraft(string status)
        {
            //Console.WriteLine(status);
            Retry.Timeout(() => Assert.AreEqual(summaryPage.CpmStatus.SelectedOption.ToString(), status), 10);
        }
               
        [StepDefinition(@"I enter contact details under summary tab")]
        public void ThenIEnterContactDetailsUnderSummaryTab()
        {
            charterParty.WaitUntilLoaded();
            var cpDate = DateTime.Now.AddDays(2).ToString("dd-MM-yyyy");
            charterParty.SpecifyCPDate(cpDate);

            var details = summaryPage.DetailsHeader;
            var contactDetails = summaryPage.ContactDetailsHeader;
            //Enter Details empty fields
            this.detailsInput = details.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { });
            //Enter contact details empty fields
            this.contactDetailsInput = contactDetails.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
        }

        [StepDefinition(@"I verify Audit History with events as '(.*)'")]
        public void WhenIVerifyAuditHistoryWithEventsAs(string eventDescription)
        {
            switch (eventDescription)
            {
                case "Prepare CP":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditPrepareCP.Text, eventDescription), 10);
                    break;
                case "Draft To Final":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditDraft2Final.Text, eventDescription), 10);
                    break;
                case "Final To Draft":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditFinal2Draft.Text, eventDescription), 10);
                    break;
                case "Draft To Working Copy":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditDraft2WorkingCopy.Text, eventDescription), 10);
                    break;
                case "Working Copy To Draft":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditWorkingCopy2Draft.Text, eventDescription), 10);
                    break;
                default:
                    Console.WriteLine("No aUDIT hISTORY appear. /nSomething wrong while writing Audit History.");
                    break;
            }
        }

        [StepDefinition(@"I navigate to Attachments tab")]
        public void ThenINavigateToAttachmentsTab()
        {
            attachmentsPage.ClickOnAttachments();
        }

        [StepDefinition(@"I navigate to History tab")]
        public void WhenINavigateToHistoryTab()
        {
            historyPage.ClickOnHistory();
        }

        [StepDefinition(@"I am able to attach documents")]
        public void ThenIAmAbleToAttachDocuments()
        {
            string FileName = $@"Data\CPM\SampleAttachment.xlsx";
            string attachmentFileName = "I successfully attached document";
            attachmentsPage.AddAttachment(FileName, attachmentFileName);
            //attachmentsPage.DescriptionText.SendKeys(attachmentFileName);
            attachmentsPage.CreateButton.Click();
            //var actualAttachmentText = attachmentsPage.GetAttachedDocumentText();
            //Assert.IsTrue(actualAttachmentText.Contains(attachmentFileName.ToLower()), "Additional clause title {0} but was {1}", attachmentFileName, actualAttachmentText);
        }

        [StepDefinition(@"I download my attachment")]
        public void ThenIDownloadMyAttachment()
        {
            attachmentsPage.ClickOnAttachmentDownload();
        }

        [StepDefinition(@"I delete my attachment")]
        public void ThenIDeleteMyAttachment()
        {
            attachmentsPage.ClickOnAttachmentDelete();
        }

        [StepDefinition(@"I see that my attchment has been deleted")]
        public void ThenISeeThatMyAttchmentHasBeenDeleted()
        {
            Assert.AreEqual(attachmentsPage.NoAttachmentsFound.Text, "No Attachment(s) found.");
        }

        [StepDefinition(@"I see my attachment has been downloaded successfully")]
        public void ThenISeeMyAttachmentHasBeenDownloadedSuccessfully()
        {
            Retry.Timeout(() => Assert.IsTrue(FileHelper.CheckFileExist("Sample*.xlsx")), 60);
        }

        [StepDefinition(@"I navigate to Recap tab")]
        public void ThenINavigateToRecapTab()
        {
            Retry.Timeout(() => recapPage.ClickOnRecapTab(), 5);
        }

        [StepDefinition(@"I search for Vessel details with ImoNumber '(.*)'")]
        public void WhenISearchForVesselDetailsWithImoNumber(string p_ImoNumber)
        {
            recapPage.EnterQ88Number(p_ImoNumber);
            //recapPage.PreambleHeader.ClickElement();
        }

        [When(@"I enter values into all blank fields on Recap tab")]
        public void WhenIEnterValuesIntoAllBlankFieldsOnRecapTab()
        {
            var preambleHeader = recapPage.PreambleHeader;
            var vesselDescriptionHeader = recapPage.VesselDesriptionHeader;
            var fixtureMainTermsHeader = recapPage.FixtureMainTermsHeader;

            //Enter Preamble empty fields
            this.preambleInputs = preambleHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { "RegisteredOwner", "CommercialOperator", "OwnerGroup" });
            //Enter Vessel empty fields
            this.vesselInputs = vesselDescriptionHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
            //Enter Fixture empty fields
            this.fixtureInputs = fixtureMainTermsHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });

        }
    }
}
