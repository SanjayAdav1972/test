﻿using Coypu.Drivers;
using Coypu.Drivers.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using System;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu.WebDriver
{
    public class CustomRemoteDriver : SeleniumWebDriver
    {
        public CustomRemoteDriver(Uri remoteAppHost, Browser browser, ICapabilities capabilities) : 
            base(new RemoteWebDriver(remoteAppHost, capabilities), browser) {}
    }
}