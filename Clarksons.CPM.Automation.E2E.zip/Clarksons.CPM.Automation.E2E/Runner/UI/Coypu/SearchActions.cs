﻿using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using OpenQA.Selenium;
using Should.Fluent;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class SearchActions : BaseActions
    {
        private readonly Search search;
        public SearchActions(BrowserSession browserSession) : base(browserSession)
        {
            this.search = new Search(browserSession);
        }

        internal void Navigate()
        {
            driver.Visit("/#/search");
        }

        public void AtSearchPage()
        {
            if (search.CloseButton.Exists())
            {
                search.CloseButton.ClickElement();
            }
            search.SearchInput.Exists().Should().Be.True();
        }

        public void Logout()
        {
            search.Logout.ClickElement();
        }

        public void LogoutIgnoreSaveChanges()
        {
            search.Logout.ClickElement();
            ((IWebDriver)driver.Native).AlertIgnore();
        }

        public void ClickShowMenu()
        {
            search.ShowMenu.ClickElement();
        }

        public void SelectStatusFilter(string status)
        {
            CheckSearch(statusFilters()[status.ToLower()]());
        }

        public void UnselectStatusFilter(string status)
        {
            UncheckSearch(statusFilters()[status.ToLower()]());
        }

        public void EditAnyRow()
        {
            driver.HasNoContent("No Results");
            search.Results.WithAny().FindCss("div.icon--edit").ClickElement();
        }

        public void ViewAnyRow()
        {
            driver.HasNoContent("No Results");
            search.Results.WithAny().FindCss("div.icon--visibility").ClickElement();
        }

        private Dictionary<string, Func<ElementScope>> statusFilters()
        {
            return new Dictionary<string, Func<ElementScope>>()
            {
                { "draft", () => search.DraftStatusFilter },
                { "on subs", () => search.OnSubsStatusFilter },
                { "working copy", () => search.WorkingCopyStatusFilter },
                { "final", () => search.FinalStatusFilter },
                { "fully fixed", () => search.FullyFixedStatusFilter },
                { "cancelled", () => search.CancelledStatusFilter },
                { "failed", () => search.FailedStatusFilter }
            };
        }

        protected void UncheckSearch(ElementScope elementScope)
        {
            if (SearchCheckBoxIsChecked(elementScope))
            {
                elementScope.ClickElement();
            }
        }

        protected void CheckSearch(ElementScope elementScope)
        {
            if (SearchCheckBoxIsUnChecked(elementScope))
            {
                elementScope.ClickElement();
            }
        }

        private bool SearchCheckBoxIsUnChecked(ElementScope elementScope)
        {
            var checkbox = elementScope.FindCss("div.search-checkbox-main");
            var unChecked = checkbox.HasClass("unchecked");
            return unChecked;
        }

        private bool SearchCheckBoxIsChecked(ElementScope elementScope)
        {
            return !SearchCheckBoxIsUnChecked(elementScope);
        }

        public void CheckEntryIsAtTopOfSearchResults(string v)
        {
            WaitUntilLoaded();
            search.Results.First().Text.Should().Contain(v);
        }

        public void SelectSearchOption(string document)
        {
            search.SearchInput.SendKeys(document);
            driver.FindLink("Layout: " + document).ClickElement();
        }

        public void UnselectAllStatusFilters()
        {
            AtSearchPage();
            search.AllStatusFilters.ToList().ForEach(UncheckSearch);
            driver.HasContent("No Results").Should().Be.True();
        }

        public void CheckOnlyRowsWithStatusAreListed(string status)
        {
            search.Results.ToList().ForEach(row =>
            {
                var statusField = row.FindCss("span.cpm-status");
                statusField.Text.Should().Equal(status);
            });
        }

        public void ViewAdvancedSearchOptions()
        {
            search.AdvancedSearch.ClickElement();
        }

        public void CreatedVesselNameShouldBe(string v)
        {
            search.AdvancedVesselName.Value.Should().Equal(v);
        }

        public void DateMinShouldBe(string v)
        {
            search.AdvancedSearchDateMin.Value.Should().Equal(v);
        }

        public void ChartererShouldBe(string v)
        {
            search.AdvancedSearchCharterer.Value.Should().Equal(v);
        }

        public void CpFormShouldBe(string v)
        {
            search.AdvancedSearchCpForm.Value.Should().Equal(v);
        }

        public void DateMaxShouldBe(string v)
        {
            search.AdvancedSearchDateMax.Value.Should().Equal(v);
        }

        public void OwnerShouldBe(string v)
        {
            search.AdvancedSearchOwner.Value.Should().Equal(v);
        }

        public void NamedUserShouldBe(string v)
        {
            search.AdvancedSearchNamedUser.Value.Should().Equal(v);
        }

        public void CheckSearchStatusOptionIsSelected(string statusOption)
        {
            SearchCheckBoxIsChecked(statusFilters()[statusOption.ToLower()]());
        }

        public void CheckSearchStatusOptionIsNotSelected(string statusOption)
        {
            SearchCheckBoxIsUnChecked(statusFilters()[statusOption.ToLower()]());
        }

        public void CreatedCreatedByShouldBe(string v)
        {
            search.AdvancedSearchCreatedBy.Value.Should().Equal(v);
        }

        public void SaveSearchDefaults()
        {
            search.AdvancedSearchSaveDefaults.ClickElement();
        }

        public void SetVesselNameAs(string value)
        {
            search.AdvancedVesselName.Enter(value);
        }

        public void SetCreatedByAs(string value)
        {
            search.AdvancedSearchCreatedBy.Enter(value);
        }

        public void SetDateMinAs(string value)
        {
            search.AdvancedSearchDateMin.Enter(value);
        }

        public void SetChartererAs(string value)
        {
            search.AdvancedSearchCharterer.Enter(value);
        }

        public void SetCPFormAs(string value)
        {
            search.AdvancedSearchCpForm.Enter(value);
        }

        public void SetDateMaxAs(string value)
        {
            search.AdvancedSearchDateMax.Enter(value);
        }

        public void SetOwnerAs(string value)
        {
            search.AdvancedSearchOwner.Enter(value);
        }

        public void SetNamedUserAs(string value)
        {
            search.AdvancedSearchNamedUser.Enter(value);
        }
    }
}
