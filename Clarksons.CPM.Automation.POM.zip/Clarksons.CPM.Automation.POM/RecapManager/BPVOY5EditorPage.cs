﻿using Coypu;

namespace Clarksons.CPM.Automation.POM.RecapManager
{
    public class BPVOY5EditorPage
    {
        protected BrowserSession _browserSession;
        public BPVOY5EditorPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Editor page objects
        public ElementScope AdditionalClauseTitle => _browserSession.FindXPath(".//*[@id='inlineTemplateEditor']/div/table[34]/tbody/tr[1]/td");
        #endregion

        #region Editor page methods
        public string VerifyAdditionalClauseOnBPVOY5()
        {
            return AdditionalClauseTitle.Text;
        }
        #endregion
    }
}