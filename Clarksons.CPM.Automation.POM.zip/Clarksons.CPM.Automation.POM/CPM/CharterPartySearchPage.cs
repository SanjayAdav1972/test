﻿using Clarksons.CPM.Automation.POM.Shared;
using Coypu;

namespace Clarksons.CPM.Automation.POM.CPM
{
    public class CharterPartySearchPage
    {
        private readonly BrowserSession _browserSession;
        public CharterParty charterParty { get; }

        public CharterPartySearchPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }
    }
}