﻿using Coypu;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.POM.CPM
{
    public class CpmSearch
    {
        private readonly BrowserSession _browserSession;
        public CpmSearch(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        public ElementScope GoSearch => _browserSession.FindCss("[ng-click='vm.goSearch()']");
        public ElementScope DraftCheckBox => _browserSession.FindCss("[ng-click='vm.searchFilters.Draft = !vm.searchFilters.Draft;vm.performSearch();']");
        public ElementScope OnSubsCheckBox => _browserSession.FindCss("[ng-click='vm.searchFilters.OnSubs = !vm.searchFilters.OnSubs;vm.performSearch();']");
        public ElementScope FullyFixedCheckBox => _browserSession.FindCss("[ng-click='vm.searchFilters.FullyFixed = !vm.searchFilters.FullyFixed;vm.performSearch();']");
        public ElementScope CancelledCheckBox => _browserSession.FindCss("[ng-click='vm.searchFilters.Cancelled = !vm.searchFilters.Cancelled;vm.performSearch();']");
        //public ElementScope DraftIcon => _browserSession.FindAllCss("DIV[ng-if='result.Status == 0']", cell => cell.Any());
        public IEnumerable<SnapshotElementScope> DraftIcon => _browserSession.FindAllCss("DIV[ng-if='result.Status == 0']", cell => cell.Any());
        public IEnumerable<SnapshotElementScope> OnSubsIcon => _browserSession.FindAllCss("DIV[ng-if='result.Status == 1']", cell => cell.Any());
        public IEnumerable<SnapshotElementScope> FullyFixedIcon => _browserSession.FindAllCss("DIV[ng-if='result.Status == 2']", cell => cell.Any());
        public IEnumerable<SnapshotElementScope> CancelledIcon => _browserSession.FindAllCss("DIV[ng-if='result.Status == 3']", cell => cell.Any());
        public ElementScope FullyFixeFirstEditIcondIcon => _browserSession.FindCss("DIV[ng-click='vm.editCp(result.CpName, result.CpId)']");
        public ElementScope NoResult => _browserSession.FindField("No Results");
    }
}