﻿using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Clarksons.CPM.Automation.POM.CPM
{
    public class SummaryPage : BasePageObject
    {
        private readonly BrowserSession _browserSession;
        public SummaryPage(BrowserSession browserSession) : base(browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Summary page objects
        public ElementScope DetailsHeader => _browserSession.FindCss(".col-md-6 cpm-cp-details-component");
        public ElementScope ContactDetailsHeader => _browserSession.FindXPath("//div[@class='summary-tab']/div[2]");
        public ElementScope AddUsers => _browserSession.FindButton("Add Users");
        public ElementScope UserWithinCompany => _browserSession.FindXPath("//div[contains(text(),'Share with')]/following-sibling::div[1]/div[2]/div");
        public ElementScope SelectCompany => _browserSession.FindXPath("//select[@ng-model='vm.company']");
        public ElementScope CompanyClarksonsIT => _browserSession.FindXPath("//select[@ng-model='vm.company']/option[contains(text(),'Clarksons Cloud Limited')]");
        public ElementScope UsersNameField => Css(".form-control.cpm-share-cp-name.ng-pristine.ng-untouched.ng-valid.ng-valid-editable.ng-empty");
        public ElementScope UserNameOption => _browserSession.FindXPath("//li[contains(@id, 'typeahead-')]");
        public ElementScope AddButton => _browserSession.FindId("cpm-share-button");
        public ElementScope ShareButton => Button("SHARE");
        public ElementScope MessageBoardButton => _browserSession.FindXPath("//div[contains(@class,'message-board-show-button')]");
        public ElementScope MessageText => _browserSession.FindXPath("//div[@class='message-board-content']//div/textarea[@placeholder='Add Message for all...']");
        public ElementScope AddMessage => Button("Send Message");
        public ElementScope SentMessage => _browserSession.FindXPath("//div[@class='message-board-content messages-sent angular-ui-tree']//li[1]/div/div[contains(@class,\'sent-message-text\')]");
        public ElementScope ReplyMessageText => _browserSession.FindXPath("//li[@message-index='message-0']//ol//div[contains(@class,'sent-message-text')]");
        public ElementScope ReplyMessageTextArea => _browserSession.FindXPath("//li[@message-index='message-0']//textarea");
        public ElementScope SendButton => Button("Send");
        public ElementScope ApprovalsHeader => _browserSession.FindXPath("//h2[contains(text(),'Approvals')]");
        public ElementScope ApprovalToggleButton => _browserSession.FindXPath("//span[@id='enabled']/small");
        public ElementScope AddApprovalsButton => Button("Add Approval");
        public ElementScope ConfirmButton => Button("CONFIRM");
        public ElementScope OwnerField => _browserSession.FindXPath("//input[@ng-model='vm.owner']");
        public ElementScope ChartererField => _browserSession.FindXPath("//input[@ng-model='vm.charterer']");
        public ElementScope CPDownloadPdfFile => _browserSession.FindXPath("//tr[@id='cp-approval-0']//a");
        public ElementScope PrepareButton => Button("Prepare");
        public ElementScope BrokerApprovalStatus => _browserSession.FindId("cp-approval-prepared");
        public ElementScope DraftToWCStatus => _browserSession.FindXPath("//p[contains(text(),'Draft To Working Copy')]");
        public ElementScope WCToFinalStatus => _browserSession.FindXPath("//p[contains(text(),'Working Copy To Final')]");
        public ElementScope ChartererApproveButton => _browserSession.FindId("cp-charterer-approve");
        public ElementScope ChartererRejectButton => _browserSession.FindId("cp-charterer-reject");
        public ElementScope ChartererApproveOnBehalfOfButton => Button("Approve on behalf of Charterer ");
        public ElementScope ChartererApprovedStatus => _browserSession.FindId("cp-charterer-approved");
        public ElementScope ChartererRejectedStatus => _browserSession.FindId("cp-charterer-rejected");
        public ElementScope ChartererApprovedOnBehalfStatus => _browserSession.FindId("cp-charterer-approved");
        public ElementScope OwnerApproveButton => _browserSession.FindId("cp-owner-approve");
        public ElementScope OwnerRejectButton => _browserSession.FindId("cp-owner-reject");
        public ElementScope OwnerApproveOnBehalfOfButton => Button("Approve on behalf of Owner ");
        public ElementScope OwnerApprovedStatus => _browserSession.FindId("cp-owner-approved");
        public ElementScope OwnerRejectedStatus => _browserSession.FindId("cp-owner-rejected");
        public ElementScope ChartererSignElectronically => _browserSession.FindId("charterer-sign-electronically");
        public ElementScope OwnerSignElectronically => _browserSession.FindId("owner-sign-electronically");
        public ElementScope RejectionReason => _browserSession.FindXPath("//textarea[@ng-model='vm.reason']");
        public ElementScope RejectedByCharterer => _browserSession.FindXPath("//span[contains(text(),'rejected by Charterer')]");
        public ElementScope RejectedByOwner => _browserSession.FindXPath("//span[contains(text(),'rejected by Owner')]");
        public ElementScope ApprovedOnBehalfOfCharterer => _browserSession.FindXPath("//span[contains(text(),'Approved on behalf of Charterer')]");
        public ElementScope ApprovedOnBehalfOfOwner => _browserSession.FindXPath("//span[contains(text(),'Approved on behalf of Owner')]");
        public ElementScope FirstCPFromSearchResults => _browserSession.FindXPath("//tbody[@class='cpm-cp-search-results-container-body']/tr[1]");

        public ElementScope CpmStatus => _browserSession.FindXPath("//select[@ng-model='vm.model.CP.Status']");
        public ElementScope AuditPrepareCP => _browserSession.FindXPath("//h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]//..//span[contains(text(),'Prepare CP')]");
        public ElementScope AuditDraft2Final => _browserSession.FindXPath("//h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]//..//span[contains(text(),'Draft To Final')]");
        public ElementScope AuditFinal2Draft => _browserSession.FindXPath("//h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]//..//span[contains(text(),'Final To Draft')]");
        public ElementScope AuditDraft2WorkingCopy => _browserSession.FindXPath("//h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]//..//span[contains(text(),'Draft To Working Copy')]");
        public ElementScope AuditWorkingCopy2Draft => _browserSession.FindXPath("//h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]//..//span[contains(text(),'Working Copy To Draft')]");

        // //h2[@class='cpm-form-group-heading cpm-bg-primary' and contains(text(),'Audit History')]
        #endregion

        #region Summary page methods
        public SummaryPage ClickOnAddUsers()
        {
            AddUsers.Click();
            return this;
        }

        public SummaryPage ClickOnUserWithinCompany()
        {
            UserWithinCompany.Click();
            return this;
        }

        public SummaryPage EnterCompanyUser(string userName)
        {
            CompanyClarksonsIT.Click();
            Retry.Timeout(() => UsersNameField.Enter(userName), 10);
            UserNameOption.Click();
            return this;
        }

        public SummaryPage ClickAdd()
        {
            AddButton.Click();
            return this;
        }

        public SummaryPage ClickOnMessageBoard()
        {
            Retry.Timeout(() => MessageBoardButton.Click(), 10);
            return this;
        }

        public SummaryPage EnterMessage(string message)
        {
            MessageText.Enter(message);
            AddMessage.Click();
            Thread.Sleep(TimeSpan.FromSeconds(5));
            return this;
        }

        public string GetSentMessage()
        {
            string sentText = SentMessage.Text.ToLower();
            return sentText;
        }

        public string GetReplyMessage()
        {
            string replyText = ReplyMessageText.Text.ToLower();
            return replyText;
        }

        public string GetUrl()
        {
            HelperMethod hm = new HelperMethod(_browserSession);
            string cpURL = hm.GetPageUrl().ToLower();
            return cpURL;
        }

        public void GotoCPFixture()
        {
            FirstCPFromSearchResults.Click();
        }

        public SummaryPage EnterReplyMessage(string replyMessage)
        {
            SentMessage.Click();
            ReplyMessageTextArea.Click();
            ReplyMessageTextArea.Enter(replyMessage);
            SendButton.Click();
            return this;
        }

        public SummaryPage ClickApprovalButton()
        {
            ApprovalToggleButton.ClickElement();
            return this;
        }

        public SummaryPage ClickAddApproval()
        {
            AddApprovalsButton.Click();
            return this;
        }

        public SummaryPage EnterOwnerDetails(string owner)
        {
            OwnerField.SendKeys(owner);
            _browserSession.ClickLink(owner, options: new Options()
            {
                Timeout = TimeSpan.FromSeconds(15)
            });
            return this;
        }

        public SummaryPage EnterChartererDetails(string charterer)
        {
            HelperMethod hm = new HelperMethod(_browserSession);
            var chartererField = hm.FindElement(By.XPath("//input[@ng-model='vm.charterer']"));
            chartererField.Clear();
            chartererField.SendKeys(charterer);
            _browserSession.ClickLink(charterer, options: new Options()
            {
                Timeout = TimeSpan.FromSeconds(15)
            });
            return this;
        }

        public SummaryPage ClickConfirm()
        {
            ConfirmButton.Click();
            Thread.Sleep(TimeSpan.FromSeconds(15));
            return this;
        }

        public SummaryPage ClickRejectionConfirm()
        {
            ConfirmButton.Click();
            return this;
        }

        public SummaryPage ClickCPDownloadPdf()
        {
            CPDownloadPdfFile.Click();
            return this;
        }

        public SummaryPage ClickOnPrepare()
        {
            PrepareButton.ClickElement();
            return this;
        }

        public string GetBrokerApprovalStatusText()
        {
            ApprovalsHeader.Click();
            string statusText = BrokerApprovalStatus.Text.ToLower();
            return statusText;
        }

        public string GetWorkingCopyCPStatus()
        {
            string cpStatusText = DraftToWCStatus.Text.ToLower();
            return cpStatusText;
        }

        public SummaryPage ClickOnChartererRequestLink(string requestLink)
        {
            HelperMethod helperMethod = new HelperMethod(_browserSession);
            Action action = null;
            switch (requestLink)
            {
                case "Approve":
                    action = () => ChartererApproveButton.Click();
                    break;
                case "Reject":
                    action = () => ChartererRejectButton.Click();
                    break;
                case "Approve on behalf of Charterer":
                    action = () => ChartererApproveOnBehalfOfButton.Click();
                    break;
                default:
                    action = () => helperMethod.CreateSoftAssertion("No request link found");
                    break;
            }

            Retry.Timeout(action, 5);

            return this;
        }

        public string GetChartererApprovedStatus()
        {
            string chartererApprovalStatus = ChartererApprovedStatus.Text.ToLower();
            return chartererApprovalStatus;
        }

        public string GetChartererRejectedStatus()
        {
            string chartererRejectedStatus = ChartererRejectedStatus.Text.ToLower();
            return chartererRejectedStatus;
        }

        public string GetChartererApprovedOnBehalfStatus()
        {
            string chartererApprovedOnBehalfStatus = ChartererApprovedStatus.Text.ToLower();
            return chartererApprovedOnBehalfStatus;
        }

        public SummaryPage ClickOnOwnerRequestLink(string requestLink)
        {
            HelperMethod helperMethod = new HelperMethod(_browserSession);
            switch (requestLink)
            {
                case "Approve":
                    Retry.Timeout(() => OwnerApproveButton.Click(), 10);
                    break;
                case "Reject":
                    Retry.Timeout(() => OwnerRejectButton.Click(), 10);
                    break;
                case "Approve on behalf of Owner":
                    Retry.Timeout(() => OwnerApproveOnBehalfOfButton.Click(), 10);
                    break;
                default:
                    helperMethod.CreateSoftAssertion("No request link found");
                    break;
            }

            return this;
        }

        public string GetOwnerApprovedStatus()
        {
            string ownerApprovalStatus = OwnerApprovedStatus.Text.ToLower();
            return ownerApprovalStatus;
        }

        public string GetOwnerRejectedStatus()
        {
            string ownerRejectedStatus = OwnerRejectedStatus.Text.ToLower();
            return ownerRejectedStatus;
        }

        public string GetOwnerApprovedOnBehalfStatus()
        {
            string approvedOnBehalfOfOwnerStatus = OwnerApprovedStatus.Text.ToLower();
            return approvedOnBehalfOfOwnerStatus;
        }

        public string GetFinalCPStatus()
        {
            string cpStatusText = WCToFinalStatus.Text.ToLower();
            return cpStatusText;
        }

        public SummaryPage ChartererClickSignElectronically()
        {
            ChartererSignElectronically.Click();
            Thread.Sleep(TimeSpan.FromSeconds(10));
            return this;
        }

        public SummaryPage OwnerClickSignElectronically()
        {
            _browserSession.GoBack();
            OwnerSignElectronically.ClickElement();
            Thread.Sleep(TimeSpan.FromSeconds(10));
            return this;
        }

        public SummaryPage EnterRejectionComment(string rejectReason)
        {
            RejectionReason.SendKeys(rejectReason);
            return this;
        }

        public string GetChartererRejectedStatusBy()
        {
            string cpRejectedByCharterer = RejectedByCharterer.Text.ToLower();
            return cpRejectedByCharterer;
        }

        public string GetOwnerRejectedStatusBy()
        {
            string cpRejectedByOwner = RejectedByOwner.Text.ToLower();
            return cpRejectedByOwner;
        }

        public string GetApprovedOnBehalfOfCharterer()
        {
            string approvedOnBehalfcharter = ApprovedOnBehalfOfCharterer.Text.ToLower();
            return approvedOnBehalfcharter;
        }

        public string GetApprovedOnBehalfOfOwner()
        {
            string approvedOnBehalfOwner = ApprovedOnBehalfOfOwner.Text.ToLower();
            return approvedOnBehalfOwner;
        }
        #endregion
    }
}