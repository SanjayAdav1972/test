﻿using Coypu;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.POM.Shared
{
    public class BasePageObject
    {
        private readonly BrowserSession driver;
        public BasePageObject(BrowserSession browserSession)
        {
            this.driver = browserSession;
        }

        protected ElementScope Button(string text)
        {
            return driver.FindButton(text);
        }

        protected ElementScope Field(string text)
        {
            return driver.FindField(text);
        }

        protected ElementScope Link(string text)
        {
            return driver.FindLink(text);
        }

        protected ElementScope Css(string cssSelector)
        {
            return driver.FindCss(cssSelector);
        }

        protected ElementScope CssWithText(string cssSelector, string text)
        {
            return driver.FindCss(cssSelector, text, new Options()
            {
                TextPrecision = TextPrecision.Substring
            });
        }

        protected IEnumerable<ElementScope> AllCss(string cssSelector)
        {
            return driver.FindAllCss(cssSelector);
        }
    }
}