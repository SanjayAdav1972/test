﻿using Coypu;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.POM.Shared
{
    public class CharterPartyEditor : BasePageObject
    {
        public CharterPartyEditor(BrowserSession browserSession) : base(browserSession)
        {
        }

        public IEnumerable<ElementScope> Lines => AllCss("div.cptec-ckeditor-content > div p");
    }
}