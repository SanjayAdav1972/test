﻿using Coypu;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.POM.Shared
{
    public class Search : BasePageObject
    {
        private readonly BrowserSession _browserSession;
        public Search(BrowserSession browserSession) : base(browserSession)
        {
            this._browserSession = browserSession;
        }

        public ElementScope Logout => CssWithText("span.cpm-sidebar-area-name", "Sign Out");
        public ElementScope ShowMenu => Css(".btn-group.cpm-user-profile.dropdown.hidden-sm.hidden-xs div span.title i");
        public ElementScope DraftStatusFilter => CssWithText("div.cpm-search-checkbox", "Draft");
        public ElementScope OnSubsStatusFilter => CssWithText("div.cpm-search-checkbox", "On Subs");
        public ElementScope WorkingCopyStatusFilter => CssWithText("div.cpm-search-checkbox", "Working Copy");
        public ElementScope FinalStatusFilter => CssWithText("div.cpm-search-checkbox", "Final");
        public ElementScope FullyFixedStatusFilter => CssWithText("div.cpm-search-checkbox", "Fully Fixed");
        public ElementScope CancelledStatusFilter => CssWithText("div.cpm-search-checkbox", "Cancelled");
        public ElementScope FailedStatusFilter => CssWithText("div.cpm-search-checkbox", "Failed");
        public IEnumerable<ElementScope> Results => AllCss("tbody.cpm-cp-search-results-container-body > tr");
        public ElementScope NewDocumentButton => Button("ADD NEW");
        public ElementScope SearchInput => Field("Search for your");
        public IEnumerable<ElementScope> AllStatusFilters => AllCss("div.cpm-search-checkbox");
        public ElementScope AdvancedSearch => Css("cp-advanced-search");
        public ElementScope AdvancedSearchCreatedBy => AdvancedSearch.FindField("Created By");
        public ElementScope AdvancedSearchDateMin => AdvancedSearch.FindField("Date Min");
        public ElementScope AdvancedSearchCharterer => AdvancedSearch.FindField("Charterer");
        public ElementScope AdvancedSearchCpForm => AdvancedSearch.FindField("CP Form");
        public ElementScope AdvancedSearchDateMax => AdvancedSearch.FindField("Date Max");
        public ElementScope AdvancedSearchOwner => AdvancedSearch.FindField("Owner");
        public ElementScope AdvancedSearchNamedUser => AdvancedSearch.FindField("Named User");
        public ElementScope AdvancedVesselName => AdvancedSearch.FindField("Vessel Name");
        public ElementScope AdvancedSearchSaveDefaults => AdvancedSearch.FindButton("Save Defaults");
        public ElementScope CloseButton => _browserSession.FindXPath("//button[@class='btn cpm-button-blue' and contains(text(),'Close')]");
    }
}