﻿using Coypu;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.POM.Shared
{
    public class CharterParty : BasePageObject
    {
        private readonly BrowserSession _browserSession;
        public CharterParty(BrowserSession browserSession) : base(browserSession)
        {
            this._browserSession = browserSession;
        }

        public ElementScope AddNewDocumentButton => Button("ADD NEW");
        public ElementScope BrokerAutocomplete => Css("body > div.modal.fade.in > div > div > div.modal-body > div > div:nth-child(1) > input");
        public ElementScope ChartererAutocomplete => Css("body > div.modal.fade.in > div > div > div.modal-body > div > div:nth-child(2) > input");
        public ElementScope StyleSelection => Css("body > div.modal.fade.in > div > div > div.modal-body > div > div:nth-child(3) > select");
        public ElementScope CreateButton => Button("CREATE");
        public ElementScope ViewMainDetailsButton => Link("Recap");
        public ElementScope ViewEditorButton => Link("Editor");
        public ElementScope SubjectsInput => Css("div.cpm-cp-subjects-text > textarea");
        public ElementScope SubjectsAlertIcon => Css("cpm-cp-subjects-component > div > h2 > div > button");
        public ElementScope CreateDialogTitle => Css("div.modal-header > h3");
        public ElementScope Save => Css("div.icon--save");
        public IEnumerable<ElementScope> AllTextInputs => AllCss("input[type='text'],textarea");
        public ElementScope GoToLine => Css("#goToLine");
        public ElementScope GoToLineNavigate => Css("Button[ng-click='vm.scrollToClauseLineOnEnter($event)']");
        public ElementScope OwnerGroup => Css("#ownerGroup");
        public ElementScope CPDated => _browserSession.FindXPath("//label[contains(text(),'Date:')]/following-sibling::input");
        public ElementScope BPVoy4MBPShippingQuestionnaireCompletedDate => Css("div.cpm-details > div:nth-child(1) > div > div:nth-child(5) > div > div > div:nth-child(2) > div:nth-child(6) > div > div > input");
        public ElementScope BPVoy4MBPShippingQuestionnaireConfirmedDate => Css("div.cpm-details > div:nth-child(1) > div > div:nth-child(5) > div > div > div:nth-child(2) > div:nth-child(7) > div > div > input");
        public ElementScope ImoNumber => Css("#IMONumber > input");
        public ElementScope DeleteButton => _browserSession.FindXPath("//a[contains(text(),'Delete CP')]");
        public ElementScope ToolbarMenu => Css(".has-icon.icon--more.dropdown-toggle");
        public ElementScope ConfirmDeleteButton => Button("Yes");
        public ElementScope Q88Search => Css("div.cpm-cp-vessel-desc-tools");
        public ElementScope Q88SearchInput => Css("#cpm-cp-vessel-description > div > form > div > input");
        public ElementScope Q88SearchOption => Css("#cpm-cp-vessel-description > span");
        public ElementScope ExportButton => Button("export-button");
        public ElementScope ExportCharterPartyLink => Link("Fixture Charter Party");
        public IEnumerable<ElementScope> VesselTabs => AllCss(" cp-tab > ul > li");
        public ElementScope ExportRecapLink => Link("Fixture Recap");
        public IEnumerable<ElementScope> VesselRemoveButtons => AllCss("cp-tab > ul > li > a > i");
        public ElementScope VesselSection => Css("div.cpm-cp-vessel-container > div > div");
        public ElementScope VesselName => Css("#VesselName > input");
        public ElementScope VesselDescriptionFreetext => Css("div.cpm-cp-vessel-container > div > div > div > div > div > textarea");
        public ElementScope VesselFreetextOption => Css("span.cpm-vessel-description-switch");
        public ElementScope RecapSection => Link("Recap");
        public ElementScope ResumeEditingButton => Button("Resume");
    }
}