﻿using Coypu;
using System.Linq;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class ExistingClausesPage
    {
        private readonly BrowserSession _browserSession;
        public ExistingClausesPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region ExistingClauses Page objects

        #region BPVOY4CLEARLAKE Clauses Page objects
        public ElementScope SB_BP_ISM_CLAUSE => _browserSession.FindXPath(".//span[contains(text(),\'BP ISM CLAUSE\')]");
        public ElementScope SB_BP_ITWF_CLAUSE => _browserSession.FindXPath(".//span[contains(text(),\'BP ITWF CLAUSE\')]");
        public ElementScope SB_IN_TRANSIT_LOSS => _browserSession.FindXPath(".//span[contains(text(),\'IN TRANSIT LOSS\')]");
        #endregion

        #region ASBA Clauses Page objects
        public ElementScope NAMING_LOADING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'NAMING LOADING AND DISCHARGE PORTS\')]");
        public ElementScope TWO_OR_MORE_PORTS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'TWO OR MORE PORTS COUNTING AS ONE\')]");
        public ElementScope HOURS_FOR_LOADING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'HOURS FOR LOADING AND DLSCHARGLNG\')]");
        public ElementScope GENERAL_EXCEPTIONS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'GENERAL EXCEPTIONS CLAUSE\')]");
        #endregion

        #region BOXTIMEMAERSK Clauses Page objects
        public ElementScope TRADING_LIMITS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'TRADING LIMITS\')]");
        public ElementScope PERMITTED_CARGOES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PERMITTED CARGOES\')]");
        public ElementScope LUMP_SUM_SETTLEMENTS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LUMP SUM SETTLEMENTS\')]");
        #endregion

        #region BOXTIME Clauses Page objects
        public ElementScope BUNKER_FUEL_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BUNKER FUEL\')]");
        public ElementScope LASHINGS_AND_STEVEDORING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LASHINGS AND STEVEDORING\')]");
        public ElementScope LOSS_OF_VESSEL_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LOSS OF VESSEL\')]");
        #endregion

        #region Gencon Clauses Page objects
        public ElementScope DEVIATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DEVIATION CLAUSE\')]");
        public ElementScope GENERAL_ICE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'GENERAL ICE CLAUSE\')]");
        public ElementScope CANCELLING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CANCELLING CLAUSE\')]");
        public ElementScope PAYMENT_OF_FREIGHT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PAYMENT OF FREIGHT\')]");
        #endregion

        #region Yaracharter Clauses Page objects
        public ElementScope ON_DELIVERY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ON DELIVERY\')]");
        public ElementScope MISREPRESENTATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'MISREPRESENTATION\')]");
        public ElementScope LAW_AND_JURISDICTION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LAW AND JURISDICTION\')]");
        public ElementScope BILLS_OF_LADING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BILLS OF LADING\')]");
        #endregion

        #region AMWELSH93 Clauses Page objects
        public ElementScope FREIGHT_PAYMENT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Freight Payment\')]");
        public ElementScope DISCHARGING_PORT_ORDERS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Discharging Port Orders\')]");
        public ElementScope COST_LOADING_DISCHARGING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Cost of Loading and Discharging\')]");
        public ElementScope EXTRA_INSURANCE_CARGO_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Extra Insurance on Cargo\')]");
        #endregion

        #region ANGLOAMERICAN Clauses Page objects
        public ElementScope DEFINITIONS_INTERPRETATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),'DEFINITIONS AND INTERPRETATION')]");
        public ElementScope LOADING_PORTS_DISCHARGING_PORTS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LOADING PORTS AND DISCHARGING PORTS\')]");
        public ElementScope LIGHTERAGE_LIGHTENING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LIGHTERAGE AND LIGHTENING\')]");
        public ElementScope FORCE_MAJEURE_EXCEPTIONS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'FORCE MAJEURE EXCEPTIONS\')]");
        #endregion

        #region NORGRAIN74 Clauses Page objects
        public ElementScope CHARTERERS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),'CHARTERERS')]");
        public ElementScope DESCRIPTION_OF_CARGO_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DESCRIPTION OF CARGO\')]");
        public ElementScope DUES_AT_GERMAN_PORTS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DUES AT GERMAN PORTS\')]");
        #endregion

        #region NORGRAIN89 Clauses Page objects
        public ElementScope CANADIAN_PARAMOUNT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),'CANADIAN CLAUSE PARAMOUNT.')]");
        public ElementScope USA_PARAMOUNT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'U.S.A.CLAUSE PARAMOUNT.\')]");
        public ElementScope EXTRA_INSURANCE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'EXTRA INSURANCE.\')]");
        #endregion

        #region HYDROCHARTER2017 Clauses Page objects
        public ElementScope ADVANCE_NOTICES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Advance notices\')]");
        public ElementScope STEVEDORES_AND_STEVEDORE_DAMAGE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Stevedores and stevedore damage\')]");
        public ElementScope BIMCO_ICE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BIMCO Ice Clause for Voyage Charter Parties\')]");
        #endregion

        #region TATASTEELGATE Clauses Page objects
        public ElementScope HOLD_LADDER_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'HOLD LADDER CLAUSE\')]");
        public ElementScope PORT_STATE_CONTROL_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PORT STATE CONTROL CLAUSE\')]");
        public ElementScope SHIP_TO_SHIP_TRANSFER_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SHIP TO SHIP TRANSFER CLAUSE\')]");
        #endregion

        #region BPVOY4 Clauses Page objects
        public ElementScope CARGO_HEATING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARGO HEATING\')]");
        public ElementScope CLAIMS_TIME_BAR_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CLAIMS TIME BAR\')]");
        public ElementScope CARGO_RETENTION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARGO RETENTION\')]");
        #endregion

        #region BPVOY5 Clauses Page objects
        public ElementScope CLAUSE_PARAMOUNT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CLAUSE PARAMOUNT\')]");
        public ElementScope BALTIC_ROUTEING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BALTIC ROUTEING\')]");
        public ElementScope CARRIAGE_OF_CARGO_DDITIVE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARRIAGE OF CARGO ADDITIVE\')]");
        #endregion

        #region BPVOY4STVOY2006 Clauses Page objects
        public ElementScope OIL_POLLUTION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'OIL POLLUTION CLAUSE\')]");
        public ElementScope WEATHERNEWS_MONITORING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'WEATHERNEWS MONITORING CLAUSE\')]");
        public ElementScope NIGERIAN_CLAUSE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'NIGERIAN CLAUSE\')]");
        #endregion

        #region BPVOY4STVOY2010 Clauses Page objects
        public ElementScope ST_NOTICES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ST NOTICES CLAUSE\')]");
        public ElementScope LAYTIME_ALLOWANCE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LAYTIME ALLOWANCE\')]");
        #endregion

        #region BPVOY4VITOL2006 Clauses Page objects
        public ElementScope VITOL_VOYAGE_CHARTERING_TERMS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'VITOL VOYAGE CHARTERING TERMS\')]");
        public ElementScope OIL_COMPANY_APPROVALS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'OIL COMPANY APPROVALS\')]");
        public ElementScope BP_WEATHERNEWS_MONITORING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BP WEATHERNEWS MONITORING CLAUSE\')]");
        #endregion

        #region BPVOY4VITOL2010 Clauses Page objects
        public ElementScope ESTIMATED_TIMES_OF_ARRIVAL_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ESTIMATED TIMES OF ARRIVAL\')]");
        public ElementScope GENERAL_AVERAGE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'GENERAL AVERAGE\')]");
        public ElementScope SOUTH_EAST_ASIA_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SOUTH EAST ASIA\')]");
        #endregion

        #region BPVOY4VITOLTORM2007 Clauses Page objects
        public ElementScope DUES_AND_OTHER_CHARGES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DUES AND OTHER CHARGES\')]");
        public ElementScope AMENDMENTS_TO_THE_BPVOY4_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'AMENDMENTS TO THE BPVOY4\')]");
        public ElementScope BALLAST_WATER_MANAGEMENT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BALLAST WATER MANAGEMENT\')]");
        # endregion

        #region BPVOY4VITOLMANSEL Clauses Page objects
        public ElementScope MAINTENANCE_OF_CARGO_TEMPERATURE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'MAINTENANCE OF CARGO TEMPERATURE\')]");
        public ElementScope GULF_OF_ADEN_TRANSIT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'GULF OF ADEN TRANSIT\')]");
        public ElementScope MISSISSIPPI_RIVER_PORTS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'MISSISSIPPI RIVER PORTS\')]");
        #endregion

        #region EXXONMOBILVOY2005 Clauses Page objects
        public ElementScope CHARTER_ADMINISTRATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CHARTER ADMINISTRATION\')]");
        public ElementScope DRUG_AND_ALCOHOL_POLICY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DRUG AND ALCOHOL POLICY\')]");
        public ElementScope CARGO_MEASUREMENT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARGO MEASUREMENT\')]");
        #endregion

        #region EXXONMOBILVOY2005SOCAR Clauses Page objects
        public ElementScope CARGO_SUPERINTENDENT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARGO SUPERINTENDENT\')]");
        public ElementScope NOTICE_OF_READINESS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'NOTICE OF READINESS\')]");
        public ElementScope ROTTERDAM_HARBOR_DUES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ROTTERDAM HARBOR DUES\')]");
        #endregion

        #region EXXONMOBILVOY2005VALERO Clauses Page objects
        public ElementScope CHARTER_PARTY_FORMAT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CHARTER PARTY FORMAT\')]");
        public ElementScope EXCESS_BERTH_OCCUPANCY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'EXCESS BERTH OCCUPANCY\')]");
        public ElementScope SECURITY_REGULATIONS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SECURITY REGULATIONS\')]");
        #endregion

        #region OMVOY2001 Clauses Page objects
        public ElementScope PLACE_OF_ISSUE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PLACE OF ISSUE\')]");
        public ElementScope COMMINGLING_AND_INDEMNITY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'COMMINGLING AND INDEMNITY\')]");
        public ElementScope TERMINATION_OF_LAYTIME_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'TERMINATION OF LAYTIME\')]");

        #endregion
        #region SHELLVOY6 Clauses Page objects
        public ElementScope CLEANLINESS_OF_TANKS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CLEANLINESS OF TANKS\')]");
        public ElementScope BOTH_TO_BLAME_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BOTH TO BLAME CLAUSE\')]");
        public ElementScope EU_ADVANCE_CARGO_DECLARATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'EU ADVANCE CARGO DECLARATION CLAUSE\')]");
        #endregion

        #region SHELLTIME4 Clauses Page objects
        public ElementScope SHIPBOARD_PERSONNEL_AND_THEIR_DUTIES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SHIPBOARD PERSONNEL AND THEIR DUTIES\')]");
        public ElementScope INSTRUCTIONS_AND_LOGS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'INSTRUCTIONS AND LOGS\')]");
        public ElementScope PERIODICAL_DRYDOCKING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PERIODICAL DRYDOCKING\')]");
        #endregion

        #region EXXONVOY84SCANPORT Clauses Page objects
        public ElementScope TURKISH_PORT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'TURKISH PORT CLAUSE\')]");
        public ElementScope POLLUTION_INSURANCE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'POLLUTION INSURANCE CLAUSE\')]");
        public ElementScope LIGHTENING_AND_TOPPING_OFF_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LIGHTENING AND TOPPING OFF\')]");
        #endregion

        #region EXXONMOBILVOY2005TESORO Clauses Page objects
        public ElementScope MOORING_MASTER_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'MOORING MASTER CLAUSE\')]");
        public ElementScope CARBON_BLACK_CLEANING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CARBON BLACK CLEANING CLAUSE\')]");
        public ElementScope CALIFORNIA_NAVIGATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CALIFORNIA NAVIGATION\')]");
        #endregion

        #region EXXONVOY84 Clauses Page objects
        public ElementScope BACK_LOADING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BACK LOADING\')]");
        public ElementScope QUARANTINE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'QUARANTINE\')]");
        public ElementScope CLEAN_SEAS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CLEAN SEAS\')]");
        #endregion

        #region RTMVOY1Q15 Clauses Page objects
        public ElementScope ECONOMIC_SANCTIONS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ECONOMIC SANCTIONS\')]");
        public ElementScope INCORPORATED_DOCUMENTATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'INCORPORATED DOCUMENTATION\')]");
        public ElementScope DEVIATION_AND_LIBERTIES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DEVIATION AND LIBERTIES\')]");
        #endregion

        #region BALTIMORE Clauses Page objects
        public ElementScope PART_1_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PART 1\')]");
        public ElementScope PART_2_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PART 2\')]");
        #endregion

        #region GENCON76 Clauses Page objects
        public ElementScope GENERAL_STRIKE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'GENERAL STRIKE CLAUSE\')]");
        public ElementScope LIEN_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LIEN CLAUSE \')]");
        #endregion

        #region ROYHILL Clauses Page objects
        public ElementScope LAYCAN_COMMENCEMENT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Laycan Commencement Date and Laytime\')]");
        public ElementScope VESSEL_NOMINATION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Vessel Nomination\')]");
        public ElementScope JAPANESE_TRADING_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'Japanese Trading Clause\')]");
        #endregion

        #region VALEVOY2014 Clauses Page objects
        public ElementScope ENTIRE_CONTRACT_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'ENTIRE CONTRACT\')]");
        public ElementScope LIMITATION_OF_LIABILITY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'LIMITATION OF LIABILITY\')]");
        public ElementScope FORCE_MAJEURE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'FORCE MAJEURE\')]");
        #endregion

        #region BHPBVOY2014 Clauses Page objects
        public ElementScope WIRE_MOORING_ROPES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'WIRE MOORING ROPES\')]");
        public ElementScope SANCTIONS_COMPLIANCE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SANCTIONS COMPLIANCE CLAUSE\')]");
        public ElementScope BOTH_TO_BLAME_COLLISION_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BOTH TO BLAME COLLISION\')]");
        #endregion

        #region NYPE93 Clauses Page objects
        public ElementScope OWNERS_TO_PROVIDE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'OWNERS TO PROVIDE\')]");
        public ElementScope STEVEDORE_DAMAGE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'STEVEDORE DAMAGE\')]");
        public ElementScope CLEANING_OF_HOLDS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CLEANING OF HOLDS\')]");
        #endregion

        #region ARCELORMITTALIRONORECP2014 Clauses Page objects
        public ElementScope SHIFTING_COST_AND_TIME_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'SHIFTING COST AND TIME\')]");
        public ElementScope VESSEL_DEFICIENCIES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'VESSEL DEFICIENCIES\')]");

        public ElementScope WARPING => _browserSession.FindXPath("//span[contains(text(),'WARPING')]");
        public ElementScope OVERTIME => _browserSession.FindXPath("//span[contains(text(),'OVERTIME')]");
        public ElementScope LIGHTING => _browserSession.FindXPath("//span[contains(text(),'LIGHTING')]");
        #endregion

        #region EUROMED1997 Clauses Page objects
        public ElementScope PARAMOUNT_CLAUSES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PARAMOUNT CLAUSE\')]");
        public ElementScope USCG_CLAUSE_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'USCG CLAUSE\')]");
        public ElementScope CERTIFICATE_OF_FINANCIAL_RESPONSIBILITY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CERTIFICATE OF FINANCIAL RESPONSIBILITY')]");
        #endregion

        #region FMGVOY2012 Clauses Page objects
        public ElementScope OPENING_AND_CLOSING_HATCHCOVERS_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'OPENING AND CLOSING HATCHCOVERS\')]");
        public ElementScope DRAFT_SURVEY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'DRAFT SURVEY\')]");
        #endregion

        #region NYPE81 Clauses Page objects
        public ElementScope BUNKERS_ON_DELIVERY_AND_REDELIVERY_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'BUNKERS ON DELIVERY AND REDELIVERY\')]");
        public ElementScope PROSECUTION_OF_VOYAGES_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'PROSECUTION OF VOYAGES\')]");
        public ElementScope CONDUCT_OF_CAPTAIN_CLAUSE => _browserSession.FindXPath("//span[contains(text(),\'CONDUCT OF CAPTAIN\')]");
        #endregion

        #endregion

        #region ExistingClauses Page methods

        #region Recap Manager Forms
        public bool BPVOY4CLEARLAKEClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "BP ISM CLAUSE":
                        actualLabel = SB_BP_ISM_CLAUSE.Text.ToLower();
                        fieldTxt = "BP ISM CLAUSE";
                        break;
                    case "BP ITWF CLAUSE":
                        actualLabel = SB_BP_ITWF_CLAUSE.Text.ToLower();
                        fieldTxt = "BP ITWF CLAUSE";
                        break;
                    case "IN TRANSIT LOSS":
                        actualLabel = SB_IN_TRANSIT_LOSS.Text.ToLower();
                        fieldTxt = "IN TRANSIT LOSS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CARGO HEATING":
                        actualLabel = CARGO_HEATING_CLAUSE.Text.ToLower();
                        fieldTxt = "CARGO HEATING";
                        break;
                    case "CLAIMS TIME BAR":
                        actualLabel = CLAIMS_TIME_BAR_CLAUSE.Text.ToLower();
                        fieldTxt = "CLAIMS TIME BAR";
                        break;
                    case "CARGO RETENTION":
                        actualLabel = CARGO_RETENTION_CLAUSE.Text.ToLower();
                        fieldTxt = "CARGO RETENTION";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY5Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CLAUSE PARAMOUNT":
                        actualLabel = CLAUSE_PARAMOUNT_CLAUSE.Text.ToLower();
                        fieldTxt = "CLAUSE PARAMOUNT";
                        break;
                    case "BALTIC ROUTEING":
                        actualLabel = BALTIC_ROUTEING_CLAUSE.Text.ToLower();
                        fieldTxt = "BALTIC ROUTEING";
                        break;
                    case "CARRIAGE OF CARGO ADDITIVE":
                        actualLabel = CARRIAGE_OF_CARGO_DDITIVE_CLAUSE.Text.ToLower();
                        fieldTxt = "CARRIAGE OF CARGO ADDITIVE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4STVOY2006Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "OIL POLLUTION CLAUSE":
                        actualLabel = OIL_POLLUTION_CLAUSE.Text.ToLower();
                        fieldTxt = "OIL POLLUTION CLAUSE";
                        break;
                    case "WEATHERNEWS MONITORING CLAUSE":
                        actualLabel = WEATHERNEWS_MONITORING_CLAUSE.Text.ToLower();
                        fieldTxt = "WEATHERNEWS MONITORING CLAUSE";
                        break;
                    case "NIGERIAN CLAUSE":
                        actualLabel = NIGERIAN_CLAUSE_CLAUSE.Text.ToLower();
                        fieldTxt = "NIGERIAN CLAUSE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4STVOY2010Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "ST NOTICES CLAUSE":
                        actualLabel = ST_NOTICES_CLAUSE.Text.ToLower();
                        fieldTxt = "ST NOTICES CLAUSE";
                        break;
                    case "LAYTIME ALLOWANCE":
                        actualLabel = LAYTIME_ALLOWANCE_CLAUSE.Text.ToLower();
                        fieldTxt = "LAYTIME ALLOWANCE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4VITOL2006Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "VITOL VOYAGE CHARTERING TERMS":
                        actualLabel = VITOL_VOYAGE_CHARTERING_TERMS_CLAUSE.Text.ToLower();
                        fieldTxt = "VITOL VOYAGE CHARTERING TERMS";
                        break;
                    case "OIL COMPANY APPROVALS":
                        actualLabel = OIL_COMPANY_APPROVALS_CLAUSE.Text.ToLower();
                        fieldTxt = "OIL COMPANY APPROVALS";
                        break;
                    case "BP WEATHERNEWS MONITORING CLAUSE":
                        actualLabel = BP_WEATHERNEWS_MONITORING_CLAUSE.Text.ToLower();
                        fieldTxt = "BP WEATHERNEWS MONITORING CLAUSE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4VITOL2010Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "ESTIMATED TIMES OF ARRIVAL":
                        actualLabel = ESTIMATED_TIMES_OF_ARRIVAL_CLAUSE.Text.ToLower();
                        fieldTxt = "ESTIMATED TIMES OF ARRIVAL";
                        break;
                    case "GENERAL AVERAGE":
                        actualLabel = GENERAL_AVERAGE_CLAUSE.Text.ToLower();
                        fieldTxt = "GENERAL AVERAGE";
                        break;
                    case "SOUTH EAST ASIA":
                        actualLabel = SOUTH_EAST_ASIA_CLAUSE.Text.ToLower();
                        fieldTxt = "SOUTH EAST ASIA";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4VITOLTORM2007Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "DUES AND OTHER CHARGES":
                        actualLabel = DUES_AND_OTHER_CHARGES_CLAUSE.Text.ToLower();
                        fieldTxt = "DUES AND OTHER CHARGES";
                        break;
                    case "AMENDMENTS TO THE BPVOY4":
                        actualLabel = AMENDMENTS_TO_THE_BPVOY4_CLAUSE.Text.ToLower();
                        fieldTxt = "AMENDMENTS TO THE BPVOY4";
                        break;
                    case "BALLAST WATER MANAGEMENT":
                        actualLabel = BALLAST_WATER_MANAGEMENT_CLAUSE.Text.ToLower();
                        fieldTxt = "BALLAST WATER MANAGEMENT";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BPVOY4VITOLMANSELClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "MAINTENANCE OF CARGO TEMPERATURE":
                        actualLabel = MAINTENANCE_OF_CARGO_TEMPERATURE_CLAUSE.Text.ToLower();
                        fieldTxt = "MAINTENANCE OF CARGO TEMPERATURE";
                        break;
                    case "GULF OF ADEN TRANSIT":
                        actualLabel = GULF_OF_ADEN_TRANSIT_CLAUSE.Text.ToLower();
                        fieldTxt = "GULF OF ADEN TRANSIT";
                        break;
                    case "MISSISSIPPI RIVER PORTS":
                        actualLabel = MISSISSIPPI_RIVER_PORTS_CLAUSE.Text.ToLower();
                        fieldTxt = "MISSISSIPPI RIVER PORTS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONMOBILVOY2005Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CHARTER ADMINISTRATION":
                        actualLabel = CHARTER_ADMINISTRATION_CLAUSE.Text.ToLower();
                        fieldTxt = "CHARTER ADMINISTRATION";
                        break;
                    case "DRUG AND ALCOHOL POLICY":
                        actualLabel = DRUG_AND_ALCOHOL_POLICY_CLAUSE.Text.ToLower();
                        fieldTxt = "DRUG AND ALCOHOL POLICY";
                        break;
                    case "CARGO MEASUREMENT":
                        actualLabel = CARGO_MEASUREMENT_CLAUSE.Text.ToLower();
                        fieldTxt = "CARGO MEASUREMENT";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONMOBILVOY2005SOCAR2010Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CARGO SUPERINTENDENT":
                        actualLabel = CARGO_SUPERINTENDENT_CLAUSE.Text.ToLower();
                        fieldTxt = "CARGO SUPERINTENDENT";
                        break;
                    case "NOTICE OF READINESS":
                        actualLabel = NOTICE_OF_READINESS_CLAUSE.Text.ToLower();
                        fieldTxt = "NOTICE OF READINESS";
                        break;
                    case "ROTTERDAM HARBOR DUES":
                        actualLabel = ROTTERDAM_HARBOR_DUES_CLAUSE.Text.ToLower();
                        fieldTxt = "ROTTERDAM HARBOR DUES";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONMOBILVOY2005VALEROClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CHARTER PARTY FORMAT":
                        actualLabel = CHARTER_PARTY_FORMAT_CLAUSE.Text.ToLower();
                        fieldTxt = "CHARTER PARTY FORMAT";
                        break;
                    case "EXCESS BERTH OCCUPANCY":
                        actualLabel = EXCESS_BERTH_OCCUPANCY_CLAUSE.Text.ToLower();
                        fieldTxt = "EXCESS BERTH OCCUPANCY";
                        break;
                    case "SECURITY REGULATIONS":
                        actualLabel = SECURITY_REGULATIONS_CLAUSE.Text.ToLower();
                        fieldTxt = "SECURITY REGULATIONS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool OMVOY2001Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "PLACE OF ISSUE":
                        actualLabel = PLACE_OF_ISSUE_CLAUSE.Text.ToLower();
                        fieldTxt = "PLACE OF ISSUE";
                        break;
                    case "COMMINGLING AND INDEMNITY":
                        actualLabel = COMMINGLING_AND_INDEMNITY_CLAUSE.Text.ToLower();
                        fieldTxt = "COMMINGLING AND INDEMNITY";
                        break;
                    case "TERMINATION OF LAYTIME":
                        actualLabel = TERMINATION_OF_LAYTIME_CLAUSE.Text.ToLower();
                        fieldTxt = "TERMINATION OF LAYTIME";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool SHELLVOY6Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CLEANLINESS OF TANKS":
                        actualLabel = CLEANLINESS_OF_TANKS_CLAUSE.Text.ToLower();
                        fieldTxt = "CLEANLINESS OF TANKS";
                        break;
                    case "BOTH TO BLAME CLAUSE":
                        actualLabel = BOTH_TO_BLAME_CLAUSE.Text.ToLower();
                        fieldTxt = "BOTH TO BLAME CLAUSE";
                        break;
                    case "EU ADVANCE CARGO DECLARATION CLAUSE":
                        actualLabel = EU_ADVANCE_CARGO_DECLARATION_CLAUSE.Text.ToLower();
                        fieldTxt = "EU ADVANCE CARGO DECLARATION CLAUSE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool SHELLTIME4Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "SHIPBOARD PERSONNEL AND THEIR DUTIES,,":
                        actualLabel = SHIPBOARD_PERSONNEL_AND_THEIR_DUTIES_CLAUSE.Text.ToLower();
                        fieldTxt = "SHIPBOARD PERSONNEL AND THEIR DUTIES";
                        break;
                    case "INSTRUCTIONS AND LOGS":
                        actualLabel = INSTRUCTIONS_AND_LOGS_CLAUSE.Text.ToLower();
                        fieldTxt = "INSTRUCTIONS AND LOGS";
                        break;
                    case "PERIODICAL DRYDOCKING":
                        actualLabel = PERIODICAL_DRYDOCKING_CLAUSE.Text.ToLower();
                        fieldTxt = "PERIODICAL DRYDOCKING";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONVOY84SCANPORTClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "TURKISH PORT CLAUSE":
                        actualLabel = TURKISH_PORT_CLAUSE.Text.ToLower();
                        fieldTxt = "TURKISH PORT CLAUSE";
                        break;
                    case "POLLUTION INSURANCE CLAUSE":
                        actualLabel = POLLUTION_INSURANCE_CLAUSE.Text.ToLower();
                        fieldTxt = "POLLUTION INSURANCE CLAUSE";
                        break;
                    case "LIGHTENING AND TOPPING OFF":
                        actualLabel = LIGHTENING_AND_TOPPING_OFF_CLAUSE.Text.ToLower();
                        fieldTxt = "LIGHTENING AND TOPPING OFF";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONMOBILVOY2005TESOROClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "MOORING MASTER CLAUSE":
                        actualLabel = MOORING_MASTER_CLAUSE.Text.ToLower();
                        fieldTxt = "MOORING MASTER CLAUSE";
                        break;
                    case "CARBON BLACK CLEANING CLAUSE":
                        actualLabel = CARBON_BLACK_CLEANING_CLAUSE.Text.ToLower();
                        fieldTxt = "CARBON BLACK CLEANING CLAUSE";
                        break;
                    case "CALIFORNIA NAVIGATION":
                        actualLabel = CALIFORNIA_NAVIGATION_CLAUSE.Text.ToLower();
                        fieldTxt = "CALIFORNIA NAVIGATION";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EXXONVOY84Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "BACK LOADING":
                        actualLabel = BACK_LOADING_CLAUSE.Text.ToLower();
                        fieldTxt = "BACK LOADING";
                        break;
                    case "QUARANTINE":
                        actualLabel = QUARANTINE_CLAUSE.Text.ToLower();
                        fieldTxt = "CARBON BLACK CLEANING CLAUSE";
                        break;
                    case "CLEAN SEAS":
                        actualLabel = CLEAN_SEAS_CLAUSE.Text.ToLower();
                        fieldTxt = "CLEAN SEAS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        #endregion

        #region Charter Party Manager Forms

        public bool ASBAClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "NAMING LOADING AND DISCHARGE PORTS":
                        actualLabel = NAMING_LOADING_CLAUSE.Text.ToLower();
                        fieldTxt = "NAMING LOADING AND DISCHARGE PORTS";
                        break;
                    case "TWO OR MORE PORTS COUNTING AS ONE":
                        actualLabel = TWO_OR_MORE_PORTS_CLAUSE.Text.ToLower();
                        fieldTxt = "TWO OR MORE PORTS COUNTING AS ONE";
                        break;
                    case "HOURS FOR LOADING AND DlSCHARGlNG":
                        actualLabel = HOURS_FOR_LOADING_CLAUSE.Text.ToLower();
                        fieldTxt = "HOURS FOR LOADING AND DlSCHARGlNG";
                        break;
                    case "GENERAL EXCEPTIONS CLAUSE":
                        actualLabel = GENERAL_EXCEPTIONS_CLAUSE.Text.ToLower();
                        fieldTxt = "GENERAL EXCEPTIONS CLAUSE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BOXTIMEMAERSKClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "TRADING LIMITS":
                        actualLabel = TRADING_LIMITS_CLAUSE.Text.ToLower();
                        fieldTxt = "TRADING LIMITS";
                        break;
                    case "PERMITTED CARGOES":
                        actualLabel = PERMITTED_CARGOES_CLAUSE.Text.ToLower();
                        fieldTxt = "PERMITTED CARGOES";
                        break;
                    case "LUMP SUM SETTLEMENTS":
                        actualLabel = LUMP_SUM_SETTLEMENTS_CLAUSE.Text.ToLower();
                        fieldTxt = "LUMP SUM SETTLEMENTS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BOXTIMEClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "BUNKER FUEL":
                        actualLabel = BUNKER_FUEL_CLAUSE.Text.ToLower();
                        fieldTxt = "BUNKER FUEL";
                        break;
                    case "LASHINGS AND STEVEDORING":
                        actualLabel = LASHINGS_AND_STEVEDORING_CLAUSE.Text.ToLower();
                        fieldTxt = "LASHINGS AND STEVEDORING";
                        break;
                    case "LOSS OF VESSEL":
                        actualLabel = LOSS_OF_VESSEL_CLAUSE.Text.ToLower();
                        fieldTxt = "LOSS OF VESSEL";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool Gencon94Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "DEVIATION CLAUSE":
                        actualLabel = DEVIATION_CLAUSE.Text.ToLower();
                        fieldTxt = "DEVIATION CLAUSE";
                        break;
                    case "GENERAL ICE CLAUSE":
                        actualLabel = GENERAL_ICE_CLAUSE.Text.ToLower();
                        fieldTxt = "GENERAL ICE CLAUSE";
                        break;
                    case "CANCELLING CLAUSE":
                        actualLabel = CANCELLING_CLAUSE.Text.ToLower();
                        fieldTxt = "CANCELLING CLAUSE";
                        break;
                    case "PAYMENT OF FREIGHT":
                        actualLabel = PAYMENT_OF_FREIGHT_CLAUSE.Text.ToLower();
                        fieldTxt = "PAYMENT OF FREIGHT";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool YaraCharterClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "ON DELIVERY":
                        actualLabel = ON_DELIVERY_CLAUSE.Text.ToLower();
                        fieldTxt = "ON DELIVERY";
                        break;
                    case "MISREPRESENTATION":
                        actualLabel = MISREPRESENTATION_CLAUSE.Text.ToLower();
                        fieldTxt = "MISREPRESENTATION";
                        break;
                    case "LAW AND JURISDICTION":
                        actualLabel = LAW_AND_JURISDICTION_CLAUSE.Text.ToLower();
                        fieldTxt = "LAW AND JURISDICTION";
                        break;
                    case "BILLS OF LADING":
                        actualLabel = BILLS_OF_LADING_CLAUSE.Text.ToLower();
                        fieldTxt = "BILLS OF LADING";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool AMWELSH93Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "Freight Payment":
                        actualLabel = FREIGHT_PAYMENT_CLAUSE.Text.ToLower();
                        fieldTxt = "Freight Payment";
                        break;
                    case "Discharging Port Orders":
                        actualLabel = DISCHARGING_PORT_ORDERS_CLAUSE.Text.ToLower();
                        fieldTxt = "Discharging Port Orders";
                        break;
                    case "Cost of Loading and Discharging":
                        actualLabel = COST_LOADING_DISCHARGING_CLAUSE.Text.ToLower();
                        fieldTxt = "Cost of Loading and Discharging";
                        break;
                    case "Extra Insurance on Cargo":
                        actualLabel = EXTRA_INSURANCE_CARGO_CLAUSE.Text.ToLower();
                        fieldTxt = "Extra Insurance on Cargo";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool ANGLOAMERICANClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {

                    case "LOADING PORTS AND DISCHARGING PORTS":
                        actualLabel = LOADING_PORTS_DISCHARGING_PORTS_CLAUSE.Text.ToLower();
                        fieldTxt = "LOADING PORTS AND DISCHARGING PORTS";
                        break;
                    case "LIGHTERAGE AND LIGHTENING":
                        actualLabel = LIGHTERAGE_LIGHTENING_CLAUSE.Text.ToLower();
                        fieldTxt = "LIGHTERAGE AND LIGHTENING";
                        break;
                    case "FORCE MAJEURE EXCEPTIONS":
                        actualLabel = FORCE_MAJEURE_EXCEPTIONS_CLAUSE.Text.ToLower();
                        fieldTxt = "FORCE MAJEURE EXCEPTIONS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool NORGRAIN74Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CHARTERERS":
                        actualLabel = CHARTERERS_CLAUSE.Text.ToLower();
                        fieldTxt = "CHARTERERS";
                        break;
                    case "DESCRIPTION OF CARGO":
                        actualLabel = DESCRIPTION_OF_CARGO_CLAUSE.Text.ToLower();
                        fieldTxt = "DESCRIPTION OF CARGO";
                        break;
                    case "DUES AT GERMAN PORTS":
                        actualLabel = DUES_AT_GERMAN_PORTS_CLAUSE.Text.ToLower();
                        fieldTxt = "DUES AT GERMAN PORTS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool NORGRAIN89Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "CANADIAN CLAUSE PARAMOUNT.":
                        actualLabel = CANADIAN_PARAMOUNT_CLAUSE.Text.ToLower();
                        fieldTxt = "CANADIAN CLAUSE PARAMOUNT.";
                        break;
                    case "U.S.A.CLAUSE PARAMOUNT.":
                        actualLabel = USA_PARAMOUNT_CLAUSE.Text.ToLower();
                        fieldTxt = "U.S.A.CLAUSE PARAMOUNT.";
                        break;
                    case "EXTRA INSURANCE.":
                        actualLabel = EXTRA_INSURANCE_CLAUSE.Text.ToLower();
                        fieldTxt = "EXTRA INSURANCE.";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool HYDROCHARTER2017Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "Advance notices":
                        actualLabel = ADVANCE_NOTICES_CLAUSE.Text.ToLower();
                        fieldTxt = "Advance notices";
                        break;
                    case "Stevedores and stevedore damage":
                        actualLabel = STEVEDORES_AND_STEVEDORE_DAMAGE_CLAUSE.Text.ToLower();
                        fieldTxt = "Stevedores and stevedore damage";
                        break;
                    case "BIMCO Ice Clause for Voyage Charter Parties":
                        actualLabel = BIMCO_ICE_CLAUSE.Text.ToLower();
                        fieldTxt = "BIMCO Ice Clause for Voyage Charter Parties";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool TATASTEELGATEClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "HOLD LADDER CLAUSE":
                        actualLabel = HOLD_LADDER_CLAUSE.Text.ToLower();
                        fieldTxt = "HOLD LADDER CLAUSE";
                        break;
                    case "PORT STATE CONTROL CLAUSE":
                        actualLabel = PORT_STATE_CONTROL_CLAUSE.Text.ToLower();
                        fieldTxt = "PORT STATE CONTROL CLAUSE";
                        break;
                    case "SHIP TO SHIP TRANSFER CLAUSE":
                        actualLabel = SHIP_TO_SHIP_TRANSFER_CLAUSE.Text.ToLower();
                        fieldTxt = "SHIP TO SHIP TRANSFER CLAUSE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool RTMVOY1Q15Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "ECONOMIC SANCTIONS":
                        actualLabel = ECONOMIC_SANCTIONS_CLAUSE.Text.ToLower();
                        fieldTxt = "ECONOMIC SANCTIONS";
                        break;
                    case "INCORPORATED DOCUMENTATION":
                        actualLabel = INCORPORATED_DOCUMENTATION_CLAUSE.Text.ToLower();
                        fieldTxt = "INCORPORATED DOCUMENTATION";
                        break;
                    case "DEVIATION AND LIBERTIES":
                        actualLabel = DEVIATION_AND_LIBERTIES_CLAUSE.Text.ToLower();
                        fieldTxt = "DEVIATION AND LIBERTIES";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BALTIMOREClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "PART 1":
                        actualLabel = PART_1_CLAUSE.Text.ToLower();
                        fieldTxt = "PART 1";
                        break;
                    case "PART 2":
                        actualLabel = PART_2_CLAUSE.Text.ToLower();
                        fieldTxt = "PART 2";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool GENCON76Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "GENERAL STRIKE CLAUSE":
                        actualLabel = GENERAL_STRIKE_CLAUSE.Text.ToLower();
                        fieldTxt = "GENERAL STRIKE CLAUSE";
                        break;
                    case "LIEN CLAUSE ":
                        actualLabel = LIEN_CLAUSE.Text.ToLower();
                        fieldTxt = "LIEN CLAUSE ";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool ROYHILLClauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {

                    case "Laycan Commencement Date and Laytime":
                        actualLabel = LAYCAN_COMMENCEMENT_CLAUSE.Text.ToLower();
                        fieldTxt = "Laycan Commencement Date and Laytime";
                        break;
                    case "Vessel Nomination":
                        actualLabel = VESSEL_NOMINATION_CLAUSE.Text.ToLower();
                        fieldTxt = "Vessel Nomination";
                        break;
                    case "Japanese Trading Clause":
                        actualLabel = JAPANESE_TRADING_CLAUSE.Text.ToLower();
                        fieldTxt = "Japanese Trading Clause";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool VALEVOY2014Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {

                    case "ENTIRE CONTRACT":
                        actualLabel = ENTIRE_CONTRACT_CLAUSE.Text.ToLower();
                        fieldTxt = "ENTIRE CONTRACT";
                        break;
                    case "LIMITATION OF LIABILITY":
                        actualLabel = LIMITATION_OF_LIABILITY_CLAUSE.Text.ToLower();
                        fieldTxt = "LIMITATION OF LIABILITY";
                        break;
                    case "FORCE MAJEURE":
                        actualLabel = FORCE_MAJEURE_CLAUSE.Text.ToLower();
                        fieldTxt = "FORCE MAJEURE";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool BHPBVOY2014Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    //case "WIRE MOORING ROPES":
                    //    actualLabel = WIRE_MOORING_ROPES_CLAUSE.Text.ToLower();
                    //    fieldTxt = "WIRE MOORING ROPES";
                    //    break;
                    //case "SANCTIONS COMPLIANCE CLAUSE":
                    //    actualLabel = SANCTIONS_COMPLIANCE_CLAUSE.Text.ToLower();
                    //    fieldTxt = "SANCTIONS COMPLIANCE CLAUSE";
                    //    break;
                    //case "BOTH TO BLAME COLLISION":
                    //    actualLabel = BOTH_TO_BLAME_COLLISION_CLAUSE.Text.ToLower();
                    //    fieldTxt = "BOTH TO BLAME COLLISION";
                    //    break;
                    case "WARPING":
                        actualLabel = WARPING.Text.ToLower();
                        fieldTxt = "WARPING";
                        break;
                    case "OVERTIME":
                        actualLabel = OVERTIME.Text.ToLower();
                        fieldTxt = "OVERTIME";
                        break;
                    case "LIGHTING":
                        actualLabel = LIGHTING.Text.ToLower();
                        fieldTxt = "LIGHTING";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool NYPE93Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {

                    case "OWNERS TO PROVIDE":
                        actualLabel = OWNERS_TO_PROVIDE_CLAUSE.Text.ToLower();
                        fieldTxt = "OWNERS TO PROVIDE";
                        break;
                    case "STEVEDORE DAMAGE":
                        actualLabel = STEVEDORE_DAMAGE_CLAUSE.Text.ToLower();
                        fieldTxt = "STEVEDORE DAMAGE";
                        break;
                    case "CLEANING OF HOLDS":
                        actualLabel = CLEANING_OF_HOLDS_CLAUSE.Text.ToLower();
                        fieldTxt = "CLEANING OF HOLDS";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool ARCELORMITTALIRONORECP2014Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    //case "SHIFTING COST AND TIME":
                    //    actualLabel = SHIFTING_COST_AND_TIME_CLAUSE.Text.ToLower();
                    //    fieldTxt = "SHIFTING COST AND TIME";
                    //    break;
                    //case "VESSEL DEFICIENCIES":
                    //    actualLabel = VESSEL_DEFICIENCIES_CLAUSE.Text.ToLower();
                    //    fieldTxt = "VESSEL DEFICIENCIES";
                    //    break;
                    //case "SANCTIONS COMPLIANCE CLAUSE":
                    //    actualLabel = SANCTIONS_COMPLIANCE_CLAUSE.Text.ToLower();
                    //    fieldTxt = "SANCTIONS COMPLIANCE CLAUSE";
                    //    break;
                    case "WARPING":
                        actualLabel = WARPING.Text.ToLower();
                        fieldTxt = "WARPING";
                        break;
                    case "OVERTIME":
                        actualLabel = OVERTIME.Text.ToLower();
                        fieldTxt = "OVERTIME";
                        break;
                    case "LIGHTING":
                        actualLabel = LIGHTING.Text.ToLower();
                        fieldTxt = "LIGHTING";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool EUROMED1997Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "PARAMOUNT CLAUSES":
                        actualLabel = PARAMOUNT_CLAUSES_CLAUSE.Text.ToLower();
                        fieldTxt = "PARAMOUNT CLAUSES";
                        break;
                    case "USCG CLAUSE":
                        actualLabel = USCG_CLAUSE_CLAUSE.Text.ToLower();
                        fieldTxt = "USCG CLAUSE";
                        break;
                    case "CERTIFICATE OF FINANCIAL RESPONSIBILITY":
                        actualLabel = CERTIFICATE_OF_FINANCIAL_RESPONSIBILITY_CLAUSE.Text.ToLower();
                        fieldTxt = "CERTIFICATE OF FINANCIAL RESPONSIBILITY";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool FMGVOY2012Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    //case "OPENING AND CLOSING HATCHCOVERS":
                    //    actualLabel = OPENING_AND_CLOSING_HATCHCOVERS_CLAUSE.Text.ToLower();
                    //    fieldTxt = "OPENING AND CLOSING HATCHCOVERS";
                    //    break;
                    //case "DRAFT SURVEY":
                    //    actualLabel = DRAFT_SURVEY_CLAUSE.Text.ToLower();
                    //    fieldTxt = "DRAFT SURVEY";
                    //    break;
                    //case "JAPANESE TRADING CLAUSE":
                    //    actualLabel = JAPANESE_TRADING_CLAUSE.Text.ToLower();
                    //    fieldTxt = "JAPANESE TRADING CLAUSE";
                    //    break;
                    case "WARPING":
                        actualLabel = WARPING.Text.ToLower();
                        fieldTxt = "WARPING";
                        break;
                    case "OVERTIME":
                        actualLabel = OVERTIME.Text.ToLower();
                        fieldTxt = "OVERTIME";
                        break;
                    case "LIGHTING":
                        actualLabel = LIGHTING.Text.ToLower();
                        fieldTxt = "LIGHTING";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        public bool NYPE81Clauses(string p_Clauses)
        {
            if (p_Clauses.Length == 0)
                return false;
            var clauses = p_Clauses.Split(',').Select(p_F => p_F.Trim()).ToList();
            foreach (var clause in clauses)
            {
                string actualLabel;
                var fieldTxt = "";
                switch (clause)
                {
                    case "BUNKERS ON DELIVERY AND REDELIVERY":
                        actualLabel = BUNKERS_ON_DELIVERY_AND_REDELIVERY_CLAUSE.Text.ToLower();
                        fieldTxt = "BUNKERS ON DELIVERY AND REDELIVERY";
                        break;
                    case "PROSECUTION OF VOYAGES":
                        actualLabel = PROSECUTION_OF_VOYAGES_CLAUSE.Text.ToLower();
                        fieldTxt = "PROSECUTION OF VOYAGES";
                        break;
                    case "CONDUCT OF CAPTAIN":
                        actualLabel = CONDUCT_OF_CAPTAIN_CLAUSE.Text.ToLower();
                        fieldTxt = "CONDUCT OF CAPTAIN";
                        break;
                    default:
                        actualLabel = "UNKNOWN";
                        break;
                }

                if (!actualLabel.ToLower().Trim().Contains(fieldTxt.ToLower()))
                    return false;
            }

            return true;
        }

        #endregion

        #endregion
    }
}