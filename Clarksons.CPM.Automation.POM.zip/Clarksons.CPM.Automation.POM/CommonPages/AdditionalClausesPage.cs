﻿using Clarksons.CPM.Automation.Utilities;
using Coypu;
using System;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class AdditionalClausesPage
    {
        private readonly BrowserSession _browserSession;
        public AdditionalClausesPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Addtional Clauses page objects
        public ElementScope AddAdditonalClause => _browserSession.FindButton("Add Additional Clauses");
        public ElementScope NameOfClause => _browserSession.FindCss(".clause-title input");
        public ElementScope ClauseDetails => _browserSession.FindCss("#editor-1");
        public ElementScope CreateButton => _browserSession.FindButton("CREATE");
        public ElementScope AdditionalClauseTitle => _browserSession.FindCss(".additional-clause-0 p.text-ellipsis");
        #endregion

        #region Additonal Clauses methods
        public AdditionalClausesPage ClickAddAdditionalClause()
        {
            Retry.Timeout(() => AddAdditonalClause.Click(), 10);
            return this;
        }

        public AdditionalClausesPage EnterNameOfClause(string newAdditionalClause)
        {
            Thread.Sleep(500);
            Retry.Timeout(() => NameOfClause.SendKeys(newAdditionalClause), 10);
            return this;
        }

        public AdditionalClausesPage EnterClauseDetails()
        {
            Thread.Sleep(500);
            ClauseDetails.SendKeys("Enter my test data clause here");
            CreateButton.Click();
            _browserSession.HasNoContent("Add New Clause", new Options() { Timeout = TimeSpan.FromSeconds(5) });
            return this;
        }

        public string VerifyAdditionalClause(string additionalClause)
        {
            return Retry.Timeout(() => AdditionalClauseTitle.Text, 10);
        }

        public AdditionalClausesPage DialogIsPresent()
        {
            _browserSession.HasContent("Add New Clause", new Options() { Timeout = TimeSpan.FromSeconds(5) });
            Thread.Sleep(1000);
            return this;
        }
        #endregion
    }
}
