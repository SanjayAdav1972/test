﻿using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class EditorPage : HelperMethod
    {
        protected BrowserSession _browserSession;
        public EditorPage(BrowserSession browserSession) : base(browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Editor page objects
        public ElementScope EditClause => _browserSession.FindCss("#view290285");
        public ElementScope EditorTabButton => _browserSession.FindXPath("//span[text() = 'Charter Party']");
        public ElementScope EditorFullContent => _browserSession.FindCss("# inlineTemplateEditor > div > div");
        public ElementScope EditorConditionOfVesselContent => _browserSession.FindCss("#inlineTemplateEditor > div > div > table:nth-child(20) > tbody");
        public ElementScope EditorHeader => _browserSession.FindCss(".cptec-parent-container div span");
        public ElementScope DataField => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='VesselName']/..");
        public ElementScope DataFieldPlaceholder => _browserSession.FindXPath("//p/dfplaceholder[@dfsystemname='VesselName']");
        public ElementScope EditorDataFieldPlaceholder => _browserSession.FindXPath("//div[@id='editorx901877']/dfplaceholder");
        public ElementScope ValueDatafieldPlaceholder => _browserSession.FindXPath("//input[@class='cke_dialog_ui_input_text']");
        public ElementScope SaveButton => _browserSession.FindId("cpm-share-button");
        //public IEnumerable<ElementScope> ClauseLinesAddedText => _browserSession.FindAllCss("ins.ice-ins.ice-cts-1");
        public IEnumerable<ElementScope> ClauseLinesAddedText => _browserSession.FindAllXPath("//ins[@class='ice-ins ice-cts-1']");
        public ElementScope TemplateEditor => _browserSession.FindXPath(".//*[@id='inlineTemplateEditor']");
        public ElementScope EditorTemplate => _browserSession.FindXPath("//div[@class='cpm-drycargo-form cpm-boxform']");
        public ElementScope OwnerName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='OwnerCompany']");
        public ElementScope OwnerAndContact => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='OwnerAndContact']");
        public ElementScope OwnerTitle => _browserSession.FindXPath("//dfplaceholder[title='OwnerCompany']");
        public ElementScope ChartererName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='CSCompany']");
        public ElementScope ChartererAndContact => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='ChartererAndContact']");
        public ElementScope VesselName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='VesselName']");

        public ElementScope AdditionalClauseTitleAsba => _browserSession.FindCss(".additional-clauses-header #view-1");
        public ElementScope AdditionalClauseTitleBoxtime => _browserSession.FindXPath("//tr[2]//div[@class='cpm-cpcld-inner-container']/p[@id='view-1']");
        public ElementScope AdditionalClauseTitle => _browserSession.FindCss(".additional-span");
        public ElementScope AdditionalClauseTitleExxon => _browserSession.FindCss(".cpm-clause-title.bold-underlined");

        public IEnumerable<ElementScope> BoxtimeClauseLine => _browserSession.FindAllCss("p[text-line-order='330']");
        public IEnumerable<ElementScope> BaltimoreClauseLine => _browserSession.FindAllCss("p[text-line-order='44']");
        public IEnumerable<ElementScope> ClauseLinesAddTextCurrent => _browserSession.FindAllCss("span.add-text");
        public IEnumerable<ElementScope> Clauses => _browserSession.FindAllCss("p[text-line-order='120']");
        public IEnumerable<ElementScope> ClauseLinesCurrent => _browserSession.FindAllCss("cpm-cp-ckeditor-component div");
        #endregion

        #region Editor page methods
        public EditorPage ClickOnEditorTab()
        {
            Retry.Timeout(() => EditorTabButton.Click(), 10);
            return this;
        }

        public string VerifyAdditionalClauseTitle()
        {
            return AdditionalClauseTitle.Text.ToLower();
        }

        public string VerifyAdditionalClauseAsba()
        {
            return AdditionalClauseTitleAsba.Text.ToLower();
        }

        public string VerifyAdditionalClauseBoxtime()
        {
            return AdditionalClauseTitleBoxtime.Text.ToLower();
        }

        public string VerifyAdditionalClauseExxon()
        {
            return AdditionalClauseTitleExxon.Text.ToLower();
        }

        public string VerifyPlaceholderText()
        {
            var dataFieldPlaceholders = Retry.Timeout(() => FindElements(By.XPath("//p/dfplaceholder[@dfsystemname='VesselName']")), 10);
            var anyCurrentClausesLines = dataFieldPlaceholders.ToList().Last();
            return anyCurrentClausesLines.Text;
        }

        public EditorPage ClickPlaceholder()
        {
            Retry.Timeout(() =>
            {
                var dataFieldPlaceholdersLine = FindElements(By.XPath("//p/dfplaceholder[@dfsystemname='VesselName']"));
                var anyCurrentClausesLines = dataFieldPlaceholdersLine.ToList().First();
                anyCurrentClausesLines.Click();
            }, 5);

            Retry.Timeout(() =>
            {
                Actions actions = new Actions(((IWebDriver)_browserSession.Native));
                var dataFieldPlaceholders = FindElements(By.XPath("//div/dfplaceholder[@dfsystemname='VesselName']"));
                actions.ClickAndHold(dataFieldPlaceholders.ToList().Last()).MoveByOffset(1, 1).Perform();
                actions.DoubleClick(dataFieldPlaceholders.ToList().Last()).Perform();
            }, 5);
            return this;
        }

        public EditorPage EnterDataIntoPlaceholder(string value)
        {
            WebElementExtensions.WaitForElementToExist((IWebDriver)_browserSession.Native, By.XPath("//div[@class='col-md-12']/div/input"), TimeSpan.FromSeconds(350));
            var inputPlaceholderPopup = FindElement(By.XPath("//div[@class='col-md-12']/div/input"));
            inputPlaceholderPopup.Clear();
            inputPlaceholderPopup.SendKeys(value);
            SaveButton.Click();
            return this;
        }

        public EditorPage EnterDataIntoPlaceholderBoxtime(string value)
        {
            WebElementExtensions.WaitForElementToExist((IWebDriver)_browserSession.Native, By.XPath("//div[@class='col-md-12']/div/textarea"), TimeSpan.FromSeconds(350));
            var textareaPlaceholderPopup = FindElement(By.XPath("//div[@class='col-md-12']/div/textarea"));
            textareaPlaceholderPopup.Clear();
            textareaPlaceholderPopup.SendKeys(value);
            SaveButton.Click();
            return this;
        }

        protected string GetElementValue(IWebElement elem)
        {
            string actualValue = null;
            switch (elem.TagName.ToLower())
            {
                case "textarea":
                    actualValue = GetTextAreaValue(elem);
                    break;
                case "input":
                    actualValue = GetInputValue(elem);
                    break;
                default:
                    actualValue = elem.GetAttribute("value") ?? elem.Text;
                    break;
            }
            return actualValue;
        }

        private string GetInputValue(IWebElement elem)
        {
            elem = FindElement(By.XPath("//input[@class='cke_dialog_ui_input_text']"));
            string elem1 = elem.GetAttribute("value") ?? elem.Text;
            return elem1;
        }

        private string GetTextAreaValue(IWebElement elem)
        {
            elem = FindElement(By.XPath("//textarea[@class='cke_dialog_ui_input_textarea']"));
            string elem2 = elem.GetAttribute("value") ?? elem.Text;
            return elem2;

        }

        public void ClauseName(string name, string editText)
        {
            var clauseElement = FindElement(By.XPath(String.Format("//p[contains(text(),'{0}')]", name.ToUpper())));
            clauseElement.Click();
            clauseElement.Clear();
            clauseElement.SendKeys(editText);
        }

        public EditorPage EditAnyCurrentClauseLines(string editMessage)
        {
            var editClausesLine = FindElement(By.CssSelector(".cpm-cpcld-hover-container cpm-cp-ckeditor-component div"));
            editClausesLine.SendKeys(editMessage);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            return this;
        }

        public IList<string> GetAddedText()
        {
            var addedTextElements = _browserSession.FindAllCss("ins.ice-ins.ice-cts-1").ToList();
            var addedTexts = new List<string>();
            addedTextElements.ForEach(e => addedTexts.Add(e.Text.Trim()));
            return addedTexts;
        }

        public EditorPage ChooseAnyClauseToEdit(string templateName)
        {
            switch (templateName)
            {
                case "BOXTIMEMAERSK":
                case "BOXTIME":
                    var boxtimeClauses = BoxtimeClauseLine.WithAny();
                    boxtimeClauses.ClickElement();
                    break;
                case "BALTIMOREBERTHCP1913":
                    var baltimoreClauses = BaltimoreClauseLine.WithAny();
                    baltimoreClauses.ClickElement();
                    break;
                default:
                    var anyClauses = Clauses.WithAny();
                    anyClauses.ClickElement();
                    break;
            }

            return this;
        }

        public string VerifyOwnerName(string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    return OwnerAndContact.Text;
                case "ANGLOAMERICAN":
                    return OwnerTitle.Text;

                default:
                    return OwnerName.Text;
            }

        }

        public string VerifyChartererName(string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    return ChartererAndContact.Text;
                default:
                    return ChartererName.Text;
            }

        }

        public string VerifyVesselName()
        {
            return VesselName.Text;
        }
        #endregion
    }
}