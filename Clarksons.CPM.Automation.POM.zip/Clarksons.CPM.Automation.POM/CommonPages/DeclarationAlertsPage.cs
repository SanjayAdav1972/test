﻿using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class DeclarationAlertsPage
    {
        private readonly BrowserSession _browserSession;
        public DeclarationAlertsPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Declaration Alerts page objects 
        public ElementScope DeclarationAlertTextArea => _browserSession.FindXPath("//div[contains(@label,'Alert')]/textarea");
        public ElementScope DeclarationAlertRecipients => _browserSession.FindXPath("//label[contains(text(),'Alert Recipients')]/following-sibling::input");
        public ElementScope ScheduleDateTimeText => _browserSession.FindCss(".content-inline.cpm-cp-declaration-date>p");
        public ElementScope Calender => _browserSession.FindCss(".input-group-addon");
        public ElementScope CalenderArrowRight => _browserSession.FindCss(".glyphicon.glyphicon-chevron-right");
        public ElementScope ScheduleDate => _browserSession.FindXPath("//td[contains(text(),'20')]");
        public ElementScope ScheduleHour => _browserSession.FindXPath("//span[@class='hour'][contains(text(),'11:00 AM')]");
        public ElementScope ScheduleMinutes => _browserSession.FindXPath("//span[@class='minute'][contains(text(),'11:25 AM')]");
        public ElementScope TimeZone => _browserSession.FindXPath("//select[@ng-model='vm.timeZone']/option[contains(text(),'London')]");
        public ElementScope CreateButton => _browserSession.FindButton("CREATE");
        #endregion 

        #region Declaration Alerts page methods
        public DeclarationAlertsPage AddDeclarationAlert()
        {
            Retry.Timeout(() => DeclarationAlertTextArea.Enter("Text"), 10);
            DeclarationAlertRecipients.Enter("Abc@clarksons.com; xyz@clarksons.com");
            Calender.Click();
            CalenderArrowRight.Click();
            ScheduleDate.Click();
            ScheduleHour.Click();
            ScheduleMinutes.Click();
            TimeZone.Click();
            CreateButton.Click();
            return this;
        }

        public string GetScheduleDateTime()
        {
            //string scheduleTimeText = ScheduleDateTimeText.Text;   .content-inline.cpm-cp-declaration-date>p
            return ScheduleDateTimeText.Text;
        }
        #endregion
    }
}