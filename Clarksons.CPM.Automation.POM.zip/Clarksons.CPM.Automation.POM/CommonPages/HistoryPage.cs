﻿using Coypu;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class HistoryPage
    {
        private readonly BrowserSession _browserSession;
        public HistoryPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region History page objects 
        public ElementScope HistoryTab => _browserSession.FindXPath("//uib-tab-heading[contains(text(),'History')]");
        #endregion

        #region History page methods 
        public void ClickOnHistory()
        {
            HistoryTab.Click();
        }
        #endregion
    }
}
