﻿using Clarksons.CPM.Automation.Utilities.Extensions;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    public class InvoicingPage
    {
        private readonly BrowserSession _browserSession;
        public InvoicingPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
            //Assert.AreEqual(InvoicePageTitle.Text.ToLower(), "invoicing");
        }

        #region Invoicing Page objects
        public ElementScope CPIDField => _browserSession.FindXPath("//div[@class='form-group has-feedback']/label[contains(text(),'CP ID:')]/following-sibling::input");
        public ElementScope CompanyField => _browserSession.FindCss("div[class='form-group has-feedback']>input[ng-model='vm.company']");
        public ElementScope CompanyFieldDropdown => _browserSession.FindCss("ul[class='dropdown-menu']");
        public ElementScope CompanyExpandButton => _browserSession.FindCss(".fa.fa-plus-square");
        public ElementScope ID => _browserSession.FindXPath("//table/tbody/tr[2]/td[2]/div//table/tbody/tr/td[1]");
        public ElementScope ActionCheckBox => _browserSession.FindXPath("//table/tbody/tr[2]/td[2]/div/table/tbody/tr/td[10]/input");
        public ElementScope RaiseButton => _browserSession.FindButton("Raise");
        public ElementScope InvoicePageTitle => _browserSession.FindXPath("//h1");
        public ElementScope ConfirmButton => _browserSession.FindButton("CONFIRM");
        #endregion

        #region Invoicing page methods
        public InvoicingPage EnterCPID(string cpId)
        {
            CPIDField.Enter(cpId);
            return this;
        }

        public InvoicingPage ClickActionOnCP(string cpId)
        {
            CompanyExpandButton.Click();
            string id = ID.Text;
            if (cpId == id)
            {
                ActionCheckBox.Click();
            }
            else
            {
                var failMessage = string.Format("CPID {0} is not displayed", id);
                var helper = new HelperMethod(_browserSession);
                helper.CreateSoftAssertion(failMessage);
            }

            return this;
        }

        public InvoicingPage ClickCompanyFieldDropdown()
        {
            CompanyFieldDropdown.ClickElement();
            return this;
        }

        public InvoicingPage RaiseInvoice()
        {
            RaiseButton.Click();
            ConfirmButton.Click();
            return this;
        }
        #endregion
    }
}