﻿using System.Configuration;
using System.Data.SqlClient;

namespace Clarksons.CPM.Automation.Utilities.Database
{
    public class DbInteraction
    {
        private readonly string _connectionstring;
        public DbInteraction()
        {
            if (ConfigurationManager.ConnectionStrings["RM"] != null)
            {
                _connectionstring = ConfigurationManager.ConnectionStrings["RM"].ConnectionString;
            }
        }

        public void ExecuteSelectQuery(string query)
        {
            using (var sqlConnection = new SqlConnection(_connectionstring))
            using (var cmd = new SqlCommand(query, sqlConnection))
            {
                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
        }

        public void ExecuteUpdateQuery(string query)
        {
            using (var sqlConnection = new SqlConnection(_connectionstring))
            using (var cmd = new SqlCommand(query, sqlConnection))
            {
                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
        }
    }
}
