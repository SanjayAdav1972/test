﻿using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Data;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class InputExtensions
    {
        public static string GetInputDisplayText(this ElementScope input)
        {
            return input.Value ?? input.Text;
        }

        public static string GetLabelForInput(this ElementScope field)
        {
            var nearestText = "";
            var element = field.Native();
            while (element != null && string.IsNullOrWhiteSpace(nearestText))
            {
                nearestText = element.Text;
                element = element.Parent();
            }
            if (string.IsNullOrWhiteSpace(nearestText))
            {
                throw new Exception("Expected to find a label text for input" +
                    " but could not find any for itself or any parent elements");
            }

            return nearestText.Trim();
        }

        public static ElementScope GetInputByLabel(this ElementScope container, string label)
        {
            var fields = container.GetAllInputs(null);
            var input = fields.Single(x => GetLabelForInput(x).Contains(label.Trim()));
            return input;
        }

        public static string GetInputValue(this ElementScope input)
        {
            var isInput = "text,number".Split(',').Contains(input["type"]?.ToLower());
            var tagName = input.Native().TagName.ToLower();
            var isTextarea = tagName == "textarea";
            var isSelector = tagName == "select";
            var isCheckbox = input["type"] == "checkbox";
            var isCustomCheckbox = input.HasClass("switch");

            if (isInput || isTextarea)
            {
                return input.GetInputDisplayText();
            }
            if (isCustomCheckbox)
            {
                return (input.HasClass("checked")).ToString();
            }
            if (isCheckbox)
            {
                return input.Selected.ToString();
            }
            if (isSelector)
            {
                return input.SelectedOption;
            }
            throw new Exception("Could not return value for input as code not implemented for this input scenario");
        }

        public static void Enter(this ElementScope element, string text)
        {
            if (Setting.UseFastDataEntry)
            {
                var executor = (IJavaScriptExecutor)element.NativeDriver();
                executor.ExecuteScript("$(arguments[0]).val(arguments[1]).change();", element.Native(), text);
            }
            else
            {
                CodeHelper.CanFail(element.Native().Clear);
                element.SendKeys(text);
            }
        }

        public static void Type(this ElementScope element, string text)
        {
            CodeHelper.CanFail(element.Native().Clear);
            element.SendKeys(text);
        }

        public static bool CanChangeContent(this ElementScope input)
        {
            var currentContent = GetInputDisplayText(input);
            try
            {
                input.SendKeys(Guid.NewGuid().ToString(),
                    new Options() { Timeout = TimeSpan.FromSeconds(1) });
            }
            catch (InvalidElementStateException invalidElementStateException)
            {
                var sva = invalidElementStateException;
                return false;
            }
            var newContent = GetInputDisplayText(input);
            return !currentContent.Equals(newContent);
        }
    }
}