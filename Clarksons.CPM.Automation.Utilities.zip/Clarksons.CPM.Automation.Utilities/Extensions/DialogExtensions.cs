﻿using Coypu;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class DialogExtensions
    {
        public static void IsDialogClosed(this ElementScope dialogTitle)
        {
            if (!dialogTitle.Missing())
            {
                throw new Exception("Dialog was not closed");
            }
        }
    }
}