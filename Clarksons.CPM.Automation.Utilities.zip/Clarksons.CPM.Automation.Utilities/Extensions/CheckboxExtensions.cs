﻿using Coypu;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class CheckboxExtensions
    {
        public static void CheckCheckbox(this ElementScope checkbox)
        {
            var inputType = checkbox["type"];
            if (inputType == "checkbox")
            {
                checkbox.Check();
            }
            if (checkbox.HasClass("switch"))
            {
                if (!checkbox.HasClass("checked"))
                {
                    checkbox.ClickElement();
                }
            }
        }

        public static void UncheckCheckbox(this ElementScope checkbox)
        {
            var inputType = checkbox["type"];
            if (inputType == "checkbox")
            {
                checkbox.Uncheck();
            }
            if (checkbox.HasClass("switch"))
            {
                if (checkbox.HasClass("checked"))
                {
                    checkbox.ClickElement();
                }
            }
        }

        public static bool IsCheckboxChecked(this ElementScope checkbox)
        {
            var inputType = checkbox["type"];
            if (inputType == "checkbox")
            {
                return checkbox.Selected;
            }
            if (checkbox.HasClass("switch"))
            {
                return checkbox.HasClass("checked");
            }
            return false;
        }

        public static bool IsCheckboxUnchecked(this ElementScope checkbox)
        {
            return !IsCheckboxChecked(checkbox);
        }
    }
}