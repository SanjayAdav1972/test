﻿using Coypu;
using OpenQA.Selenium;
using OpenQA.Selenium.Internal;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class CoypuExtensions
    {
        public static IWebElement Native(this ElementScope elementScope)
        {
            return (IWebElement)elementScope.Now().Native;
        }

        public static IWebDriver NativeDriver(this ElementScope element)
        {
            return ((IWrapsDriver)element.Native()).WrappedDriver;
        }
    }
}