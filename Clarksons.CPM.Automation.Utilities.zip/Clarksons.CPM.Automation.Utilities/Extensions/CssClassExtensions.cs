﻿using Coypu;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class CssClassExtensions
    {
        public static bool HasClass(this ElementScope element, string className)
        {
            var classes = element.Native().GetAttribute("class");
            return element.Native().GetAttribute("class").Split(' ').Contains(className);
        }
    }
}