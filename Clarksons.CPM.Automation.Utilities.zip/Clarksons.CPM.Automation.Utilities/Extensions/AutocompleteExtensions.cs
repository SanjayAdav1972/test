﻿using Coypu;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class AutocompleteExtensions
    {
        public static void AutoComplete(this BrowserSession browserSession, ElementScope autocomplete, string value)
        {
            autocomplete.Type(value);
            browserSession.ClickLink(value, options: new Options()
            {
                Timeout = TimeSpan.FromSeconds(15)
            });
        }
    }
}