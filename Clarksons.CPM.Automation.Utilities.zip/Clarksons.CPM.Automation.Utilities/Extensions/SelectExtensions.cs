﻿using Coypu;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    public static class SelectExtensions
    {
        public static string SelectOption(this ElementScope selectInput, bool useRandomData)
        {
            selectInput.ClickElement();

            var options = selectInput.FindAllCss("option")
                .Where(x => !string.IsNullOrWhiteSpace(x.Text));

            var testData = options.WithAny();
            if (!useRandomData)
            {
                testData = options.Last();
            }

            testData.ClickElement();

            return selectInput.GetInputDisplayText();
        }
    }
}