﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace Clarksons.CPM.Automation.Utilities
{
    public static class Retry
    {
        public static double TimeoutMultiplier = 1;

        public static T Timeout<T>(Func<T> function, double timeoutInSeconds)
        {
            var stopwatch = new Stopwatch();
            T result = default(T);
            stopwatch.Start();
            var timeoutMilliseconds = (timeoutInSeconds * TimeoutMultiplier) * 1000;
            var retryCount = 0;
            var exceptions = new List<Exception>();
            while(stopwatch.ElapsedMilliseconds < timeoutMilliseconds && result == null)
            {
                try
                {
                    result = function();
                }
                catch (Exception ex)
                {
                    Console.Write("Retried: count {0}...", retryCount);
                    exceptions.Add(ex);         // ToDo: Create Custom exception class e.g. TimeoutExpcetion
                    Thread.Sleep(1000);
                    retryCount++;
                }
            }

            stopwatch.Stop();

            if (result == null)
            {
                // ToDo: Create Custom exception class
                throw new AggregateException($"Retried {retryCount} times. Timed out after {stopwatch.Elapsed.TotalSeconds} seconds.", exceptions);
            }
            else
            {
                exceptions.Clear();
            }

            return result;
        }

        public static void Timeout(Action action, double timeoutInSeconds)
        {
            Timeout<string>(() =>
            {
                action();
                return "";
            }, timeoutInSeconds);
        }
    }
}
