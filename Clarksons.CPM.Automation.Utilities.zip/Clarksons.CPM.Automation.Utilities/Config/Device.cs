﻿namespace Clarksons.CPM.Automation.Utilities.Config
{
    public enum Device
    {
        DesktopMax,
        Mobile      // future implementation
    }
}
