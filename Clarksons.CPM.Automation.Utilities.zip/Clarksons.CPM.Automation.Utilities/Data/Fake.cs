﻿using System;

namespace Clarksons.CPM.Automation.Utilities.Data
{
    public static class Fake
    {
        public static string InputText => Guid.NewGuid().ToString().Substring(0, 5);
        public static string InputNumber => Convert.ToInt32((new Random().NextDouble() * (10000 - 100) + 100)).ToString();
        public static bool InputCheckBoxValue => new Random().NextDouble() >= 0.5;
    }
}