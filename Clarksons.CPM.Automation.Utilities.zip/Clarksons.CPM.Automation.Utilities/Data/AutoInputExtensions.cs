﻿using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using Should.Fluent;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Data
{
    public static class AutoInputExtensions
    {
        public static string InputField(this ElementScope field,
            Func<string, string, string> validInputTypeFunc,
            bool useRandomData, int fieldIndex, int testDataSetNumber)
        {
            var inputLabel = field.GetLabelForInput();
            var inputType = validInputTypeFunc(inputLabel, field["type"]);
            var tagName = field.Native().TagName.ToLower();
            var isTextarea = tagName == "textarea";
            var testData = "";
            if (inputType == "text" || isTextarea)
            {
                var randomData = useRandomData ? $" [{Fake.InputText}]" : "";
                testData = inputLabel + " " + testDataSetNumber + randomData;
                field.Enter(testData);
            }
            if (inputType == "number")
            {
                var randomData = useRandomData ? Fake.InputNumber : "";
                testData = int.Parse($"{1 + fieldIndex:00}{testDataSetNumber:00}{randomData}").ToString();
                field.Enter(testData);
            }
            if (inputType == "checkbox" || field.HasClass("switch"))
            {
                var checkedValue = Fake.InputCheckBoxValue;
                if (!useRandomData)
                {
                    checkedValue = true;
                }
                if (checkedValue == true)
                {
                    field.CheckCheckbox();
                }
                else
                {
                    field.UncheckCheckbox();
                }
                testData = checkedValue.ToString();
            }
            return testData;
        }

        public static IEnumerable<string> PopulateFields(this ElementScope fieldsIn,
            Func<string, string, string> validInputTypeFunc,
            bool useRandomData, int testDataSetNumber,
            Action preFills = null, IEnumerable<string> excludeInputs = null,
            bool onlyBlankFields = true)
        {
            preFills?.Invoke();

            var fieldData = new List<string>();

            var allInputs = fieldsIn.GetAllInputs(excludeInputs);

            allInputs.ToList().ForEach(input =>
            {
                var inputIsEmpty = string.IsNullOrWhiteSpace(input.GetInputDisplayText());
                if (onlyBlankFields && input.IsInputOrSelectEmpty())
                {
                    if (input.Native().TagName == "select")
                    {
                        input.SelectOption(useRandomData);
                    }
                    else
                    {
                        var fieldIndex = allInputs.ToList().IndexOf(input);
                        input.InputField(validInputTypeFunc, useRandomData, fieldIndex, testDataSetNumber);
                    }
                }
                fieldData.Add(input.GetInputValue());
            });
            return fieldData;
        }

        private static bool IsInputOrSelectEmpty(this ElementScope input)
        {
            var isInput = "text,number".Split(',').Contains(input["type"]?.ToLower());
            var tagName = input.Native().TagName.ToLower();
            var isTextarea = tagName == "textarea";
            var isSelector = tagName == "select";
            if (isInput || isTextarea)
            {
                return string.IsNullOrWhiteSpace(input.GetInputDisplayText());
            }
            if (isSelector)
            {
                return string.IsNullOrWhiteSpace(input.SelectedOption);
            }
            return true;
        }

        public static void CheckFields(this ElementScope fieldsIn, IEnumerable<String> fieldData,
            IEnumerable<string> excludeInputs)
        {
            var allInputs = fieldsIn.GetAllInputs(excludeInputs).ToList();

            allInputs.Count().Should().Equal(fieldData.Count());

            var exceptions = new List<Exception>();

            for (int i = 0; i < allInputs.Count(); i++)
            {
                var input = allInputs[i];
                var data = fieldData.ToList()[i];
                if (input.GetInputValue() != data)
                {
                    exceptions.Add(new Exception(
                        $"Input field {input.Native().TagName} in id {input.Native().FindIdOrNameOrElement()} " +
                        $"value of {input.GetInputValue()} did not equal {data}"));
                }
            };

            if (exceptions.Any())
            {
                throw new AggregateException("Some inputs did not contain values as expected", exceptions);
            }
        }

        public static IEnumerable<SnapshotElementScope> GetAllInputs(this ElementScope container,
            IEnumerable<string> exclude)
        {
            exclude = exclude ?? new string[] { };
            var inputs = container.FindAllCss("input,textarea,select,span.switch").ToList();
            inputs = inputs.Where(x => !exclude.Any(x.OuterHTML.Contains)).ToList();
            return inputs;
        }
    }
}
