﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.UI;
using System.Linq;
using Clarksons.Automation.TestReporting.SpecFlow;
using Newtonsoft.Json;
using TechTalk.SpecFlow;
using Clarksons.Automation.TestReporting.Utility;
using TechTalk.SpecFlow.Bindings;
using System.Configuration;
using System.Text;
using System.Net.Http;
using System.Web;

namespace Clarksons.Automation.TestReporting.Services
{
    public class TestTransformer : ITestTransformer
    {
        private TestLogger _testcontextcontainer;

        private readonly string _createbugscript = "function CreateBug(title, details, tfsUrl, tfsKey, tfsIteration)\n" + 
            "{\n" +
            "var ops = [ {path: \"/fields/System.Title\", op: \"add\",value: title},{path: \"/fields/Microsoft.VSTS.TCM.ReproSteps\",op: \"add\",value: details },{path: \"/fields/System.IterationPath\",op: \"add\",value: tfsIteration}];\n" +
            "var xhr = new XMLHttpRequest();\n" +
            "var url = tfsUrl + '/_apis/wit/workItems/$Bug?api-version=1.1';\n" +
            "xhr.open(\"PATCH\", url, true);\n" +
            "xhr.setRequestHeader('Content-Type', 'application/json-patch+json');\n" +
            "xhr.setRequestHeader('Authorization', 'Basic ' + tfsKey);\n" +
            "var data = JSON.stringify(ops);\n" +
            "xhr.send(data);\n" +
            "xhr.onprogress = function () {window.alert(\"Operation in progress!\");}\n" +
            "xhr.onload = function () {window.alert(\"Operation completed with status code\" + xhr.status);}\n" +
            "xhr.onloadend = function () {var response = xhr.responseText;var jsonResponse = JSON.parse(response); window.open(tfsUrl + '/_workitems?id=' + jsonResponse[\"id\"]);}\n" +
            "}";

        public TestTransformer(TestLogger testContextContainer) { _testcontextcontainer = testContextContainer; }

        public void ToJsonFormat(string filePath) => File.WriteAllText(filePath, JsonConvert.SerializeObject(_testcontextcontainer));

        public void ToHtmlReport(string filePath, string filename)
        {
            StringWriter stringWriter = new StringWriter();

            using (HtmlTextWriter writer = new HtmlTextWriter(stringWriter))
            {
                writer.RenderBeginTag("!DOCTYPE html");
                writer.RenderBeginTag(HtmlTextWriterTag.Html); //<html>

                #region HEAD
                writer.RenderBeginTag(HtmlTextWriterTag.Head); //<head>
                writer.AddAttribute("charset", "UTF-8");
                writer.RenderBeginTag(HtmlTextWriterTag.Meta);//<meta>
                writer.RenderEndTag();//</meta>
                writer.AddAttribute("name", "viewport");
                writer.AddAttribute("content", "width=device-width, initial-scale=1");
                writer.RenderBeginTag(HtmlTextWriterTag.Meta);//<meta>
                writer.RenderEndTag();//</meta>
                writer.AddAttribute(HtmlTextWriterAttribute.Rel, "stylesheet");
                writer.AddAttribute(HtmlTextWriterAttribute.Href, "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css");
                writer.RenderBeginTag(HtmlTextWriterTag.Link);//<link>
                writer.RenderEndTag();//</link>
                writer.AddAttribute(HtmlTextWriterAttribute.Src, "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js");
                writer.RenderBeginTag(HtmlTextWriterTag.Script); //<script>
                writer.RenderEndTag();//</script>
                writer.AddAttribute(HtmlTextWriterAttribute.Src, "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js");
                writer.RenderBeginTag(HtmlTextWriterTag.Script);//<script>
                writer.RenderEndTag();//</script>
                writer.AddAttribute(HtmlTextWriterAttribute.Src, "createbug.js");
                writer.RenderBeginTag(HtmlTextWriterTag.Script);//<script>
                writer.RenderEndTag();//</script>

                #region CSS
                writer.RenderBeginTag(HtmlTextWriterTag.Style); //<style>
                writer.WriteEncodedText(@"btn:after { font-family: ""Glyphicons Halflings""; content: ""\e114""; float: right; margin-left: 15px; }");
                writer.RenderEndTag();//</style>
                writer.RenderBeginTag(HtmlTextWriterTag.Style);//<style>
                writer.WriteEncodedText(@"btn.collapsed:after {content: ""\e080"";}");
                writer.RenderEndTag();//</style>
                writer.RenderBeginTag(HtmlTextWriterTag.Style);
                writer.WriteEncodedText(@"table tr td:last-child {width: 100%;}");
                writer.RenderEndTag();//</style>
                #endregion

                writer.RenderEndTag(); //</head>
                #endregion

                writer.RenderBeginTag(HtmlTextWriterTag.Body);//<body>

                writer.AddAttribute(HtmlTextWriterAttribute.Class, "container-fluid");
                writer.RenderBeginTag(HtmlTextWriterTag.Div); //open main container

                RenderTestTitle(writer);
                RenderRunOverview(writer);

                #region RENDER FEATURES > SCEANARIOS > STEPS
                RenderFeatureResults(writer, _testcontextcontainer.Features);
                #endregion

                writer.RenderEndTag(); //close main container
                writer.RenderEndTag();//</body>
                writer.RenderEndTag(); //</html>               
            }

            File.WriteAllText(Path.Combine(filePath, filename), stringWriter.ToString());
            //save also the scripts in the same folder
            File.WriteAllText(Path.Combine(filePath, "createbug.js"), _createbugscript);

            //cleanup garbage
            if (CleanerService.Instance != null)
                CleanerService.ClearGargage();
        }

        private void RenderTestTitle(HtmlTextWriter writer)
        {
            if (_testcontextcontainer.Failed > 0)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "text-center alert alert-danger");
            }
            else
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "text-center alert alert-success");
            }
            writer.RenderBeginTag(HtmlTextWriterTag.H1);//open title
            writer.WriteEncodedText($"{_testcontextcontainer.User} on {_testcontextcontainer.Environment} Environment - {_testcontextcontainer.StartTime}");
            writer.RenderEndTag();//close title
        }

        private void RenderRunOverview(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "row");
            writer.RenderBeginTag(HtmlTextWriterTag.Div); //<div>

            #region TABLE RUN RESULTS
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "col-lg-2");
            writer.RenderBeginTag(HtmlTextWriterTag.Div); //Open Div fluid


            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            writer.WriteEncodedText("Run Results");
            writer.RenderEndTag();

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "table table-bordered");
            writer.RenderBeginTag(HtmlTextWriterTag.Table); //<table>
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody); //<tbody>
            #region TOTAL
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "active");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Total");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.Total.ToString());
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion
            #region PASSED
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "success");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Passed");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.Passed.ToString());
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion
            #region FAILED
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "danger");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Failed");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.Failed.ToString());
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion
            #region INCONCLUSIVE
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "warning");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Inconclusive");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.Inconclusive.ToString());
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion

            writer.RenderEndTag();//</tbody>
            writer.RenderEndTag();//</table>
            writer.RenderEndTag();//</div>
            #endregion

            #region TABLE RUN TIME
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "col-lg-4");
            writer.RenderBeginTag(HtmlTextWriterTag.Div); //Open Div fluid


            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            writer.WriteEncodedText("Run Time");
            writer.RenderEndTag();

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "table table-bordered table-striped");
            writer.RenderBeginTag(HtmlTextWriterTag.Table); //<table>
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody); //<tbody>

            #region START
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Start");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.StartTime.ToString("dd/MM/yyyy HH:mm"));
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion

            #region END
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("End");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.EndTime.ToString("dd/MM/yyyy HH:mm"));
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion

            #region DURATION
            writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th); //<th>
            writer.WriteEncodedText("Duration");
            writer.RenderEndTag(); //</th>
            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
            writer.WriteEncodedText(_testcontextcontainer.Duration);
            writer.RenderEndTag(); //</td>
            writer.RenderEndTag(); //</tr>
            #endregion

            writer.RenderEndTag();//</tbody>
            writer.RenderEndTag();//</table>
            writer.RenderEndTag();//</div>
            #endregion

            writer.RenderEndTag(); //</div>
        }

        private void RenderStepsResults(HtmlTextWriter writer, List<StepContextContainer> steps, string collapseId)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, collapseId);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "collapse col-lg-12");
            writer.RenderBeginTag(HtmlTextWriterTag.Div); //<div>
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "table");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);//<table>
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);//<tbody>



            foreach (var step in steps)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
                #region STEP TEXT
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>

                //Set step text color depending on the outcome
                switch (step.StepStatus)
                {
                    case Enums.TestStatus.Passed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "text-success");
                        break;
                    case Enums.TestStatus.Failed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "text-danger");
                        break;
                    case Enums.TestStatus.Inconclusive:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "text-warning");
                        break;

                }
                writer.RenderBeginTag(HtmlTextWriterTag.Strong); //<strong>
                writer.WriteEncodedText($"{Enum.GetName(typeof(StepDefinitionType), step.StepType)} {step.StepTitle}"); //step text
                writer.RenderEndTag();//</strong>

                //print step data table if present
                if (step.Table != null)
                {
                    Table steptable = step.Table;

                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "table table-bordered");
                    writer.RenderBeginTag(HtmlTextWriterTag.Table);//<table>
                    writer.RenderBeginTag(HtmlTextWriterTag.Thead);//<thead>
                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>

                    foreach (var header in steptable.Header)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Th);//<th>
                        writer.WriteEncodedText(header);
                        writer.RenderEndTag();//</th>
                    }
                    writer.RenderEndTag();//</tr>
                    writer.RenderEndTag();//</thead>

                    writer.RenderBeginTag(HtmlTextWriterTag.Tbody);//<tbody>
                    foreach (var row in steptable.Rows)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>

                        foreach (var td in row.Values)
                        {
                            writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                            writer.WriteEncodedText(td);
                            writer.RenderEndTag();//</td>
                        }

                        writer.RenderEndTag();//</tr>
                    }
                    writer.RenderEndTag();//</tbody>
                    writer.RenderEndTag();//</table>
                }
                writer.RenderEndTag(); //</td>
                #endregion

                #region STATUS ICON
                //render status icon
                writer.RenderBeginTag(HtmlTextWriterTag.Td); //<td>
                switch (step.StepStatus)
                {
                    case Enums.TestStatus.Passed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-ok");
                        break;
                    case Enums.TestStatus.Failed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-remove");
                        break;
                    case Enums.TestStatus.Inconclusive:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-alert");
                        break;
                }
                writer.RenderBeginTag(HtmlTextWriterTag.Span);//<span>
                writer.RenderEndTag();//</span>
                writer.RenderEndTag(); //</td>
                #endregion

                #region IMAGES & GIF
                //if images are present
                writer.RenderBeginTag(HtmlTextWriterTag.Td); //<td>

                if (string.IsNullOrWhiteSpace(step.Gif))
                {
                    foreach (var img in step.ScreenShotPath)
                    {
                       RenderImage(writer, img, 20);
                    }
                }
                else
                {
                    RenderImage(writer, step.Gif, 50);
                }
                writer.RenderEndTag(); //</td>
                #endregion

                writer.RenderEndTag(); //</tr>
            }

            writer.RenderEndTag();//</tbody>
            writer.RenderEndTag();//</table>
            writer.RenderEndTag();//</div>

        }

        private void RenderScenarioResults(HtmlTextWriter writer, List<ScenarioContextContainer> scenarios, string collapseId)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, collapseId);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "collapse");
            writer.RenderBeginTag(HtmlTextWriterTag.Div); //<div>
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "table");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);//<table>
            #region THEAD
            writer.RenderBeginTag(HtmlTextWriterTag.Thead);//<thead>
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Test");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Time");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Duration");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Status");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Message");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Tags");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Support Files");
            writer.RenderEndTag();
            writer.RenderEndTag();//</tr>
            writer.RenderEndTag();//</thead>
            #endregion

            #region TBODY
            foreach (var scenario in scenarios)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody); //<tbody>
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
                #region TITLE
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.WriteEncodedText(scenario.ScenarioName);
                writer.RenderEndTag();//</td>
                #endregion
                #region START TIME
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.WriteEncodedText(scenario.StartTime.ToString("dd/MM/yyyy HH:mm"));
                writer.RenderEndTag();//</td>
                #endregion
                #region DURATION
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.WriteEncodedText(scenario.Duration);
                writer.RenderEndTag();//</td>
                #endregion
                #region STATUS
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                var status = string.Empty;
                switch (scenario.Status)
                {
                    case Enums.TestStatus.Passed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "label label-success");
                        status = "Passed";
                        break;
                    case Enums.TestStatus.Failed:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "label label-danger");
                        status = "Failed";
                        break;
                    case Enums.TestStatus.Inconclusive:
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "label label-warning");
                        status = "Inconclusive";
                        break;
                }
                writer.RenderBeginTag(HtmlTextWriterTag.Span); //<span>
                writer.WriteEncodedText(status);
                writer.RenderEndTag();//</span>
                writer.RenderEndTag();//</td>
                #endregion
                #region MESSAGE
                if (scenario.TestOutput != null)
                {
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                    writer.WriteEncodedText(scenario.TestOutput.Message);
                    writer.RenderEndTag();//</td>
                }
                else
                {
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                    writer.WriteEncodedText("No Message");
                    writer.RenderEndTag();//</td>
                }
                #endregion
                #region TAGS
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.WriteEncodedText(scenario.Tags.ToList().SplitList());
                writer.RenderEndTag();//</td>
                #endregion
                #region SUPPORT FILES
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>

                if (scenario.ExportedFiles.Count > 0)
                {
                    foreach (var file in scenario.ExportedFiles)
                    {
                        writer.AddAttribute(HtmlTextWriterAttribute.Href, $"file:{file}");
                        writer.AddAttribute("download", string.Empty);
                        writer.RenderBeginTag(HtmlTextWriterTag.A);//<a>
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-download-alt");
                        writer.RenderBeginTag(HtmlTextWriterTag.Span);//<span>
                        writer.RenderEndTag();//</span>
                        writer.RenderEndTag();//</a>
                    }
                }
                else
                {
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                    writer.WriteEncodedText("No Files");
                    writer.RenderEndTag();//</td>
                }
                writer.RenderEndTag();//</td>
                #endregion

                #region BUTTONS
                #region STEPS COLLAPSE BUTTON
                var stepcolid = $"step_{Tools.GenerateRandomInt()}";
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.AddAttribute(HtmlTextWriterAttribute.Type, "button");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "btn btn-success collapsed");
                writer.AddAttribute("data-toggle", "collapse");
                writer.AddAttribute("data-target", $"#{stepcolid}");
                writer.AddAttribute("aria-expanded", "false");
                writer.RenderBeginTag(HtmlTextWriterTag.Button);//<button>
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-collapse-down");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);//<span>
                writer.WriteEncodedText("Steps");
                writer.RenderEndTag();//</span>
                writer.RenderEndTag();//</button>

                #endregion
                #region CREATE BUG ON TFS BUTTON
                if (scenario.Status == Enums.TestStatus.Failed)
                {
                    string bugtitle = scenario.ScenarioName;
                    string bugdetails = BuildBugMessage(scenario);
                    string tfsurl = ConfigurationManager.AppSettings["TfsURL"];
                    string tfskey = ConfigurationManager.AppSettings["TfsKey"];
                    string tfsIteration = ConfigurationManager.AppSettings["TfsIteration"];

                    writer.AddAttribute(HtmlTextWriterAttribute.Type, "button");
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "btn btn-danger");
                    writer.AddAttribute(HtmlTextWriterAttribute.Onclick, $"javascript:CreateBug('{bugtitle}','{bugdetails}','{tfsurl}','{tfskey}','{tfsIteration}')");
                    writer.RenderBeginTag(HtmlTextWriterTag.Button);//<button>
                    writer.RenderBeginTag(HtmlTextWriterTag.Span);//<span>
                    writer.WriteEncodedText("Create Bug");
                    writer.RenderEndTag();//</span>
                    writer.RenderEndTag();//</button>
                }
                #endregion
                writer.RenderEndTag();//</td>
                #endregion

                writer.RenderEndTag();//</tr>
                #region STEPS RENDERING
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "8");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                RenderStepsResults(writer, scenario.StepList, stepcolid);
                writer.RenderEndTag();//</td>
                writer.RenderEndTag();//</tr>
                #endregion
                writer.RenderEndTag(); //</tbody>
            }
            #endregion

            writer.RenderEndTag();//</table>
            writer.RenderEndTag();//</div>
        }

        private void RenderFeatureResults(HtmlTextWriter writer, List<FeatureContextContainer> features)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "container-fluid");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);//<div>
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "col-lg-12");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);//<div>

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "table");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);//<table>
            #region THEAD
            writer.RenderBeginTag(HtmlTextWriterTag.Thead);//<thead>
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Feature");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Status");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Tot");
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.WriteEncodedText("Breakdown");
            writer.RenderEndTag();
            writer.RenderEndTag();//</tr>
            writer.RenderEndTag();//</thead>
            #endregion

            #region TBODY
            foreach (var feature in features)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody);//<tbody>
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
                #region TITLE
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.WriteEncodedText(feature.Title);
                writer.RenderEndTag();
                #endregion
                #region STATUS
                writer.AddAttribute(HtmlTextWriterAttribute.Style, "width:20%");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "progress");
                writer.RenderBeginTag(HtmlTextWriterTag.Div);//<div>
                var pass = ((float)feature.Passed / (float)feature.Total) * 100.00;
                var fail = ((float)feature.Failed / (float)feature.Total) * 100.00;
                var inc = ((float)feature.Inconclusive / (float)feature.Total) * 100;
                #region PASS
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "progress-bar progress-bar-success");
                writer.AddAttribute("role", "progressbar");
                writer.AddAttribute("aria-valuenow", pass.ToString());
                writer.AddAttribute("aria-valuemin", "0");
                writer.AddAttribute("aria-valuemax", "100");
                writer.AddAttribute(HtmlTextWriterAttribute.Style, $"width:{pass}%");
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.RenderEndTag();
                #endregion
                #region FAIL
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "progress-bar progress-bar-danger");
                writer.AddAttribute("role", "progressbar");
                writer.AddAttribute("aria-valuenow", fail.ToString());
                writer.AddAttribute("aria-valuemin", "0");
                writer.AddAttribute("aria-valuemax", "100");
                writer.AddAttribute(HtmlTextWriterAttribute.Style, $"width:{fail}%");
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.RenderEndTag();
                #endregion
                #region INC
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "progress-bar progress-bar-warning");
                writer.AddAttribute("role", "progressbar");
                writer.AddAttribute("aria-valuenow", inc.ToString());
                writer.AddAttribute("aria-valuemin", "0");
                writer.AddAttribute("aria-valuemax", "100");
                writer.AddAttribute(HtmlTextWriterAttribute.Style, $"width:{inc}%");
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.RenderEndTag();
                #endregion
                writer.RenderEndTag();//</div>
                writer.RenderEndTag();//</td>
                #endregion
                #region TOT
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "badge");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.WriteEncodedText(feature.Total.ToString());
                writer.RenderEndTag();
                writer.RenderEndTag();
                #endregion
                #region SCENARIOS BUTTON COLLAPSE
                var collapseid = $"scen_{Tools.GenerateRandomInt()}";
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                writer.AddAttribute(HtmlTextWriterAttribute.Type, "button");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "btn btn-success collapsed");
                writer.AddAttribute("data-toggle", "collapse");
                writer.AddAttribute("data-target", $"#{collapseid}");
                writer.AddAttribute("aria-expanded", "false");
                writer.RenderBeginTag(HtmlTextWriterTag.Button);//<button>
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "glyphicon glyphicon-collapse-down");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);//<span>
                writer.WriteEncodedText("Scenarios");
                writer.RenderEndTag();//</span>
                writer.RenderEndTag();//</button>
                writer.RenderEndTag();//</td>
                #endregion
                writer.RenderEndTag();//</tr>
                #region SCENARIOS RENDER
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);//<tr>
                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);//<td>
                RenderScenarioResults(writer, feature.ScenarioList, collapseid);
                writer.RenderEndTag();//</td>
                writer.RenderEndTag();//</tr>
                #endregion
                writer.RenderEndTag();//</tbody>
            }
            #endregion

            writer.RenderEndTag();//</table>
            writer.RenderEndTag();//</div>
            writer.RenderEndTag();//</div>
        }

        private void RenderImage(HtmlTextWriter writer, string src, int maxwidthpercentage)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Href, src);
            writer.AddAttribute(HtmlTextWriterAttribute.Target, "_blank");
            writer.RenderBeginTag(HtmlTextWriterTag.A); //<a>
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "img-thumbnail");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, src);
            writer.AddAttribute(HtmlTextWriterAttribute.Style, $"max-width: {maxwidthpercentage}%");
            writer.RenderBeginTag(HtmlTextWriterTag.Img); //<img>
            writer.RenderEndTag(); //</img>
            writer.RenderEndTag(); //</a>
        }

        private string BuildBugMessage(ScenarioContextContainer scenario)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Steps to reproduce: ");
            List<string> steps = scenario.StepList.Select(step => step.StepType + " " + step.StepTitle).ToList();
            stringBuilder.AppendLine(steps.SplitList(true));
            stringBuilder.AppendLine("Error Message: ");
            stringBuilder.Append(scenario.TestOutput.Message);

            return HttpUtility.JavaScriptStringEncode(stringBuilder.ToString());
        }

    }
}
