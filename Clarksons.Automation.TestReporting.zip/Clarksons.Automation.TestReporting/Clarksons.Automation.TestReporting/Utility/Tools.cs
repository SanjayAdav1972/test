﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Clarksons.Automation.TestReporting.Utility
{
    public static class Tools
    {
        /// <summary>
        /// Generates SECURE random numbers using OS entropy to generate seeds. OS entropy is a random value
        /// which is generated using sound, mouse click and keyboard timings, thermal temp, etc.
        /// </summary>
        /// <returns></returns>
        public static int GenerateRandomInt()
        {
            using (RNGCryptoServiceProvider rg = new RNGCryptoServiceProvider())
            {
                byte[] rno = new byte[5];

                rg.GetBytes(rno);

                if (BitConverter.ToInt32(rno, 0) < 0)
                    return BitConverter.ToInt32(rno, 0) * -1;
                else
                    return BitConverter.ToInt32(rno, 0);
            }
        }

        public static void DeleteFile(string image)
        {
            try
            {
                File.Delete(image);
            }
            catch (IOException)
            {
                DeleteFile(image);
            }
        }
    }
}
