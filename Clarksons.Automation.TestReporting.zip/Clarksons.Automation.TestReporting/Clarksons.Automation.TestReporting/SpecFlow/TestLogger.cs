﻿using Clarksons.Automation.TestReporting.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TechTalk.SpecFlow;

namespace Clarksons.Automation.TestReporting.SpecFlow
{
    /// <summary>
    /// Test logger class to record test execution. It can observe a Screenshot class in order to get Screenshots values.
    /// </summary>
    public class TestLogger : ITestLogger, IObserver<string>
    {

        readonly int GIF_FRAME_DELAY = 3000;
        public int Id { get; }
        public int Total { get; set; }
        public int Passed { get; set; }
        public int Failed { get; set; }
        public int Inconclusive { get; set; }
        public int Error { get; set; }
        public int Warning { get; set; }
        public int Timeout { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string Duration { get; set; }

        public string User { get; set; }
        public string Environment { get; set; }

        public List<FeatureContextContainer> Features { get; set; }

        private FeatureContextContainer _lastFeatureAdded;

        private IDisposable _unsubscriber;

        public TestLogger()
        {
            Features = new List<FeatureContextContainer>();
            StartTime = DateTime.Now;
            Id = Utility.Tools.GenerateRandomInt();
        }

        /// <summary>
        /// Add a feature to the TestRun Context.
        /// </summary>
        /// <param name="feature">FeatureContext from SpecFlow</param>
        public void AddFeature(FeatureContext feature)
        {
            _lastFeatureAdded = new FeatureContextContainer(feature);
            Features.Add(_lastFeatureAdded);
        }

        /// <summary>
        /// Add a scenario to the TestRun Context by creating a link to the relative feature.
        /// </summary>
        /// <param name="context">ScenarioContext from SpecFlow</param>
        public void AddScenarioToFeature(ScenarioContext scenario)
        {
            _lastFeatureAdded.AddScenario(scenario);
        }

        /// <summary>
        /// Add a step to the TestRun Context by creating a link to the relative scenario and feature.
        /// </summary>
        /// <param name="context">ScenarioContext from SpecFlow</param>
        public void AddStepToScenario(ScenarioStepContext step)
        {
            _lastFeatureAdded.GetLastAddedScenario().AddStep(step);
        }

        /// <summary>
        /// Takes the values from the last executed feature and sum them to the overall test execution
        /// </summary>
        public void UpdateTestCount()
        {

            Total += _lastFeatureAdded.Total;
            Passed += _lastFeatureAdded.Passed;
            Failed += _lastFeatureAdded.Failed;
            Inconclusive += _lastFeatureAdded.Inconclusive;
        }

        /// <summary>
        /// Call after the scenario is completed updates the scenario count for current feature
        /// </summary>
        public void UpdateScenarioCount() => _lastFeatureAdded.UpdateScenarioCount();

        /// <summary>
        /// Mark the current step -and the linked scenario- as failed
        /// </summary>
        public void ReportStepFailure()
        {
            _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().StepStatus = Enums.TestStatus.Failed;
            _lastFeatureAdded.GetLastAddedScenario().Status = Enums.TestStatus.Failed;
        }

        /// <summary>
        /// Mark the current step -and the linked scenario- as passed. The Scenario is not marked if it is already marked as failure.
        /// </summary>
        public void ReportStepPass()
        {
            _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().StepStatus = Enums.TestStatus.Passed;

            if (_lastFeatureAdded.GetLastAddedScenario().Status != Enums.TestStatus.Failed)
                _lastFeatureAdded.GetLastAddedScenario().Status = Enums.TestStatus.Passed;
        }

        /// <summary>
        /// Generate a Gif using the collection of images for a step.
        /// </summary>
        /// <param name="storelocation">Location where the files are phisically stored</param>
        /// <param name="artifactlocation">Location where the files are available on the network. Used only in case HTML report is hosted on a network.</param>
        public void GroupImagesInGif(string storelocation, string artifactlocation = null)
        {
            var screenshots = _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().ScreenShotPath;
            var fileName = $"Gif_{Tools.GenerateRandomInt()}.gif";
            var store = Path.Combine(storelocation, fileName);
            var artifact = Path.Combine(artifactlocation, fileName);
            if (screenshots.Count > 1)
            {
                using (GifWriter gif = new GifWriter(store, GIF_FRAME_DELAY))
                {
                    screenshots.ForEach(image => gif.WriteFrame(Path.Combine(storelocation, Path.GetFileName(image))));
                }

                _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().AddGif(artifactlocation != null ? artifact : store);

            }
        }

        /// <summary>
        /// Add a Test Output for the current scenario.
        /// </summary>
        /// <param name="message">Message to report</param>
        /// <param name="stackTrace">Error stack trace</param>
        public void AddTestOutput(string message, string stackTrace = null)
        {
            _lastFeatureAdded.GetLastAddedScenario().AddTestOutput(message, stackTrace);
        }

        public void AddScreenshot(string filePath)
        {
            _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().AddScrenshot(filePath);
        }

        public void AddExportedFile(string filePath)
        {
            _lastFeatureAdded.GetLastAddedScenario().ExportedFiles.Add(filePath);
        }

        /// <summary>
        /// Add final informations to the test container. 
        /// </summary>
        public void CloseTestExecution()
        {
            EndTime = DateTime.Now;
            var diff = EndTime.Subtract(StartTime);
            Duration = $"{diff.Hours}h {diff.Minutes}m {diff.Seconds}s";
        }

        /// <summary>
        /// Add the start time to the current scenario
        /// </summary>
        public void LogScenarioStart()
        {
            _lastFeatureAdded.GetLastAddedScenario().StartTime = DateTime.Now;
        }

        /// <summary>
        /// Add the end time to the current scenario and update the duration
        /// </summary>
        public void LogScenarioEnd()
        {
            //check if it's inconclusive
            if (_lastFeatureAdded.GetLastAddedScenario().AreStepsInconclusive())
                _lastFeatureAdded.GetLastAddedScenario().Status = Enums.TestStatus.Inconclusive;

            _lastFeatureAdded.GetLastAddedScenario().EndTime = DateTime.Now;

            var diff = _lastFeatureAdded.GetLastAddedScenario().EndTime.Subtract(_lastFeatureAdded.GetLastAddedScenario().StartTime);
            _lastFeatureAdded.GetLastAddedScenario().Duration = $"{diff.Hours}h {diff.Minutes}m {diff.Seconds}s";
        }

        public void MarkScenarioAsInconclusive()
        {
            _lastFeatureAdded.GetLastAddedScenario().Status = Enums.TestStatus.Inconclusive;
            _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().MarkStepInconclusive();
        }

        public virtual void Subscribe(IObservable<string> provider)
        {
            if (provider != null)
                _unsubscriber = provider.Subscribe(this);
        }

        public void OnNext(string value)
        {
            _lastFeatureAdded.GetLastAddedScenario().GetLastAddedStep().AddScrenshot(value);
        }

        public void OnError(Exception error)
        {
            throw error;
        }

        public void OnCompleted()
        {
            this.Unsubscribe();
        }

        public virtual void Unsubscribe()
        {
            _unsubscriber.Dispose();
        }
    }
}
