﻿using Clarksons.Automation.TestReporting.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;

namespace Clarksons.Automation.TestReporting.SpecFlow
{
    /// <summary>
    /// Context for single scenario
    /// </summary>
    public class ScenarioContextContainer
    {
        public int Id { get; set; }
        public string ScenarioName { get; }
        public TestStatus Status { get; set; }
        public string[] Tags { get; }
        public List<string> ExportedFiles { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string Duration { get; set; }
        public List<StepContextContainer> StepList { get; set; }

        public TestOutput TestOutput { get; set; }

        private StepContextContainer _lastAdded;


        public ScenarioContextContainer(ScenarioContext context)
        {
            ScenarioName = context.ScenarioInfo.Title;
            Tags = context.ScenarioInfo.Tags;
            StepList = new List<StepContextContainer>();
            Status = TestStatus.Inconclusive;
            ExportedFiles = new List<string>();
            Id = Utility.Tools.GenerateRandomInt();
        }

        public StepContextContainer GetLastAddedStep() => _lastAdded;

        /// <summary>
        /// Add a step to the Scenario Context.
        /// </summary>
        /// <param name="step">ScenarioStepContext from SpecFlow</param>
        public void AddStep(ScenarioStepContext step)
        {
            _lastAdded = new StepContextContainer(step);
            StepList.Add(_lastAdded);
        }

        public void AddTestOutput(string message, string stackTrace = null)
        {
            TestOutput = new TestOutput();

            TestOutput.Message = message;

            if (stackTrace != null)
                TestOutput.StackTrace = stackTrace;
        }

        public bool AreStepsInconclusive() => StepList.Any(step => step.StepStatus == TestStatus.Inconclusive);

    }

}
