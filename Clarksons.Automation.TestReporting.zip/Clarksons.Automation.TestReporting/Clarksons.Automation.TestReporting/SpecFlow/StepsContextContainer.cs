﻿using Clarksons.Automation.TestReporting.Enums;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Bindings;

namespace Clarksons.Automation.TestReporting.SpecFlow
{
    /// <summary>
    /// Context for single step execution
    /// </summary>
    public class StepContextContainer
    {
        public int Id { get; set; }
        public StepDefinitionType StepType { get; }
        public string StepTitle { get; }
        public List<string> ScreenShotPath { get;  set; }
        public TestStatus StepStatus { get; set; }
        public Table Table { get;  set; }
        public string MultilineText { get;  set; }
        public string Gif { get; private set; }

        public StepContextContainer(ScenarioStepContext context)
        {
            StepType = context.StepInfo.StepDefinitionType;
             
            StepTitle = context.StepInfo.Text;

            ScreenShotPath = new List<string>();

            StepStatus = TestStatus.Inconclusive;

            Table = context.StepInfo.Table;

            MultilineText = context.StepInfo.MultilineText;

            Id = Utility.Tools.GenerateRandomInt();
        }

        public void AddScrenshot(string imagePath)
        {
            ScreenShotPath.Add(imagePath);
        }

        public void AddGif(string gifPath)
        {
            Gif = gifPath;
        }

        public void MarkStepInconclusive()
        {
            StepStatus = TestStatus.Inconclusive;
            ScreenShotPath = new List<string>();
            Gif = string.Empty;
        }
    }
}