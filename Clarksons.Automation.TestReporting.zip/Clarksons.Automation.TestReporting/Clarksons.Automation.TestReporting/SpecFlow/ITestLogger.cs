﻿using System;
using TechTalk.SpecFlow;

namespace Clarksons.Automation.TestReporting.SpecFlow
{
    public interface ITestLogger
    {
        void AddExportedFile(string filePath);
        void AddFeature(FeatureContext feature);
        void AddScenarioToFeature(ScenarioContext scenario);
        void AddScreenshot(string filePath);
        void AddStepToScenario(ScenarioStepContext step);
        void AddTestOutput(string message, string stackTrace = null);
        void CloseTestExecution();
        void GroupImagesInGif(string storelocation, string artifactlocation = null);
        void LogScenarioEnd();
        void LogScenarioStart();
        void ReportStepFailure();
        void ReportStepPass();
        void Subscribe(IObservable<string> provider);
        void UpdateScenarioCount();
        void UpdateTestCount();
    }
}